package com.example.service

import java.time.DayOfWeek
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime

object MarketHoursManager {

    private val IST_ZONE = ZoneId.of("Asia/Kolkata")
    private val MARKET_OPEN_TIME = LocalTime.of(9, 15) // 9:15 AM IST
    private val MARKET_CLOSE_TIME = LocalTime.of(15, 30) // 3:30 PM IST

    /**
     * Returns true ONLY during Indian Market Hours:
     * 9:15 AM to 3:30 PM IST, Monday to Friday.
     */
    fun isMarketOpen(dateTime: ZonedDateTime = ZonedDateTime.now(IST_ZONE)): Boolean {
        val day = dateTime.dayOfWeek
        if (day == DayOfWeek.SATURDAY || day == DayOfWeek.SUNDAY) {
            return false
        }
        val currentTime = dateTime.toLocalTime()
        return !currentTime.isBefore(MARKET_OPEN_TIME) && !currentTime.isAfter(MARKET_CLOSE_TIME)
    }

    /**
     * Gets descriptive status string for the current market state in IST.
     */
    fun getMarketStatusText(dateTime: ZonedDateTime = ZonedDateTime.now(IST_ZONE)): String {
        val day = dateTime.dayOfWeek
        val time = dateTime.toLocalTime()

        return when {
            day == DayOfWeek.SATURDAY || day == DayOfWeek.SUNDAY -> "Market Closed (Weekend)"
            time.isBefore(MARKET_OPEN_TIME) -> "Pre-Market (Opens at 09:15 AM IST)"
            time.isAfter(MARKET_CLOSE_TIME) -> "Post-Market (Closed at 03:30 PM IST)"
            else -> "Market Open (09:15 AM - 03:30 PM IST)"
        }
    }
}
