package com.example.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import com.example.data.api.YahooFinanceService
import com.example.data.repository.EtfRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class EtfMarketTrackerService : Service() {

    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.IO + serviceJob)
    private val yahooFinanceService = YahooFinanceService()
    private val repository = EtfRepository()

    override fun onCreate() {
        super.onCreate()
        NotificationHelper.createNotificationChannels(this)
        _isRunning.value = true
        startForegroundServiceNotification("Initializing Market Tracker...")
        startMarketPollingLoop()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP_SERVICE) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {

        _isRunning.value = false
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun startForegroundServiceNotification(status: String) {
        val notification = NotificationHelper.buildForegroundNotification(this, status)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NotificationHelper.SERVICE_NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NotificationHelper.SERVICE_NOTIFICATION_ID, notification)
        }
    }

    private fun startMarketPollingLoop() {
        serviceScope.launch {
            while (true) {
                try {
                    val isMarketOpen = MarketHoursManager.isMarketOpen()
                    val marketStatus = MarketHoursManager.getMarketStatusText()
                    _lastStatusMessage.value = marketStatus

                    if (isMarketOpen) {
                        Log.d(TAG, "Market is OPEN (IST). Polling live ETF prices (30s interval)...")
                        startForegroundServiceNotification("Active 30s Polling | $marketStatus")

                        // Fetch active watchlist items
                        val currentList = repository.etfs.value.filter { it.isInWatchlist && it.alertsEnabled }

                        for (etf in currentList) {
                            val liveData = yahooFinanceService.fetchRealTimePrice(etf.symbol)
                            if (liveData != null && liveData.currentPrice > 0.0) {
                                // Calculate drop from Today's Open Price
                                val dropFromOpen = liveData.calculatePercentageDropFromOpen()
                                Log.d(TAG, "${liveData.symbol}: Open = ₹${liveData.openPrice}, Current = ₹${liveData.currentPrice}, DropFromOpen = -$dropFromOpen%")

                                for (threshold in liveData.targetDropPercentages) {
                                    if (dropFromOpen >= threshold) {
                                        val isMuted = com.example.data.storage.LocalPreferencesManager.isAlertMutedToday(
                                            applicationContext,
                                            liveData.symbol,
                                            threshold
                                        )

                                        if (!isMuted) {
                                            Log.d(TAG, "ALERT CONDITION MET! ${liveData.symbol} dropped -$dropFromOpen% (Threshold: -$threshold%). Firing notification & muting for today.")
                                            NotificationHelper.sendAlertNotification(
                                                context = applicationContext,
                                                symbol = liveData.symbol,
                                                dropPercent = threshold,
                                                currentPrice = liveData.currentPrice,
                                                openPrice = liveData.openPrice
                                            )
                                            com.example.data.storage.LocalPreferencesManager.muteAlertToday(
                                                applicationContext,
                                                liveData.symbol,
                                                threshold
                                            )
                                        } else {
                                            Log.d(TAG, "Alert for ${liveData.symbol} (-$threshold%) already triggered and muted today.")
                                        }
                                    }
                                }
                            }
                        }
                        // Zero-delay 30-second interval during market hours
                        delay(30_000)
                    } else {
                        Log.d(TAG, "Market is CLOSED. Pausing/Sleeping service to save battery...")
                        startForegroundServiceNotification("Market Closed | Idle Mode")
                        // Outside market hours: check every 60 seconds to save battery
                        delay(60_000)
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error in market polling loop", e)
                    delay(30_000)
                }
            }
        }
    }

    companion object {
        private const val TAG = "EtfTrackerService"
        const val ACTION_START_SERVICE = "com.example.service.START"
        const val ACTION_STOP_SERVICE = "com.example.service.STOP"

        private val _isRunning = MutableStateFlow(false)
        val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

        private val _lastStatusMessage = MutableStateFlow("Service Inactive")
        val lastStatusMessage: StateFlow<String> = _lastStatusMessage.asStateFlow()

        fun startService(context: Context) {
            val intent = Intent(context, EtfMarketTrackerService::class.java).apply {
                action = ACTION_START_SERVICE
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, EtfMarketTrackerService::class.java).apply {
                action = ACTION_STOP_SERVICE
            }
            context.startService(intent)
        }
    }
}
