package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R

object NotificationHelper {

    const val SERVICE_CHANNEL_ID = "etf_service_channel"
    const val ALERT_CHANNEL_ID = "etf_alert_channel"
    const val SERVICE_NOTIFICATION_ID = 1001

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            // Foreground Service Channel
            val serviceChannel = NotificationChannel(
                SERVICE_CHANNEL_ID,
                "Market Tracker Background Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows ongoing status during Indian Market Hours (9:15 AM - 3:30 PM IST)"
            }

            // Loud Alarm Sound Setup for Drop Alerts
            val alarmSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

            val audioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_ALARM)
                .build()

            // Drop Alert Push Notifications Channel with Loud Alarm Sound & High Importance
            val alertChannel = NotificationChannel(
                ALERT_CHANNEL_ID,
                "Price Drop Alarm Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Loud instant notifications when an asset drops past target percentage thresholds"
                setSound(alarmSoundUri, audioAttributes)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 250, 500, 250, 500)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }

            notificationManager.createNotificationChannel(serviceChannel)
            notificationManager.createNotificationChannel(alertChannel)
        }
    }

    fun buildForegroundNotification(context: Context, statusText: String): Notification {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(context, SERVICE_CHANNEL_ID)
            .setContentTitle("Indian Market Live Tracker")
            .setContentText(statusText)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    fun sendAlertNotification(
        context: Context,
        symbol: String,
        dropPercent: Double,
        currentPrice: Double,
        openPrice: Double
    ) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            symbol.hashCode(),
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val alarmSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        val notification = NotificationCompat.Builder(context, ALERT_CHANNEL_ID)
            .setContentTitle("🚨 PRICE DROP ALARM: $symbol")
            .setContentText("$symbol dropped -${String.format("%.2f", dropPercent)}% from Open! Current: ₹$currentPrice (Open: ₹$openPrice)")
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("$symbol dropped -${String.format("%.2f", dropPercent)}% from Today's Open Price!\n\n• Current Price: ₹$currentPrice\n• Today's Open: ₹$openPrice\n• Drop Target: -$dropPercent%\n\n(Alert muted for remainder of today)")
            )
            .setSmallIcon(R.mipmap.ic_launcher)
            .setAutoCancel(true)
            .setSound(alarmSoundUri)
            .setVibrate(longArrayOf(0, 500, 250, 500, 250, 500))
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(pendingIntent)
            .build()

        val notificationId = kotlin.math.abs(symbol.hashCode() + (dropPercent * 100).toInt())
        notificationManager.notify(notificationId, notification)
    }
}
