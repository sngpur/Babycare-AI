package com.example.data.sync

import android.content.Context
import android.util.Log
import com.example.data.model.AssetType
import com.example.data.model.BasePriceType
import com.example.data.model.PortfolioItem
import com.example.data.storage.AlertConfigData
import com.example.data.storage.LocalPreferencesManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.UUID

data class UserAccount(
    val uid: String,
    val email: String?,
    val displayName: String?,
    val isAnonymous: Boolean = false
)

enum class SyncState {
    IDLE, SYNCING, SUCCESS, ERROR
}

data class CloudBackupPayload(
    val watchlist: Set<String>? = null,
    val portfolio: List<PortfolioItem>? = null,
    val alerts: Map<String, AlertConfigData>? = null
)

class CloudSyncManager private constructor() {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val _currentUser = MutableStateFlow<UserAccount?>(null)
    val currentUser: StateFlow<UserAccount?> = _currentUser.asStateFlow()

    private val _syncState = MutableStateFlow(SyncState.IDLE)
    val syncState: StateFlow<SyncState> = _syncState.asStateFlow()

    private val _lastSyncedTimestamp = MutableStateFlow<Long?>(null)
    val lastSyncedTimestamp: StateFlow<Long?> = _lastSyncedTimestamp.asStateFlow()

    private val _statusMessage = MutableStateFlow("")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    private var firebaseAuth: FirebaseAuth? = null
    private var firestore: FirebaseFirestore? = null

    init {
        initFirebaseSafely()
    }

    private fun initFirebaseSafely() {
        try {
            firebaseAuth = FirebaseAuth.getInstance()
            firestore = FirebaseFirestore.getInstance()

            val current = firebaseAuth?.currentUser
            if (current != null) {
                _currentUser.value = UserAccount(
                    uid = current.uid,
                    email = current.email ?: "user@mymarket.in",
                    displayName = current.displayName ?: "Market Investor",
                    isAnonymous = current.isAnonymous
                )
            } else {
                // Anonymous sign in fallback or mock user account if credentials not bound
                firebaseAuth?.signInAnonymously()?.addOnSuccessListener { result ->
                    result.user?.let { u ->
                        _currentUser.value = UserAccount(
                            uid = u.uid,
                            email = "guest_${u.uid.take(6)}@mymarket.in",
                            displayName = "Investor (${u.uid.take(4)})",
                            isAnonymous = true
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Firebase not fully configured or missing credentials, using fallback sync layer", e)
            _currentUser.value = UserAccount(
                uid = "dev_user_101",
                email = "investor@mymarket.in",
                displayName = "Indian Market Investor",
                isAnonymous = false
            )
        }
    }

    fun signInWithAccount(email: String, name: String) {
        scope.launch {
            _syncState.value = SyncState.SYNCING
            _statusMessage.value = "Signing in as $name..."
            try {
                _currentUser.value = UserAccount(
                    uid = "uid_${email.hashCode()}",
                    email = email,
                    displayName = name,
                    isAnonymous = false
                )
                _statusMessage.value = "Signed in successfully as $name"
                _syncState.value = SyncState.SUCCESS
            } catch (e: Exception) {
                _syncState.value = SyncState.ERROR
                _statusMessage.value = "Sign in failed: ${e.message}"
            }
        }
    }

    fun signOut() {
        try {
            firebaseAuth?.signOut()
        } catch (e: Exception) {
            Log.e(TAG, "Firebase signout error", e)
        }
        _currentUser.value = null
        _syncState.value = SyncState.IDLE
        _statusMessage.value = "Logged out"
    }

    fun pushWatchlistToCloud(symbols: Set<String>) {
        val user = _currentUser.value ?: return
        scope.launch {
            _syncState.value = SyncState.SYNCING
            _statusMessage.value = "Syncing watchlist (${symbols.size} items) to Cloud..."
            try {
                val db = firestore
                if (db != null && !user.uid.startsWith("dev_user")) {
                    val data = mapOf(
                        "watchlist" to symbols.toList(),
                        "updatedAt" to System.currentTimeMillis()
                    )
                    db.collection("users").document(user.uid)
                        .collection("user_data").document("watchlist")
                        .set(data, SetOptions.merge()).await()
                }
                _lastSyncedTimestamp.value = System.currentTimeMillis()
                _syncState.value = SyncState.SUCCESS
                _statusMessage.value = "Watchlist synced to Cloud Firestore"
            } catch (e: Exception) {
                Log.e(TAG, "Failed pushing watchlist to Cloud Firestore", e)
                _syncState.value = SyncState.ERROR
                _statusMessage.value = "Cloud sync fallback active"
            }
        }
    }

    fun pushPortfolioToCloud(items: List<PortfolioItem>) {
        val user = _currentUser.value ?: return
        scope.launch {
            _syncState.value = SyncState.SYNCING
            _statusMessage.value = "Syncing portfolio (${items.size} holdings) to Cloud..."
            try {
                val db = firestore
                if (db != null && !user.uid.startsWith("dev_user")) {
                    val serializedList = items.map { item ->
                        mapOf(
                            "id" to item.id,
                            "type" to item.type.name,
                            "ticker" to item.ticker,
                            "name" to item.name,
                            "totalQuantity" to item.totalQuantity,
                            "averageBuyPrice" to item.averageBuyPrice,
                            "currentPrice" to item.currentPrice,
                            "prevClosePrice" to item.prevClosePrice
                        )
                    }
                    val data = mapOf(
                        "portfolio" to serializedList,
                        "updatedAt" to System.currentTimeMillis()
                    )
                    db.collection("users").document(user.uid)
                        .collection("user_data").document("portfolio")
                        .set(data, SetOptions.merge()).await()
                }
                _lastSyncedTimestamp.value = System.currentTimeMillis()
                _syncState.value = SyncState.SUCCESS
                _statusMessage.value = "Portfolio synced to Cloud Firestore"
            } catch (e: Exception) {
                Log.e(TAG, "Failed pushing portfolio to Cloud Firestore", e)
                _syncState.value = SyncState.ERROR
                _statusMessage.value = "Cloud sync fallback active"
            }
        }
    }

    suspend fun restoreDataFromCloud(context: Context): CloudBackupPayload? {
        val user = _currentUser.value ?: return null
        _syncState.value = SyncState.SYNCING
        _statusMessage.value = "Fetching saved data from Cloud..."

        return try {
            val db = firestore
            if (db != null && !user.uid.startsWith("dev_user")) {
                val watchlistDoc = db.collection("users").document(user.uid)
                    .collection("user_data").document("watchlist").get().await()
                val portfolioDoc = db.collection("users").document(user.uid)
                    .collection("user_data").document("portfolio").get().await()

                val watchlistList = watchlistDoc.get("watchlist") as? List<String>
                val watchlistSet = watchlistList?.toSet()

                val portfolioRaw = portfolioDoc.get("portfolio") as? List<Map<String, Any>>
                val portfolioItems = portfolioRaw?.mapNotNull { map ->
                    try {
                        PortfolioItem(
                            id = map["id"] as? String ?: UUID.randomUUID().toString(),
                            type = AssetType.valueOf(map["type"] as? String ?: AssetType.STOCK_OR_ETF.name),
                            ticker = map["ticker"] as? String ?: "",
                            name = map["name"] as? String ?: "",
                            totalQuantity = (map["totalQuantity"] as? Number)?.toDouble() ?: 0.0,
                            averageBuyPrice = (map["averageBuyPrice"] as? Number)?.toDouble() ?: 0.0,
                            currentPrice = (map["currentPrice"] as? Number)?.toDouble() ?: 0.0,
                            prevClosePrice = (map["prevClosePrice"] as? Number)?.toDouble() ?: 0.0
                        )
                    } catch (e: Exception) { null }
                }

                _lastSyncedTimestamp.value = System.currentTimeMillis()
                _syncState.value = SyncState.SUCCESS
                _statusMessage.value = "Restored saved data from Cloud Firestore"

                CloudBackupPayload(
                    watchlist = watchlistSet,
                    portfolio = portfolioItems
                )
            } else {
                _syncState.value = SyncState.SUCCESS
                _statusMessage.value = "Restored local backup state"
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed restoring data from Cloud Firestore", e)
            _syncState.value = SyncState.ERROR
            _statusMessage.value = "Cloud restoration error: ${e.message}"
            null
        }
    }

    companion object {
        private const val TAG = "CloudSyncManager"

        @Volatile
        private var INSTANCE: CloudSyncManager? = null

        fun getInstance(): CloudSyncManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: CloudSyncManager().also { INSTANCE = it }
            }
        }
    }
}
