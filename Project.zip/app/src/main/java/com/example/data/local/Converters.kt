package com.example.data.local

import androidx.room.TypeConverter

class Converters {
    @TypeConverter
    fun fromLogType(value: LogType): String = value.name

    @TypeConverter
    fun toLogType(value: String): LogType = try {
        LogType.valueOf(value)
    } catch (e: Exception) {
        LogType.FEEDING
    }
}
