package com.example.data.storage

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.AssetType
import com.example.data.model.BasePriceType
import com.example.data.model.PortfolioItem
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

data class AlertConfigData(
    val targetDrops: List<Double>,
    val baselineType: BasePriceType,
    val alertsEnabled: Boolean
)

object LocalPreferencesManager {

    private const val PREFS_NAME = "etf_watchlist_prefs"
    private const val KEY_WATCHLIST_SYMBOLS = "watchlist_symbols"
    private const val PREFIX_DROPS = "drops_"
    private const val PREFIX_BASELINE = "baseline_"
    private const val PREFIX_ALERTS_ENABLED = "alerts_enabled_"
    private const val PREFIX_MUTE = "mute_today_"

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun saveWatchlist(context: Context, symbols: Set<String>) {
        getPrefs(context).edit().putStringSet(KEY_WATCHLIST_SYMBOLS, symbols).apply()
    }

    fun loadWatchlist(context: Context): Set<String>? {
        return getPrefs(context).getStringSet(KEY_WATCHLIST_SYMBOLS, null)
    }

    fun saveEtfAlertConfig(
        context: Context,
        symbol: String,
        targetDrops: List<Double>,
        baselineType: BasePriceType,
        alertsEnabled: Boolean
    ) {
        val dropsStr = targetDrops.joinToString(",")
        getPrefs(context).edit()
            .putString("$PREFIX_DROPS$symbol", dropsStr)
            .putString("$PREFIX_BASELINE$symbol", baselineType.name)
            .putBoolean("$PREFIX_ALERTS_ENABLED$symbol", alertsEnabled)
            .apply()
    }

    fun loadEtfAlertConfig(context: Context, symbol: String): AlertConfigData? {
        val prefs = getPrefs(context)
        val dropsStr = prefs.getString("$PREFIX_DROPS$symbol", null) ?: return null
        val baselineName = prefs.getString("$PREFIX_BASELINE$symbol", BasePriceType.OPEN.name) ?: BasePriceType.OPEN.name
        val alertsEnabled = prefs.getBoolean("$PREFIX_ALERTS_ENABLED$symbol", true)

        val targetDrops = dropsStr.split(",")
            .mapNotNull { it.toDoubleOrNull() }
            .sorted()

        val baselineType = try {
            BasePriceType.valueOf(baselineName)
        } catch (e: Exception) {
            BasePriceType.OPEN
        }

        return AlertConfigData(targetDrops, baselineType, alertsEnabled)
    }

    fun removeEtfAlertConfig(context: Context, symbol: String) {
        getPrefs(context).edit()
            .remove("$PREFIX_DROPS$symbol")
            .remove("$PREFIX_BASELINE$symbol")
            .remove("$PREFIX_ALERTS_ENABLED$symbol")
            .apply()
    }

    /**
     * Checks if an alert threshold for a specific ticker has already been triggered and muted TODAY.
     */
    fun isAlertMutedToday(context: Context, symbol: String, dropThreshold: Double): Boolean {
        val todayStr = LocalDate.now().toString()
        val key = "$PREFIX_MUTE${todayStr}_${symbol.uppercase()}_$dropThreshold"
        return getPrefs(context).getBoolean(key, false)
    }

    /**
     * Flags an alert threshold as triggered and muted for the rest of today to avoid spamming.
     */
    fun muteAlertToday(context: Context, symbol: String, dropThreshold: Double) {
        val todayStr = LocalDate.now().toString()
        val key = "$PREFIX_MUTE${todayStr}_${symbol.uppercase()}_$dropThreshold"
        getPrefs(context).edit().putBoolean(key, true).apply()
    }

    private const val KEY_PORTFOLIO_ITEMS = "portfolio_items_v1"

    fun savePortfolioItems(context: Context, items: List<PortfolioItem>) {
        val jsonArray = JSONArray()
        items.forEach { item ->
            val obj = JSONObject().apply {
                put("id", item.id)
                put("type", item.type.name)
                put("ticker", item.ticker)
                put("name", item.name)
                put("totalQuantity", item.totalQuantity)
                put("averageBuyPrice", item.averageBuyPrice)
                put("currentPrice", item.currentPrice)
                put("prevClosePrice", item.prevClosePrice)
                put("price7DaysAgo", item.price7DaysAgo)
                put("price1MonthAgo", item.price1MonthAgo)
            }
            jsonArray.put(obj)
        }
        getPrefs(context).edit().putString(KEY_PORTFOLIO_ITEMS, jsonArray.toString()).apply()
    }

    fun loadPortfolioItems(context: Context): List<PortfolioItem>? {
        val str = getPrefs(context).getString(KEY_PORTFOLIO_ITEMS, null) ?: return null
        return try {
            val jsonArray = JSONArray(str)
            val list = mutableListOf<PortfolioItem>()
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val currP = obj.optDouble("currentPrice", 0.0)
                list.add(
                    PortfolioItem(
                        id = obj.optString("id", java.util.UUID.randomUUID().toString()),
                        type = AssetType.valueOf(obj.optString("type", AssetType.STOCK_OR_ETF.name)),
                        ticker = obj.optString("ticker", ""),
                        name = obj.optString("name", ""),
                        totalQuantity = obj.optDouble("totalQuantity", 0.0),
                        averageBuyPrice = obj.optDouble("averageBuyPrice", 0.0),
                        currentPrice = currP,
                        prevClosePrice = obj.optDouble("prevClosePrice", currP),
                        price7DaysAgo = obj.optDouble("price7DaysAgo", currP),
                        price1MonthAgo = obj.optDouble("price1MonthAgo", currP)
                    )
                )
            }
            list
        } catch (e: Exception) {
            null
        }
    }
}
