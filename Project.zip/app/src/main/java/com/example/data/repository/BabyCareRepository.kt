package com.example.data.repository

import com.example.data.local.*
import com.example.data.remote.GeminiApiClient
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class BabyCareRepository(private val dao: BabyCareDao) {

    val profileFlow: Flow<BabyProfile?> = dao.getProfileFlow()
    val chatMessagesFlow: Flow<List<ChatMessage>> = dao.getAllMessagesFlow()
    val careLogsFlow: Flow<List<CareLogEntry>> = dao.getAllCareLogsFlow()
    val milestonesFlow: Flow<List<MilestoneEntry>> = dao.getAllMilestonesFlow()

    suspend fun initializeDefaultDataIfNeeded() {
        // Initialize Baby Profile if missing
        val existingProfile = dao.getProfileSync()
        if (existingProfile == null) {
            dao.insertOrUpdateProfile(BabyProfile())
        }

        // Initialize Milestones if empty
        if (dao.getMilestoneCount() == 0) {
            dao.insertMilestones(getInitialMilestoneList())
        }
    }

    suspend fun updateProfile(profile: BabyProfile) {
        dao.insertOrUpdateProfile(profile)
    }

    suspend fun sendChatMessage(userText: String): Result<String> {
        // Save user message
        val userMsg = ChatMessage(sender = "user", text = userText)
        dao.insertMessage(userMsg)

        // Fetch current profile & message history for context
        val profile = dao.getProfileSync()
        val historyList = dao.getAllMessagesFlow().firstOrNull() ?: emptyList()
        val formattedHistory = historyList.takeLast(6).map { it.sender to it.text }

        // Get AI response
        val ageMonths = profile?.let {
            val diffMs = System.currentTimeMillis() - it.birthDateTimestamp
            (diffMs / (86400L * 1000L * 30L)).toInt().coerceAtLeast(0)
        } ?: 2

        val result = GeminiApiClient.getBabyCareAdvice(
            userMessage = userText,
            conversationHistory = formattedHistory,
            babyName = profile?.name,
            babyAgeMonths = ageMonths
        )

        result.onSuccess { aiReply ->
            val aiMsg = ChatMessage(
                sender = "ai",
                text = aiReply,
                isEmergencyNotice = aiReply.contains("medical attention", ignoreCase = true) || aiReply.contains("fever", ignoreCase = true)
            )
            dao.insertMessage(aiMsg)
        }

        return result
    }

    suspend fun clearChat() {
        dao.clearChatHistory()
    }

    suspend fun deleteChatMessage(messageId: Long) {
        dao.deleteMessageById(messageId)
    }

    suspend fun toggleBookmark(messageId: Long, currentBookmarked: Boolean) {
        dao.setBookmark(messageId, !currentBookmarked)
    }

    suspend fun addCareLog(logType: LogType, title: String, details: String, amountOrDuration: String) {
        val entry = CareLogEntry(
            logType = logType,
            title = title,
            details = details,
            amountOrDuration = amountOrDuration,
            timestamp = System.currentTimeMillis()
        )
        dao.insertCareLog(entry)
    }

    suspend fun deleteCareLog(entry: CareLogEntry) {
        dao.deleteCareLog(entry)
    }

    suspend fun toggleMilestone(milestoneId: Long, isCompleted: Boolean) {
        val timestamp = if (isCompleted) System.currentTimeMillis() else null
        dao.updateMilestoneState(milestoneId, isCompleted, timestamp)
    }

    private fun getInitialMilestoneList(): List<MilestoneEntry> = listOf(
        // 0-3 Months
        MilestoneEntry(ageGroup = "0-3 Months", category = "Social", title = "Social Smile", description = "Smiles responsively at parents or caregivers."),
        MilestoneEntry(ageGroup = "0-3 Months", category = "Physical", title = "Lifts Head 45°", description = "Pushes up on arms and holds head steady during tummy time."),
        MilestoneEntry(ageGroup = "0-3 Months", category = "Language", title = "Coos & Gurgles", description = "Makes soft vowel sounds (oh, ah) when spoken to."),
        MilestoneEntry(ageGroup = "0-3 Months", category = "Cognitive", title = "Tracks Objects", description = "Follows moving toys or faces with eyes from side to side."),

        // 3-6 Months
        MilestoneEntry(ageGroup = "3-6 Months", category = "Physical", title = "Rolls Tummy to Back", description = "Uses core muscles to flip over during floor play."),
        MilestoneEntry(ageGroup = "3-6 Months", category = "Language", title = "Laughs Out Loud", description = "Giggles or squeals at tickles, peekaboo, or fun sounds."),
        MilestoneEntry(ageGroup = "3-6 Months", category = "Cognitive", title = "Reaches for Toys", description = "Grasps objects intentionally with one or both hands."),
        MilestoneEntry(ageGroup = "3-6 Months", category = "Social", title = "Recognizes Familiar Faces", description = "Shows joyful excitement when seeing Mom, Dad, or caregivers."),

        // 6-9 Months
        MilestoneEntry(ageGroup = "6-9 Months", category = "Physical", title = "Sits Without Support", description = "Balances safely while sitting upright on the play mat."),
        MilestoneEntry(ageGroup = "6-9 Months", category = "Language", title = "Babbling Consonants", description = "Strings sounds together like 'ba-ba', 'da-da', 'ma-ma'."),
        MilestoneEntry(ageGroup = "6-9 Months", category = "Cognitive", title = "Plays Peekaboo", description = "Understands object permanence and looks for hidden items."),

        // 9-12 Months
        MilestoneEntry(ageGroup = "9-12 Months", category = "Physical", title = "Pulls Up to Stand", description = "Uses furniture or hands to stand up straight."),
        MilestoneEntry(ageGroup = "9-12 Months", category = "Physical", title = "Pincer Grasp", description = "Picks up small finger foods using thumb and forefinger."),
        MilestoneEntry(ageGroup = "9-12 Months", category = "Language", title = "First Word", description = "Says first meaningful word like 'Mama', 'Dada', or 'Bye'."),

        // 12-24 Months
        MilestoneEntry(ageGroup = "12-24 Months", category = "Physical", title = "Independent Walking", description = "Takes confident steps across the room independently."),
        MilestoneEntry(ageGroup = "12-24 Months", category = "Cognitive", title = "Feeds Self with Spoon", description = "Attempts to scoop food and drink from a cup."),
        MilestoneEntry(ageGroup = "12-24 Months", category = "Language", title = "2-Word Phrases", description = "Combines two words together like 'more milk' or 'big dog'.")
    )
}
