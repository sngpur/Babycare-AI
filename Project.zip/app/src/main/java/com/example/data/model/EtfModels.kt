package com.example.data.model

import java.util.Locale
import kotlin.math.abs

enum class BasePriceType(val label: String) {
    OPEN("Today's Open"),
    DAY_HIGH("Day's High"),
    PREV_CLOSE("Previous Close")
}

/**
 * Model class for WatchlistETF that stores ticker symbol, current price, 
 * today's open price, and a List of user-defined alert thresholds.
 */
data class WatchlistETF(
    val symbol: String,
    val name: String,
    val category: String,
    val currentPrice: Double,
    val openPrice: Double,
    val dayHigh: Double = currentPrice,
    val dayLow: Double = currentPrice,
    val prevClose: Double = openPrice,
    val alertThresholds: List<Double> = listOf(0.25, 0.50, 0.75)
) {
    /**
     * Mathematical logic calculating current percentage change strictly based on "Today's Open Price".
     * Formula: ((Current Price - Today's Open Price) / Today's Open Price) * 100
     */
    fun calculatePercentageChangeFromOpen(): Double {
        if (openPrice <= 0.0) return 0.0
        val change = ((currentPrice - openPrice) / openPrice) * 100.0
        return String.format(Locale.US, "%.2f", change).toDouble()
    }

    /**
     * Mathematical logic calculating percentage drop strictly from "Today's Open Price".
     * Formula: ((Today's Open Price - Current Price) / Today's Open Price) * 100
     */
    fun calculatePercentageDropFromOpen(): Double {
        if (openPrice <= 0.0) return 0.0
        val drop = ((openPrice - currentPrice) / openPrice) * 100.0
        return String.format(Locale.US, "%.2f", drop).toDouble()
    }

    /**
     * Checks if current percentage drop crosses a specific user-defined threshold.
     */
    fun isThresholdCrossed(threshold: Double): Boolean {
        val positiveThreshold = abs(threshold)
        return calculatePercentageDropFromOpen() >= positiveThreshold
    }
}

data class EtfItem(
    val symbol: String,
    val name: String,
    val category: String,
    val currentPrice: Double,
    val openPrice: Double,
    val dayHigh: Double,
    val dayLow: Double,
    val prevClose: Double,
    val changeAmount: Double,
    val changePercent: Double,
    val aumCr: Double,
    val expenseRatio: Double,
    val isInWatchlist: Boolean = false,
    val targetDropPercentages: List<Double> = listOf(0.25, 0.50, 1.00),
    val baselineType: BasePriceType = BasePriceType.OPEN,
    val alertsEnabled: Boolean = true
) {
    /**
     * Mathematical logic calculating current percentage change strictly based on "Today's Open Price".
     */
    fun calculatePercentageChangeFromOpen(): Double {
        if (openPrice <= 0.0) return 0.0
        val change = ((currentPrice - openPrice) / openPrice) * 100.0
        return String.format(Locale.US, "%.2f", change).toDouble()
    }

    /**
     * Mathematical logic calculating percentage drop strictly based on "Today's Open Price".
     */
    fun calculatePercentageDropFromOpen(): Double {
        if (openPrice <= 0.0) return 0.0
        val drop = ((openPrice - currentPrice) / openPrice) * 100.0
        return String.format(Locale.US, "%.2f", drop).toDouble()
    }

    fun getBaselinePrice(): Double {
        return when (baselineType) {
            BasePriceType.OPEN -> openPrice
            BasePriceType.DAY_HIGH -> dayHigh
            BasePriceType.PREV_CLOSE -> prevClose
        }
    }

    fun calculateTriggerPrice(dropPercentage: Double): Double {
        val base = getBaselinePrice()
        val dropFraction = dropPercentage / 100.0
        return base * (1.0 - dropFraction)
    }

    fun isDropTriggered(dropPercentage: Double): Boolean {
        val trigger = calculateTriggerPrice(dropPercentage)
        return currentPrice <= trigger
    }

    fun toWatchlistETF(): WatchlistETF {
        return WatchlistETF(
            symbol = symbol,
            name = name,
            category = category,
            currentPrice = currentPrice,
            openPrice = openPrice,
            dayHigh = dayHigh,
            dayLow = dayLow,
            prevClose = prevClose,
            alertThresholds = targetDropPercentages
        )
    }
}

data class MarketIndex(
    val symbol: String,
    val name: String,
    val value: Double,
    val changeAmount: Double,
    val changePercent: Double
)

