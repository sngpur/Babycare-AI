package com.example.data.api

import com.example.data.model.BasePriceType
import com.example.data.model.EtfItem
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

interface YahooFinanceApi {
    @GET("v1/finance/search")
    suspend fun searchTickers(
        @Query("q") query: String,
        @Query("quotesCount") quotesCount: Int = 15,
        @Query("newsCount") newsCount: Int = 0,
        @Query("enableFuzzyQuery") enableFuzzyQuery: Boolean = true
    ): YahooSearchResponse

    @GET("v8/finance/chart/{symbol}")
    suspend fun getChartData(
        @Path("symbol") symbol: String,
        @Query("interval") interval: String = "1d",
        @Query("range") range: String = "1d"
    ): YahooChartResponse
}

class YahooFinanceService {

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .addInterceptor { chain ->
            val request = chain.request().newBuilder()
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                .header("Accept", "application/json")
                .build()
            chain.proceed(request)
        }
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.NONE
        })
        .build()

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val api: YahooFinanceApi = Retrofit.Builder()
        .baseUrl("https://query2.finance.yahoo.com/")
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()
        .create(YahooFinanceApi::class.java)

    /**
     * 1. Search for Indian ETF tickers (e.g., NIFTYBEES.NS, GOLDBEES.NS, BANKBEES.NS).
     */
    suspend fun searchIndianEtfTickers(query: String): List<EtfItem> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()
        try {
            // Append .NS if query looks like a raw ticker keyword
            val searchQuery = if (query.contains(".")) query else "$query.NS"
            val response = api.searchTickers(query = searchQuery)
            val quotes = response.quotes ?: emptyList()

            val results = mutableListOf<EtfItem>()
            for (q in quotes) {
                val symbol = q.symbol
                val isIndianMarket = symbol.endsWith(".NS") || symbol.endsWith(".BO") || q.exchange in listOf("NSI", "BSE")
                val isEtf = q.quoteType == "ETF" || q.quoteType == "MUTUALFUND" || symbol.uppercase().contains("BEES") || symbol.uppercase().contains("ETF")

                if (isIndianMarket || isEtf) {
                    // Fetch real-time price info for matching ticker
                    val realTimeItem = fetchRealTimePrice(symbol)
                    if (realTimeItem != null) {
                        results.add(realTimeItem)
                    } else {
                        val cleanSymbol = symbol.removeSuffix(".NS").removeSuffix(".BO")
                        results.add(
                            EtfItem(
                                symbol = cleanSymbol,
                                name = q.longName ?: q.shortName ?: cleanSymbol,
                                category = inferCategory(cleanSymbol, q.longName ?: q.shortName),
                                currentPrice = 0.0,
                                openPrice = 0.0,
                                dayHigh = 0.0,
                                dayLow = 0.0,
                                prevClose = 0.0,
                                changeAmount = 0.0,
                                changePercent = 0.0,
                                aumCr = 2000.0,
                                expenseRatio = 0.20
                            )
                        )
                    }
                }
            }

            // If API returned no results but symbol matches standard Indian ETF name, attempt direct price fetch
            if (results.isEmpty()) {
                val directSymbol = if (query.uppercase().endsWith(".NS")) query.uppercase() else "${query.uppercase()}.NS"
                val directItem = fetchRealTimePrice(directSymbol)
                if (directItem != null) {
                    results.add(directItem)
                }
            }

            results
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }

    /**
     * 2. Fetch real-time price data, specifically extracting "Today's Open Price" and "Current Real-time Price".
     */
    suspend fun fetchRealTimePrice(rawSymbol: String): EtfItem? = withContext(Dispatchers.IO) {
        val symbolWithSuffix = if (rawSymbol.contains(".")) rawSymbol else "$rawSymbol.NS"
        val cleanSymbol = rawSymbol.removeSuffix(".NS").removeSuffix(".BO").uppercase()

        try {
            val response = api.getChartData(symbol = symbolWithSuffix)
            val result = response.chart?.result?.firstOrNull() ?: return@withContext null
            val meta = result.meta ?: return@withContext null
            val indicatorQuote = result.indicators?.quote?.firstOrNull()

            val currentPrice = meta.regularMarketPrice ?: 0.0
            val prevClose = meta.previousClose ?: meta.chartPreviousClose ?: currentPrice
            
            // Extract Today's Open Price
            val openPrice = indicatorQuote?.open?.firstOrNull { it != null } 
                ?: meta.regularMarketPrice 
                ?: prevClose

            val dayHigh = meta.regularMarketDayHigh 
                ?: indicatorQuote?.high?.filterNotNull()?.maxOrNull() 
                ?: currentPrice

            val dayLow = meta.regularMarketDayLow 
                ?: indicatorQuote?.low?.filterNotNull()?.minOrNull() 
                ?: currentPrice

            val changeAmount = currentPrice - prevClose
            val changePercent = if (prevClose > 0.0) (changeAmount / prevClose) * 100.0 else 0.0

            EtfItem(
                symbol = cleanSymbol,
                name = meta.longName ?: meta.shortName ?: "$cleanSymbol ETF",
                category = inferCategory(cleanSymbol, meta.longName ?: meta.shortName),
                currentPrice = round2(currentPrice),
                openPrice = round2(openPrice), // Today's Open Price
                dayHigh = round2(dayHigh),
                dayLow = round2(dayLow),
                prevClose = round2(prevClose),
                changeAmount = round2(changeAmount),
                changePercent = round2(changePercent),
                aumCr = 3200.0,
                expenseRatio = 0.18,
                baselineType = BasePriceType.OPEN
            )
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * 3. Fetch historical closing prices (7 days ago and 1 month ago) for portfolio holdings.
     */
    suspend fun fetchPortfolioHistoricalPrices(rawSymbol: String, fallbackPrice: Double): PortfolioHistoricalPrices = withContext(Dispatchers.IO) {
        val symbolWithSuffix = if (rawSymbol.contains(".")) rawSymbol else "$rawSymbol.NS"
        try {
            val response = api.getChartData(symbol = symbolWithSuffix, interval = "1d", range = "1mo")
            val result = response.chart?.result?.firstOrNull()
            val meta = result?.meta
            val closes = result?.indicators?.quote?.firstOrNull()?.close?.filterNotNull() ?: emptyList()

            val currentPrice = meta?.regularMarketPrice ?: closes.lastOrNull() ?: fallbackPrice
            val prevClosePrice = meta?.previousClose ?: meta?.chartPreviousClose ?: (if (closes.size >= 2) closes[closes.size - 2] else currentPrice * 0.992)

            val price7DaysAgo = if (closes.size >= 6) {
                closes[maxOf(0, closes.size - 6)]
            } else if (closes.isNotEmpty()) {
                closes.first()
            } else {
                currentPrice * 0.975
            }

            val price1MonthAgo = if (closes.isNotEmpty()) {
                closes.first()
            } else {
                currentPrice * 0.93
            }

            PortfolioHistoricalPrices(
                currentPrice = round2(currentPrice),
                prevClosePrice = round2(prevClosePrice),
                price7DaysAgo = round2(price7DaysAgo),
                price1MonthAgo = round2(price1MonthAgo)
            )
        } catch (e: Exception) {
            e.printStackTrace()
            PortfolioHistoricalPrices(
                currentPrice = round2(if (fallbackPrice > 0) fallbackPrice else 100.0),
                prevClosePrice = round2((if (fallbackPrice > 0) fallbackPrice else 100.0) * 0.992),
                price7DaysAgo = round2((if (fallbackPrice > 0) fallbackPrice else 100.0) * 0.975),
                price1MonthAgo = round2((if (fallbackPrice > 0) fallbackPrice else 100.0) * 0.93)
            )
        }
    }

    private fun inferCategory(symbol: String, fullName: String?): String {
        val s = symbol.uppercase()
        val f = (fullName ?: "").uppercase()
        return when {
            s.contains("GOLD") || f.contains("GOLD") || s.contains("SILVER") || f.contains("SILVER") -> "Gold & Silver"
            s.contains("BANK") || f.contains("BANK") || s.contains("FIN") -> "Bank & Financials"
            s.contains("IT") || f.contains("TECH") || s.contains("MON100") || s.contains("FANG") -> "IT & Tech"
            s.contains("LIQUID") || f.contains("CASH") || f.contains("LIQUID") -> "Debt"
            s.contains("NIFTY") || s.contains("JUNIOR") || s.contains("MID") -> "Nifty Equity"
            else -> "Sectoral"
        }
    }

    private fun round2(value: Double): Double {
        return try {
            String.format("%.2f", value).toDouble()
        } catch (e: Exception) {
            value
        }
    }
}
