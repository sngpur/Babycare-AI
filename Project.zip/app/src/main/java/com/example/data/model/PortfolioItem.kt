package com.example.data.model

import java.util.UUID

enum class AssetType {
    STOCK_OR_ETF,
    MUTUAL_FUND
}

data class PortfolioItem(
    val id: String = UUID.randomUUID().toString(),
    val type: AssetType,
    val ticker: String,
    val name: String,
    val totalQuantity: Double,
    val averageBuyPrice: Double,
    val currentPrice: Double = averageBuyPrice,
    val prevClosePrice: Double = currentPrice,
    val price7DaysAgo: Double = currentPrice,
    val price1MonthAgo: Double = currentPrice
) {
    val investedAmount: Double
        get() = totalQuantity * averageBuyPrice

    val currentAmount: Double
        get() = totalQuantity * currentPrice

    // All-time P&L
    val profitLoss: Double
        get() = currentAmount - investedAmount

    val profitLossPercent: Double
        get() = if (investedAmount > 0) (profitLoss / investedAmount) * 100.0 else 0.0

    // 1-Day P&L
    val oneDayPnL: Double
        get() {
            val base = if (prevClosePrice > 0) prevClosePrice else currentPrice
            return totalQuantity * (currentPrice - base)
        }

    val oneDayPnLPercent: Double
        get() {
            val base = if (prevClosePrice > 0) prevClosePrice else currentPrice
            return if (base > 0) ((currentPrice - base) / base) * 100.0 else 0.0
        }

    // 7-Day P&L
    val sevenDayPnL: Double
        get() {
            val base = if (price7DaysAgo > 0) price7DaysAgo else currentPrice
            return totalQuantity * (currentPrice - base)
        }

    val sevenDayPnLPercent: Double
        get() {
            val base = if (price7DaysAgo > 0) price7DaysAgo else currentPrice
            return if (base > 0) ((currentPrice - base) / base) * 100.0 else 0.0
        }

    // 1-Month P&L
    val oneMonthPnL: Double
        get() {
            val base = if (price1MonthAgo > 0) price1MonthAgo else currentPrice
            return totalQuantity * (currentPrice - base)
        }

    val oneMonthPnLPercent: Double
        get() {
            val base = if (price1MonthAgo > 0) price1MonthAgo else currentPrice
            return if (base > 0) ((currentPrice - base) / base) * 100.0 else 0.0
        }
}
