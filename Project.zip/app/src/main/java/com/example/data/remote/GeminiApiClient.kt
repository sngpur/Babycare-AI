package com.example.data.remote

import com.example.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

// --- Gemini REST Data Models ---

data class GenerateContentRequest(
    val contents: List<GeminiContent>,
    val systemInstruction: GeminiContent? = null,
    val generationConfig: GenerationConfig? = null
)

data class GeminiContent(
    val role: String? = null,
    val parts: List<GeminiPart>
)

data class GeminiPart(
    val text: String
)

data class GenerationConfig(
    val temperature: Float = 0.7f,
    val topP: Float = 0.95f,
    val topK: Int = 40
)

data class GenerateContentResponse(
    val candidates: List<Candidate>? = null
)

data class Candidate(
    val content: GeminiContent? = null
)

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

object GeminiApiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val service: GeminiApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(GeminiApiService::class.java)
    }

    private const val SYSTEM_PROMPT = """
You are "BabyCare AI", a highly specialized, trusted, and empathetic baby care assistant.
Your sole purpose is to provide accurate, verified, and safe information regarding infant and toddler care, baby nutrition, early childhood development, hygiene, and general parenting for ages 0 to 5 years.

Strict boundary rule: You must strictly limit all your responses to baby-related topics (ages 0 to 5 years). If a user asks about politics, adult health, coding, movies, or any non-baby-related subject, you must politely decline by saying: "I am specialized only in baby care and parenting. Please ask me a question related to your baby's health, diet, or development." Never hallucinate or guess facts; rely only on established pediatric and WHO guidelines.

Emergency safety rule: Always prioritize safety. If a user describes severe health issues like a very high temperature or trouble taking breaths, you must politely urge them to seek urgent medical help and visit the nearest hospital without delay.

Rule for Health Queries: You can share basic first aid and general home remedies for babies. You are strictly prohibited from acting as a doctor. You must not diagnose medical conditions, prescribe drugs, or suggest exact medicine dosages under any circumstances.

Mandatory Disclaimer Rule: If your response includes any health, illness, or remedy information, you must append a safety warning at the very end of your answer. Always add this exact text: Disclaimer - This information is for general awareness only. Please consult a certified pediatrician or your local doctor immediately for proper medical advice.

Language Detection & Response Rule: This application supports English and Hindi. Carefully analyze the user's input language.
1. If the user asks a query in English, respond strictly in English.
2. If the user asks a query in Hindi or Hinglish (Hindi written using the English alphabet, e.g., "Baby ko sardi ho gayi hai kya kare?"), you MUST ALWAYS respond in pure Hindi using the Devanagari script (e.g., "बच्चे को सर्दी हो गई है...").
Under no circumstances should you output responses in Hinglish. Ensure the tone remains empathetic, culturally appropriate, and professional across both languages.

Age Personalization Rule:
1. AGE VERIFICATION FIRST: If the user asks for advice, food/nutrition suggestions, feeding schedules, sleep guidance, home care remedies, or growth milestones, AND the baby's exact age (in months or years) is NOT mentioned in their prompt and NOT present in the conversation context or profile, you MUST politely ask the parent for the baby's current age (in months or years) FIRST before providing specific advice, recipes, or milestones.
2. AGE-TAILORED ADVICE: Once the baby's age is known (provided in context, mentioned in query, or stated previously), ALWAYS tailor all advice, food/diet suggestions, texture recommendations, safe sleep wake-windows, and growth milestones specifically and precisely to that exact age in months or years.

Vaccination Information Rule:
1. You can share general knowledge about standard infant immunization schedules (e.g. Birth: BCG, HepB, OPV; 6/10/14 Weeks: DTP, IPV, Hib, HepB, Rotavirus, PCV; 6 Months: Influenza; 9 Months: MMR/MR, Typhoid; 12-15 Months: Measles/MMR, Varicella, HepA; 18 Months: DTP booster).
2. ALWAYS remind users to verify exact dates, catch-up timelines, and available vaccine brands with their local health center or pediatrician.

Baby Diet & Food Safety Rule:
1. Provide age-appropriate food suggestions, texture recommendations (smooth purees, soft mashes, finger foods), and simple healthy baby recipes tailored to the baby's exact age in months.
2. ALLERGY SAFETY (3 to 5 Day Rule): ALWAYS explicitly advise parents to introduce ONLY ONE new food item at a time, waiting 3 to 5 days before introducing another new food to monitor for allergic reactions (e.g., rash, hives, vomiting, diarrhea, breathing issues).
3. CHOKING HAZARDS WARNING: ALWAYS include a clear safety warning highlighting common choking hazards (e.g., whole grapes/berries, whole nuts, hard raw veggies like carrots/celery, whole hot dogs, popcorn, hard candies, thick spoonfuls of raw peanut butter). Recommend cutting round foods lengthwise into thin quarters and steaming or mashing hard foods.

Sleep Routine & Nap Guide Rule:
1. Provide age-appropriate nap schedules (number of daily naps & recommended wake-window durations) and healthy bedtime habits (e.g., consistent bedtime routine, calm environment, white noise, safe sleep environment) tailored specifically to the child's exact age in months or years.
2. Always emphasize safe sleep environment rules (back sleeping, firm mattress, empty crib, cool room temperature 20-22°C/68-72°F) and consistent bedtime routines (bath, book, bed).

Calming Techniques & Peaceful Environment Rule:
1. Share gentle, safe, and relaxing methods to help infants settle down for rest (e.g. 5-S soothing method: Swaddle, Side/Stomach hold while awake & calming, Shush/White noise, Rhythmic Sway/Swing, Pacifier/Suck; gentle infant massage; dim warm lights; soft lullabies or rhythmic humming).
2. Guide parents on creating a peaceful, sleep-conducive environment (e.g., blackout curtains, optimal cool room temperature 20–22°C / 68–72°F, continuous white or pink noise machine, eliminating bright screens or overstimulating noise/toys).
3. Always emphasize safe sleep practices: place baby on their back in a firm, empty crib once calm.

Key Principles:
1. Tone & Style: Maintain a warm, polite, reassuring, and professional tone at all times. Always use simple, clear language that is easy to understand for parents.
2. Structure: Format your responses using short paragraphs and bullet points so they are very easy to read. Break down complex guidance into clear, actionable points with bold headings when appropriate.
3. Medical Safety: ALWAYS prioritize safety. If severe health issues like high temperature, difficulty breathing, or severe lethargy are mentioned, urge seeking urgent medical help and visiting the nearest hospital without delay.
4. Evidence-Based: Base advice on standard pediatric guidelines (AAP/WHO) for safe sleep, weaning, feeding cues, and developmental milestones.
"""

    suspend fun getBabyCareAdvice(
        userMessage: String,
        conversationHistory: List<Pair<String, String>> = emptyList(), // Pair(role, text)
        babyName: String? = null,
        babyAgeMonths: Int? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            // Provide offline smart verified response if API key isn't populated
            return@withContext Result.success(getOfflineFallbackResponse(userMessage, babyName, babyAgeMonths))
        }

        val contextInfo = if (babyName != null && babyAgeMonths != null) {
            "Note: The parent's baby is named $babyName and is $babyAgeMonths month(s) old.\n\n"
        } else ""

        val contents = mutableListOf<GeminiContent>()

        // Conversation history
        conversationHistory.takeLast(6).forEach { (role, text) ->
            val geminiRole = if (role == "user") "user" else "model"
            contents.add(
                GeminiContent(
                    role = geminiRole,
                    parts = listOf(GeminiPart(text = text))
                )
            )
        }

        // Current message
        contents.add(
            GeminiContent(
                role = "user",
                parts = listOf(GeminiPart(text = contextInfo + userMessage))
            )
        )

        val request = GenerateContentRequest(
            contents = contents,
            systemInstruction = GeminiContent(
                parts = listOf(GeminiPart(text = SYSTEM_PROMPT))
            ),
            generationConfig = GenerationConfig(
                temperature = 0.6f
            )
        )

        try {
            val response = service.generateContent(apiKey, request)
            val responseText = response.candidates
                ?.firstOrNull()
                ?.content
                ?.parts
                ?.firstOrNull()
                ?.text

            if (!responseText.isNull_or_blank()) {
                Result.success(responseText!!)
            } else {
                Result.success(getOfflineFallbackResponse(userMessage, babyName, babyAgeMonths))
            }
        } catch (e: Exception) {
            // Fallback gracefully to verified care tips if network error or quota reached
            Result.success(getOfflineFallbackResponse(userMessage, babyName, babyAgeMonths, e.localizedMessage))
        }
    }

    private fun String?.isNull_or_blank(): Boolean = this == null || this.isBlank()

    private fun getOfflineFallbackResponse(query: String, babyName: String?, babyAgeMonths: Int?, errorDetail: String? = null): String {
        val name = babyName ?: "your baby"
        val q = query.lowercase()

        val isHindiOrHinglish = query.any { it in '\u0900'..'\u097F' } || listOf(
            "ko", "hai", "kya", "kare", "kaise", "sardi", "bukhar", "gayi", "bachha", "baccha",
            "bachhe", "doodh", "neend", "sona", "khana", "pina", "chhota", "madad", "karne"
        ).any { word ->
            q.split(" ", "?", "!", ".", ",").contains(word) || q.contains(" $word ") || q.startsWith("$word ") || q.endsWith(" $word")
        }

        // Check for non-baby topics
        val offTopicKeywords = listOf(
            "politics", "president", "election", "movie", "film", "actor", "code", "coding", "python",
            "java", "javascript", "sql", "adult health", "car repair", "crypto", "bitcoin", "stock",
            "finance", "football", "basketball", "soccer"
        )
        if (offTopicKeywords.any { q.contains(it) }) {
            return if (isHindiOrHinglish) {
                "मैं केवल शिशु देखभाल और पालन-पोषण में विशेषज्ञ हूँ। कृपया अपने बच्चे के स्वास्थ्य, आहार या विकास से संबंधित प्रश्न पूछें।"
            } else {
                "I am specialized only in baby care and parenting. Please ask me a question related to your baby's health, diet, or development."
            }
        }

        // Extract age from query if mentioned (e.g. "6 months", "1 year", "3m", "8 महीने")
        val numberRegex = Regex("""(\d+)\s*(month|months|m|yr|yrs|year|years|महीने|महीना|साल)""")
        val ageMatch = numberRegex.find(q)
        val extractedMonths: Int? = when {
            ageMatch != null -> {
                val num = ageMatch.groupValues[1].toIntOrNull() ?: 6
                val unit = ageMatch.groupValues[2]
                if (unit.contains("yr") || unit.contains("year") || unit.contains("साल")) num * 12 else num
            }
            q.contains("newborn") || q.contains("0-3") -> 1
            q.contains("4-6") -> 5
            q.contains("6-12") -> 8
            q.contains("toddler") || q.contains("1-2") -> 18
            else -> babyAgeMonths
        }

        val ageMentionedInQuery = ageMatch != null || q.contains("newborn") || q.contains("toddler") ||
                q.contains("month") || q.contains("year") || q.contains("महीने") || q.contains("साल")

        // If user query is asking for age-sensitive advice/food/milestone and NO age was mentioned or provided in profile:
        val isAgeSensitive = q.contains("food") || q.contains("solid") || q.contains("eat") || q.contains("feed") ||
                q.contains("milestone") || q.contains("sleep") || q.contains("diet") || q.contains("khana") ||
                q.contains("doodh") || q.contains("neend") || q.contains("diet") || q.contains("recipe")

        if (isAgeSensitive && !ageMentionedInQuery && babyAgeMonths == null) {
            return if (isHindiOrHinglish) {
                """
### 🍼 आयु आधारित परामर्श (Age Personalization)

अपने बच्चे ($name) के लिए सबसे सटीक, सुरक्षित और उम्र के अनुकूल सलाह देने के लिए, **क्या आप कृपया बता सकते हैं कि आपका बच्चा कितने महीने या साल का है?**

जैसे ही आप अपने बच्चे की सही उम्र बताएंगे, मैं आपको निम्न विषयों पर विशिष्ट सलाह दूंगा:
• **उम्र के अनुसार सही आहार और पोषण तालिका**
• **सुरक्षित नींद के नियम और नींद का समय**
• **शारीरिक एवं मानसिक विकास के पड़ाव (Milestones)**
""".trimIndent()
            } else {
                """
### 🍼 Age Personalization

To give you the most accurate, safe, and age-tailored guidance for $name, **could you please tell me your baby's current age (in months or years)?**

Once you share your baby's exact age, I will immediately provide personalized recommendations for:
• **Age-specific nutrition & solid food menus**
• **Safe sleep wake-windows & night routines**
• **Key developmental growth milestones to expect**
""".trimIndent()
            }
        }

        val age = extractedMonths ?: 6

        if (isHindiOrHinglish) {
            return when {
                q.contains("fever") || q.contains("temperature") || q.contains("sick") || q.contains("bukhar") || q.contains("sardi") -> """
### 🤒 शिशु में बुखार और सर्दी से बचाव के उपाय (${age} महीने के अनुसार)

• **बुखार की स्थिति**: यदि शरीर का तापमान **38.0°C (100.4°F)** या उससे अधिक है, तो **बाल रोग विशेषज्ञ (Doctor) से परामर्श लें**।
• **${age} महीने के लिए विशेष देखभाल**:
  - शिशु को हल्के, सांस लेने योग्य सूती कपड़े पहनाएं।
  - निर्जलीकरण (डिहाइड्रेशन) से बचाने के लिए ${if (age < 6) "केवल स्तनपान या फार्मूला दूध पिलाते रहें" else "दूध के साथ थोड़ा उबला पानी और हल्का तरल आहार दें"}।
  - बिना डॉक्टर की सलाह के कोई भी दवा न दें।

Disclaimer - This information is for general awareness only. Please consult a certified pediatrician or your local doctor immediately for proper medical advice.
""".trimIndent()

                q.contains("calm") || q.contains("soothe") || q.contains("settle") || q.contains("relax") || q.contains("peaceful") || q.contains("shant") || q.contains("aaram") -> """
### 🕊️ ${age} महीने के शिशु को शांत करने के सौम्य उपाय एवं सुकून भरा वातावरण

• **शिशु को शांत करने के 5 सौम्य और सुरक्षित तरीके**:
  - **1. स्वैडलिंग (Swaddling)**: हल्के सूती कपड़े से शिशु को आराम से लपेटें (छाती पर आरामदायक, कूल्हों पर ढीला)।
  - **2. शशिंग व वाइट नॉयस (Shush & White Noise)**: कान के पास धीमी 'श-श' की आवाज करें या लगातार चलने वाली वाइट/पिंक नॉयस चलाएं।
  - **3. धीमी थपकी व झूला (Rhythmic Swaying)**: शिशु को गोद में लेकर धीमी लयबद्ध थपकी दें या हल्का झूला झुलाएं।
  - **4. शिशु मालिश (Gentle Infant Massage)**: पैरों के तलवों और पीठ पर हल्के गुनगुने तेल से नीचे की ओर मालिश करें।
  - **5. चूसने की शांत आदत (Suck/Pacifier)**: स्तनपान, फॉर्मूला या साफ पैसिफायर दें।

• **सुकून भरा और शांत वातावरण कैसे बनाएं (Peaceful Environment)**:
  - **कमरे की रोशनी**: सोने से 30 मिनट पहले रोशनी बिल्कुल धीमी (dim warm light) करें या ब्लैकआउट पर्दे लगाएं।
  - **अनुकूल तापमान**: कमरे का तापमान आरामदायक ठंडा (20–22°C / 68–72°F) रखें।
  - **उत्तेजना से बचाव**: टीवी, मोबाइल की स्क्रीन, तेज रोशनी और अचानक आवाज़ों को पूरी तरह बंद कर दें।

🛡️ **सुरक्षा चेतावनी**: शिशु जैसे ही शांत या सुस्त (drowsy) महसूस करे, उसे हमेशा पीठ के बल खाली पालने (firm mattress) में ही सुलाएं।
""".trimIndent()

                q.contains("sleep") || q.contains("nap") || q.contains("cry") || q.contains("neend") || q.contains("sona") || q.contains("bedtime") || q.contains("ro") -> """
### 🌙 ${age} महीने के शिशु की नींद, नेप शेड्यूल एवं शांत दिनचर्या

• **${age} महीने के अनुसार नींद का समय व वेक-विंडो (Wake Window)**:
  - ${if (age < 4) "**0-3 महीने**: कुल 14–17 घंटे नींद। **4–5 नेप (Naps)** प्रतिदिन। वेक-विंडो: केवल **60–90 मिनट**।" else if (age < 7) "**4-6 महीने**: कुल 12–15 घंटे नींद। **3–4 नेप** प्रतिदिन। वेक-विंडो: **1.5–2.5 घंटे**।" else if (age < 12) "**7-11 महीने**: कुल 12–14 घंटे नींद। **2 नेप** (सुबह ~9:00 और दोपहर ~1:30)। वेक-विंडो: **2.5–3.5 घंटे**।" else if (age < 24) "**1-2 साल (Toddler)**: कुल 11–14 घंटे नींद। **1-2 नेप** (दोपहर में ~12:30 बजे)। वेक-विंडो: **4–5.5 घंटे**।" else "**2-5 साल**: कुल 10–13 घंटे नींद। **1 दोपहर की नेप** या 45-मिनट शांत समय (Quiet Time)।"}

• **सोने की स्वस्थ आदतें व शांत वातावरण (Peaceful Sleep Environment)**:
  - **नियमित रात का रूटीन**: सोने से 20-30 मिनट पहले गुनगुने पानी से स्नान, हल्की मालिश, कहानी/लोरी और कमरे की रोशनी धीमी करें।
  - **शांत वातावरण**: कमरा ठंडा (20–22°C), अंधेरा (blackout curtains) और लगातार वाइट नॉयस वाला रखें।
  - **सुस्ती आते ही बिस्तर पर रखें**: बच्चे को पूरी तरह सोने से ठीक पहले (drowsy but awake) पालने में रखें ताकि वह खुद से सोना सीखे।

🛡️ **सुरक्षित नींद के नियम**:
  - हमेशा पीठ के बल सुलाएं। बिस्तरों पर ढीले कंबल, तकिया या खिलौने न रखें।
""".trimIndent()

                q.contains("food") || q.contains("solid") || q.contains("eat") || q.contains("feed") || q.contains("milk") || q.contains("doodh") || q.contains("khana") || q.contains("recipe") || q.contains("diet") -> """
### 🍼 ${age} महीने के शिशु का आहार, रेसिपी और पोषण गाइड

• **${age} महीने के लिए आहार सिफारिशें**:
  - ${if (age < 6) "**0 से 6 महीने**: केवल मां का दूध या फार्मूला दूध ही आवश्यक है। अभी ठोस आहार या पानी न दें।" else if (age < 12) "**6 से 12 महीने**: उबली मैश की हुई सब्जियां (गाजर, शकरकंद), केले की प्यूरी, मूंग दाल का पानी, पतली दलिया शुरू करें। साथ में स्तनपान जारी रखें।" else if (age < 24) "**1 से 2 साल**: घर का बना हल्का संतुलित भोजन (रोटी के छोटे टुकड़े, उबली दाल, दही, मुलायम फल, पनीर)।" else "**2 साल से बड़े बच्चे**: परिवार का सामान्य स्वस्थ भोजन (दिन में 3 मुख्य भोजन और 2 पौष्टिक स्नैक्स)।"}

• **सरल रेसिपी उदाहरण (${if (age < 6) "6 महीने बाद के लिए" else "${age} महीने के लिए"})**:
  - **गाजर और शकरकंद प्यूरी**: गाजर/शकरकंद को भाप में पकाएं और मुलायम प्यूरी बनाएं।
  - **मूंग दाल खिचड़ी**: मूंग दाल और चावल को बिना मिर्च-मसाले के उबालकर अच्छी तरह मैश करें।

⚠️ **एलर्जी सुरक्षा नियम (3 से 5 दिन का नियम)**:
  - **हमेशा एक बार में केवल एक नया खाद्य पदार्थ ही दें।**
  - नया भोजन शुरू करने के बाद **3 से 5 दिनों तक प्रतीक्षा करें** और किसी भी एलर्जी के लक्षण (जैसे दाने, उल्टी, दस्त, चेहरे पर सूजन) पर नजर रखें।

🚫 **दम घुटने का खतरा (Choking Hazards से सावधान)**:
  - साबुत अंगूर, साबुत मेवे (Nuts), कच्चे गाजर के टुकड़े, पॉपकॉर्न और hard candies से बचें।
  - गोल फलों (जैसे अंगूर) को हमेशा लंबाई में पतले टुकड़ों में काटकर ही दें। 1 साल से कम उम्र में शहद या अतिरिक्त नमक/चीनी न दें।
""".trimIndent()

                q.contains("milestone") || q.contains("roll") || q.contains("sit") || q.contains("walk") -> """
### ✨ ${age} महीने के शिशु के विकास के मुख्य पड़ाव (Milestones)

• **${age} महीने की उम्र में सामान्य विकास**:
  - ${if (age < 4) "सामाजिक मुस्कान, सिर को 45° उठाना, आंखों से वस्तुओं को ट्रैक करना।" else if (age < 7) "पेट के बल से पीठ के बल पलटना, बड़बड़ाना (Cooing/Babbling), खिलौनों तक हाथ पहुंचाना।" else if (age < 12) "बिना सहारे के बैठना, घुटनों के बल रेंगना (Crawling), अपना नाम पुकारने पर देखना।" else if (age < 24) "बिना सहारे चलना, 10-20 शब्द बोलना, गेंद फेंकना, खुद से चम्मच से खाने की कोशिश करना।" else "दौड़ना, 2-3 शब्दों के वाक्य बोलना, सीढ़ियां चढ़ना, चित्र पहचानना।"}
• **सलाह**: हर बच्चा अपनी गति से सीखता है और बढ़ता है।
""".trimIndent()

                q.contains("vaccine") || q.contains("vaccination") || q.contains("teeka") || q.contains("tikakarana") || q.contains("immuniz") || q.contains("shot") -> """
### 💉 सामान्य टीकाकरण तालिका (Immunization Schedule Guidance)

• **जन्म पर**: बीसीजी (BCG), हेपेटाइटिस बी (Hepatitis B dose 1), ओपीवी (OPV zero dose)
• **6, 10 और 14 सप्ताह**: डीपीटी/डीटीएपी, आईपीवी (Polio), हिब (Hib), हेपेटाइटिस बी, रोटावायरस, पीसीवी
• **6 महीने**: वार्षिक इन्फ्लूएंजा टीका (Flu shot)
• **9 महीने**: एमएमआर / एमआर (खसरा-रूबेला), टाइफाइड कंजुगेट
• **12-15 महीने**: हेपेटाइटिस ए (पहला टीका), चिकनपॉक्स (Varicella), एमएमआर डोज 2
• **16-18 महीने**: डीपीटी बूस्टर 1, आईपीवी बूस्टर, हिब बूस्टर

⚠️ **महत्वपूर्ण सूचना**: टीकाकरण की तिथियां और उपलब्ध ब्रांड आपके क्षेत्र और स्वास्थ्य केंद्र के अनुसार भिन्न हो सकते हैं। कृपया अपने बच्चे के सटीक टीकाकरण कैलेंडर और तिथियों के लिए अपने स्थानीय स्वास्थ्य केंद्र या बाल रोग विशेषज्ञ (Pediatrician) से अवश्य पुष्टि करें।
""".trimIndent()

                else -> """
### 🧸 बेबीकेयर एआई सहायक (${age} महीने के शिशु हेतु)

मैं आपके ${age} महीने के बच्चे ($name) की देखभाल में सहायता के लिए प्रस्तुत हूँ!

**आप मुझसे ये प्रश्न पूछ सकते हैं:**
• "${age} महीने के बच्चे के सोने की सही दिनचर्या क्या है?"
• "${age} महीने के बच्चे को क्या-क्या खिलाना सुरक्षित है?"
• "${age} महीने के बच्चे के विकास के मुख्य पड़ाव क्या हैं?"

*नोट: गंभीर स्थिति या उच्च बुखार होने पर तुरंत अपने नजदीकी बाल रोग विशेषज्ञ से संपर्क करें।*
""".trimIndent()
            }
        }

        return when {
            q.contains("fever") || q.contains("temperature") || q.contains("sick") -> """
### 🤒 Infant Fever & Care Guidance (${age}-Month Old)

• **Medical Alert**: ${if (age < 3) "In babies under 3 months, any rectal temperature of **38.0°C (100.4°F)** or higher requires **IMMEDIATE medical attention** at an emergency clinic." else "If fever exceeds 38.5°C (101.3°F) or $name appears unusually lethargic or refuses fluids, contact your pediatrician promptly."}
• **Comfort Measures for a ${age}-Month Old**:
  - Keep $name dressed in light, breathable cotton layers.
  - Hydration: ${if (age < 6) "Offer frequent breastmilk or formula." else "Offer breastmilk, formula, and small sips of cooled boiled water."}
  - Never give aspirin or medication without pediatrician advice.

Disclaimer - This information is for general awareness only. Please consult a certified pediatrician or your local doctor immediately for proper medical advice.
""".trimIndent()

            q.contains("calm") || q.contains("soothe") || q.contains("settle") || q.contains("relax") || q.contains("peaceful") || q.contains("shush") || q.contains("swaddle") -> """
### 🕊️ Gentle Calming Techniques & Peaceful Environment Guide (${age}-Month Old)

• **Safe & Gentle Methods to Calm $name**:
  - **1. The 5-S Soothing Sequence**: Gentle Swaddling (snug at chest, loose at hips), Side/Stomach hold while calming (always place on back to sleep), Continuous Shushing or White Noise matching heartbeat volume, Rhythmic Swaying/Rocking, and Pacifier Sucking.
  - **2. Soothing Infant Massage**: Light downward strokes on $name's legs, feet, and back using a baby-safe moisturizer or natural oil.
  - **3. Soft Lullabies & Rhythmic Humming**: Low-pitch, repetitive humming or gentle back patting matching a resting heartbeat (~60 bpm).
  - **4. Warm Bath Wind-Down**: A gentle 10-minute warm bath followed by snug towel cuddling.

• **Creating a Peaceful Sleep Environment for Better Sleep**:
  - **Lighting & Atmosphere**: Dim all artificial lights 30 minutes before bed; use warm nightlights or blackout curtains to signal sleep time.
  - **Optimal Room Temperature**: Keep the nursery cool and comfortable at 20–22°C (68–72°F).
  - **Soundscape**: Use continuous white or pink noise machines to block out household disruptions and mimic womb acoustics.
  - **Zero Overstimulation**: Turn off all screens, TVs, and bright noisy toys during the wind-down period.

🛡️ **Safe Sleep Reminder**: Once $name settles and becomes drowsy, transfer them to their back in a firm, empty crib free of loose blankets, pillows, or plush toys.
""".trimIndent()

            q.contains("sleep") || q.contains("nap") || q.contains("cry") || q.contains("bedtime") -> """
### 🌙 Sleep Routine, Nap Schedule & Bedtime Guide (${age}-Month Old)

• **Age-Appropriate Nap Schedule & Wake Windows (${age} Months)**:
  - ${if (age < 4) "**0 to 3 Months**: 14–17 hours total sleep. **4–5 naps daily**. Short wake window: **60–90 minutes** between naps." else if (age < 7) "**4 to 6 Months**: 12–15 hours total sleep. **3–4 naps daily** (Morning, Midday, Late Afternoon). Wake window: **1.5–2.5 hours**." else if (age < 12) "**7 to 11 Months**: 12–14 hours total sleep. **2 naps daily** (Morning ~9:00 AM & Afternoon ~1:30 PM). Wake window: **2.5–3.5 hours**." else if (age < 24) "**12 to 24 Months (Toddler)**: 11–14 hours total sleep. Transitioning from 2 naps to **1 afternoon nap** (~12:30–2:30 PM). Wake window: **4–5.5 hours**." else "**2 to 5 Years**: 10–13 hours total sleep. **1 afternoon nap** or 45-minute quiet rest time."}

• **Healthy Bedtime Habits for $name**:
  - **Consistent Bedtime Routine**: Follow a predictable 20–30 minute routine (Warm Bath ➔ Gentle Massage ➔ Story/Lullaby ➔ Lights Out).
  - **Optimal Bedtime**: Aim for a consistent bedtime between 7:00 PM and 8:00 PM to prevent overtiredness.
  - **Drowsy But Awake**: Put $name into the crib drowsy but awake so they learn to self-soothe to sleep.
  - **Sleep Environment**: Keep the room dark, cool (20–22°C / 68–72°F), and use continuous white noise.

🛡️ **Safe Sleep Environment**: Always place $name on their back in an empty crib with a firm mattress and no loose blankets or pillows.
""".trimIndent()

            q.contains("food") || q.contains("solid") || q.contains("eat") || q.contains("feed") || q.contains("milk") || q.contains("diet") || q.contains("recipe") -> """
### 🍼 Baby Diet & Nutrition Guide (${age}-Month Old)

• **Age-Appropriate Food Suggestions (${age} Months)**:
  - ${if (age < 6) "**0 to 6 Months**: Breastmilk or formula provides 100% of required nutrition. Do not introduce solids, water, or juices yet." else if (age < 12) "**6 to 12 Months**: Smooth single-ingredient purees (steamed sweet potato, carrot, mashed avocado/banana, iron-fortified cereal). Transition to soft finger foods as chewing skills develop." else if (age < 24) "**12 to 24 Months (Toddler)**: Whole milk alongside balanced table foods (soft cooked veggies, chopped fruits, lentils, eggs, whole grains)." else "**2 to 5 Years**: 3 balanced meals plus 2 healthy snacks daily featuring proteins, fruits, vegetables, and dairy."}

• **Simple Baby Recipe (${if (age < 6) "For 6+ Months" else "For ${age} Months"})**:
  - **Steamed Apple & Sweet Potato Puree**: Peel and dice 1 sweet potato and 1 apple. Steam until fork-tender (12-15 mins). Blend with a splash of breastmilk, formula, or warm water until completely smooth.

⚠️ **Allergy Safety Rule (One New Food at a Time)**:
  - **Introduce only ONE new food item at a time.**
  - **Wait 3 to 5 days** before offering another new food to monitor for allergic reactions (rash, hives, vomiting, diarrhea, swelling, or wheezing).

🚫 **Choking Hazard Warnings**:
  - Avoid **whole grapes/berries, whole nuts, raw hard carrots/celery, whole hot dogs, popcorn, hard candies, and thick spoonfuls of raw nut butter**.
  - Always cut round foods lengthwise into thin bite-sized quarters. Never offer honey to infants under 12 months.
""".trimIndent()

            q.contains("milestone") || q.contains("roll") || q.contains("sit") || q.contains("walk") || q.contains("development") -> """
### ✨ Growth & Developmental Milestones (${age}-Month Old)

• **Key Milestones for ${age} Months**:
  - ${if (age < 4) "Social smiling, lifting head 45° during tummy time, following objects visually." else if (age < 7) "Rolling tummy-to-back, babbling consonant sounds, reaching for and holding toys." else if (age < 12) "Sitting without support, crawling, responding to name, developing pincer grasp." else if (age < 24) "Walking independently, speaking 10–20 words, stacking blocks, imitating everyday tasks." else "Running, jumping with both feet, forming 2–3 word sentences, interactive play."}
• **Parent Tip**: Celebrate $name's progress—every baby blossoms at their own unique pace!
""".trimIndent()

            q.contains("vaccine") || q.contains("vaccination") || q.contains("immuniz") || q.contains("shot") || q.contains("jab") -> """
### 💉 Standard Immunization Schedule & Information

• **At Birth**: BCG, Hepatitis B (dose 1), OPV (zero dose).
• **6, 10 & 14 Weeks**: DTP/DTaP, IPV (Polio), Hib, Hepatitis B, Rotavirus, PCV (Pneumococcal).
• **6 Months**: Annual Influenza vaccine.
• **9 Months**: MMR / MR (Measles-Rubella), Typhoid conjugate.
• **12–15 Months**: Hepatitis A (dose 1), Varicella (Chickenpox), MMR dose 2.
• **16–18 Months**: DTP booster 1, IPV booster, Hib booster.

⚠️ **Important Reminder**: Immunization schedules and vaccine availability can vary by region and pediatric guidance. Always verify exact dates, catch-up schedules, and available vaccine brands with your local health center or pediatrician.
""".trimIndent()

            else -> """
### 🧸 Welcome to BabyCare AI Assistant (${age}-Month Tailored)

I am here to support you with age-tailored, verified guidance for $name (${age} months old)!

**Recommended Questions for a ${age}-Month Old:**
• "What is a healthy sleep schedule for a ${age}-month-old?"
• "What foods are safest for a ${age}-month-old baby?"
• "What growth milestones should I look for at ${age} months?"

*Note: For immediate medical emergencies or high fevers in young infants, please contact your pediatrician or local emergency clinic.*
""".trimIndent()
        }
    }
}
