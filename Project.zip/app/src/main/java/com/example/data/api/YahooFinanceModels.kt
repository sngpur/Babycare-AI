package com.example.data.api

import com.squareup.moshi.Json

data class YahooSearchResponse(
    @Json(name = "quotes") val quotes: List<YahooQuoteResult>? = emptyList()
)

data class YahooQuoteResult(
    @Json(name = "symbol") val symbol: String,
    @Json(name = "shortname") val shortName: String? = null,
    @Json(name = "longname") val longName: String? = null,
    @Json(name = "quoteType") val quoteType: String? = null,
    @Json(name = "exchange") val exchange: String? = null,
    @Json(name = "sector") val sector: String? = null,
    @Json(name = "industry") val industry: String? = null
)

data class YahooChartResponse(
    @Json(name = "chart") val chart: YahooChartBody? = null
)

data class YahooChartBody(
    @Json(name = "result") val result: List<YahooChartResult>? = null,
    @Json(name = "error") val error: YahooError? = null
)

data class YahooError(
    @Json(name = "code") val code: String? = null,
    @Json(name = "description") val description: String? = null
)

data class YahooChartResult(
    @Json(name = "meta") val meta: YahooChartMeta? = null,
    @Json(name = "timestamp") val timestamp: List<Long>? = null,
    @Json(name = "indicators") val indicators: YahooChartIndicators? = null
)

data class YahooChartMeta(
    @Json(name = "currency") val currency: String? = null,
    @Json(name = "symbol") val symbol: String,
    @Json(name = "longName") val longName: String? = null,
    @Json(name = "shortName") val shortName: String? = null,
    @Json(name = "regularMarketPrice") val regularMarketPrice: Double? = null,
    @Json(name = "chartPreviousClose") val chartPreviousClose: Double? = null,
    @Json(name = "previousClose") val previousClose: Double? = null,
    @Json(name = "regularMarketDayHigh") val regularMarketDayHigh: Double? = null,
    @Json(name = "regularMarketDayLow") val regularMarketDayLow: Double? = null,
    @Json(name = "instrumentType") val instrumentType: String? = null
)

data class YahooChartIndicators(
    @Json(name = "quote") val quote: List<YahooQuoteIndicator>? = null
)

data class YahooQuoteIndicator(
    @Json(name = "open") val open: List<Double?>? = null,
    @Json(name = "high") val high: List<Double?>? = null,
    @Json(name = "low") val low: List<Double?>? = null,
    @Json(name = "close") val close: List<Double?>? = null
)

data class PortfolioHistoricalPrices(
    val currentPrice: Double,
    val prevClosePrice: Double,
    val price7DaysAgo: Double,
    val price1MonthAgo: Double
)
