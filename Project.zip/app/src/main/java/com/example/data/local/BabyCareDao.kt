package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface BabyCareDao {
    // Profile
    @Query("SELECT * FROM baby_profile WHERE id = 1 LIMIT 1")
    fun getProfileFlow(): Flow<BabyProfile?>

    @Query("SELECT * FROM baby_profile WHERE id = 1 LIMIT 1")
    suspend fun getProfileSync(): BabyProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateProfile(profile: BabyProfile)

    // Chat
    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun getAllMessagesFlow(): Flow<List<ChatMessage>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessage): Long

    @Query("DELETE FROM chat_messages")
    suspend fun clearChatHistory()

    @Query("DELETE FROM chat_messages WHERE id = :id")
    suspend fun deleteMessageById(id: Long)

    @Query("UPDATE chat_messages SET isBookmarked = :isBookmarked WHERE id = :id")
    suspend fun setBookmark(id: Long, isBookmarked: Boolean)

    // Care Logs
    @Query("SELECT * FROM care_logs ORDER BY timestamp DESC")
    fun getAllCareLogsFlow(): Flow<List<CareLogEntry>>

    @Query("SELECT * FROM care_logs WHERE logType = :type ORDER BY timestamp DESC")
    fun getCareLogsByTypeFlow(type: LogType): Flow<List<CareLogEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCareLog(entry: CareLogEntry): Long

    @Delete
    suspend fun deleteCareLog(entry: CareLogEntry)

    // Milestones
    @Query("SELECT * FROM milestones ORDER BY id ASC")
    fun getAllMilestonesFlow(): Flow<List<MilestoneEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMilestones(milestones: List<MilestoneEntry>)

    @Query("UPDATE milestones SET isCompleted = :isCompleted, completedTimestamp = :timestamp WHERE id = :id")
    suspend fun updateMilestoneState(id: Long, isCompleted: Boolean, timestamp: Long?)

    @Query("SELECT COUNT(*) FROM milestones")
    suspend fun getMilestoneCount(): Int
}
