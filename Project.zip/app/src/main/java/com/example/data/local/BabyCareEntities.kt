package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "baby_profile")
data class BabyProfile(
    @PrimaryKey val id: Int = 1,
    val name: String = "Little One",
    val birthDateTimestamp: Long = System.currentTimeMillis() - (60L * 86400L * 1000L), // Default ~2 months old
    val gender: String = "Boy",
    val weightKg: Float = 5.2f,
    val heightCm: Float = 58.0f
)

@Entity(tableName = "chat_messages")
data class ChatMessage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sender: String, // "user" or "ai"
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isBookmarked: Boolean = false,
    val isEmergencyNotice: Boolean = false
)

enum class LogType {
    FEEDING, SLEEP, DIAPER, GROWTH, HEALTH
}

@Entity(tableName = "care_logs")
data class CareLogEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val logType: LogType,
    val title: String,
    val details: String,
    val timestamp: Long = System.currentTimeMillis(),
    val amountOrDuration: String = "" // e.g., "120 ml", "45 mins", "37.2°C"
)

@Entity(tableName = "milestones")
data class MilestoneEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ageGroup: String, // "0-3 Months", "3-6 Months", "6-9 Months", "9-12 Months", "12-24 Months"
    val category: String, // "Physical", "Cognitive", "Language", "Social"
    val title: String,
    val description: String,
    val isCompleted: Boolean = false,
    val completedTimestamp: Long? = null
)
