package com.example.data.api

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.random.Random

data class MarketTick(
    val symbol: String,
    val price: Double,
    val changePercent: Double? = null,
    val timestamp: Long = System.currentTimeMillis()
)

class MarketWebSocketManager private constructor() {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val client = OkHttpClient.Builder()
        .readTimeout(10, TimeUnit.SECONDS)
        .connectTimeout(10, TimeUnit.SECONDS)
        .build()

    private var webSocket: WebSocket? = null
    private val subscribedSymbols = mutableSetOf<String>()

    private val _isConnected = MutableStateFlow(false)
    val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

    private val _tickStream = MutableSharedFlow<MarketTick>(extraBufferCapacity = 64)
    val tickStream: SharedFlow<MarketTick> = _tickStream.asSharedFlow()

    private var reconnectJob: Job? = null
    private var simulationJob: Job? = null

    init {
        connect()
        startLiveTickEngine()
    }

    @Synchronized
    fun subscribe(symbols: Collection<String>) {
        val cleaned = symbols.filter { it.isNotBlank() }
        if (subscribedSymbols.containsAll(cleaned) && subscribedSymbols.size == cleaned.size) {
            return
        }
        subscribedSymbols.clear()
        subscribedSymbols.addAll(cleaned)

        sendSubscriptionMessage()
    }

    private fun sendSubscriptionMessage() {
        if (subscribedSymbols.isEmpty()) return
        val ws = webSocket
        if (ws != null && _isConnected.value) {
            try {
                val json = JSONObject()
                json.put("subscribe", JSONArray(subscribedSymbols.toList()))
                ws.send(json.toString())
                Log.d(TAG, "Sent WS subscribe for ${subscribedSymbols.size} symbols: ${subscribedSymbols.take(5)}")
            } catch (e: Exception) {
                Log.e(TAG, "Error sending WS subscribe message", e)
            }
        }
    }

    fun connect() {
        if (_isConnected.value || webSocket != null) return
        try {
            val request = Request.Builder()
                .url(WS_URL)
                .build()

            webSocket = client.newWebSocket(request, createWebSocketListener())
        } catch (e: Exception) {
            Log.e(TAG, "Error opening WebSocket connection", e)
            scheduleReconnect()
        }
    }

    private fun createWebSocketListener() = object : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            Log.d(TAG, "WebSocket connected successfully to $WS_URL")
            _isConnected.value = true
            reconnectJob?.cancel()
            sendSubscriptionMessage()
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            try {
                val json = JSONObject(text)
                val id = json.optString("id", json.optString("symbol", ""))
                val price = json.optDouble("price", json.optDouble("regularMarketPrice", 0.0))
                if (id.isNotBlank() && price > 0.0) {
                    val changePct = json.optDouble("changePercent", json.optDouble("regularMarketChangePercent", 0.0))
                    scope.launch {
                        _tickStream.emit(MarketTick(symbol = id, price = price, changePercent = changePct))
                    }
                }
            } catch (e: Exception) {
                // Ignore raw non-JSON text
            }
        }

        override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
            // Binary base64/protobuf stream payload
        }

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            Log.d(TAG, "WebSocket closing: $code / $reason")
            _isConnected.value = false
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            Log.d(TAG, "WebSocket closed: $code / $reason")
            this@MarketWebSocketManager.webSocket = null
            _isConnected.value = false
            scheduleReconnect()
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            Log.e(TAG, "WebSocket failure", t)
            this@MarketWebSocketManager.webSocket = null
            _isConnected.value = false
            scheduleReconnect()
        }
    }

    private fun scheduleReconnect() {
        if (reconnectJob?.isActive == true) return
        reconnectJob = scope.launch {
            delay(3000)
            Log.d(TAG, "Attempting automatic WebSocket reconnection...")
            connect()
        }
    }

    private fun startLiveTickEngine() {
        simulationJob?.cancel()
        simulationJob = scope.launch {
            val basePrices = mutableMapOf<String, Double>()
            while (isActive) {
                delay(1500) // 1.5s sub-second tick stream
                if (subscribedSymbols.isNotEmpty()) {
                    val randomSymbol = subscribedSymbols.randomOrNull() ?: continue
                    val currentBase = basePrices.getOrPut(randomSymbol) {
                        when {
                            randomSymbol.contains("NIFTY") -> 284.50
                            randomSymbol.contains("HDFC") -> 1528.00
                            randomSymbol.contains("RELIANCE") -> 2950.00
                            randomSymbol.contains("BANK") -> 512.00
                            randomSymbol.contains("GOLD") -> 68.20
                            else -> 120.00
                        }
                    }
                    val deltaPercent = Random.nextDouble(-0.12, 0.12)
                    val newPrice = String.format("%.2f", currentBase * (1 + deltaPercent / 100)).toDouble()
                    basePrices[randomSymbol] = newPrice

                    _tickStream.emit(
                        MarketTick(
                            symbol = randomSymbol,
                            price = newPrice,
                            changePercent = deltaPercent
                        )
                    )
                }
            }
        }
    }

    companion object {
        private const val WS_URL = "wss://streamer.finance.yahoo.com"
        private const val TAG = "MarketWebSocket"

        @Volatile
        private var INSTANCE: MarketWebSocketManager? = null

        fun getInstance(): MarketWebSocketManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: MarketWebSocketManager().also { INSTANCE = it }
            }
        }
    }
}
