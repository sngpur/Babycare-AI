package com.example.data.repository

import android.content.Context
import com.example.data.api.MarketTick
import com.example.data.api.MarketWebSocketManager
import com.example.data.api.YahooFinanceService
import com.example.data.model.AssetType
import com.example.data.model.BasePriceType
import com.example.data.model.EtfItem
import com.example.data.model.MarketIndex
import com.example.data.model.PortfolioItem
import com.example.data.storage.LocalPreferencesManager
import com.example.data.sync.CloudSyncManager
import com.example.data.sync.SyncState
import com.example.data.sync.UserAccount
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class EtfRepository(
    private val yahooFinanceService: YahooFinanceService = YahooFinanceService(),
    context: Context? = null
) {
    private var appContext: Context? = context?.applicationContext

    private val wsManager = MarketWebSocketManager.getInstance()
    val isWebSocketConnected: StateFlow<Boolean> = wsManager.isConnected

    private val cloudSyncManager = CloudSyncManager.getInstance()
    val currentUser: StateFlow<UserAccount?> = cloudSyncManager.currentUser
    val syncState: StateFlow<SyncState> = cloudSyncManager.syncState
    val lastSyncedTimestamp: StateFlow<Long?> = cloudSyncManager.lastSyncedTimestamp
    val syncStatusMessage: StateFlow<String> = cloudSyncManager.statusMessage

    private val repositoryScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val initialEtfs = listOf(
        EtfItem(
            symbol = "NIFTYBEES",
            name = "Nippon India ETF Nifty 50 BeES",
            category = "Nifty Equity",
            currentPrice = 252.40,
            openPrice = 253.80,
            dayHigh = 254.50,
            dayLow = 251.90,
            prevClose = 251.80,
            changeAmount = 0.60,
            changePercent = 0.24,
            aumCr = 28450.0,
            expenseRatio = 0.04,
            isInWatchlist = true,
            targetDropPercentages = listOf(0.25, 0.50, 0.75, 1.00),
            baselineType = BasePriceType.OPEN
        ),
        EtfItem(
            symbol = "BANKBEES",
            name = "Nippon India ETF Bank BeES",
            category = "Bank & Financials",
            currentPrice = 518.20,
            openPrice = 522.00,
            dayHigh = 523.50,
            dayLow = 516.80,
            prevClose = 520.10,
            changeAmount = -1.90,
            changePercent = -0.37,
            aumCr = 14200.0,
            expenseRatio = 0.18,
            isInWatchlist = true,
            targetDropPercentages = listOf(0.50, 1.00, 1.50),
            baselineType = BasePriceType.DAY_HIGH
        ),
        EtfItem(
            symbol = "GOLDBEES",
            name = "Nippon India ETF Gold BeES",
            category = "Gold & Silver",
            currentPrice = 62.85,
            openPrice = 63.10,
            dayHigh = 63.25,
            dayLow = 62.60,
            prevClose = 62.50,
            changeAmount = 0.35,
            changePercent = 0.56,
            aumCr = 9800.0,
            expenseRatio = 0.79,
            isInWatchlist = true,
            targetDropPercentages = listOf(0.25, 0.50, 1.00),
            baselineType = BasePriceType.OPEN
        ),
        EtfItem(
            symbol = "MON100",
            name = "Motilal Oswal Nasdaq 100 ETF",
            category = "Global Markets",
            currentPrice = 168.30,
            openPrice = 170.00,
            dayHigh = 170.50,
            dayLow = 167.90,
            prevClose = 166.80,
            changeAmount = 1.50,
            changePercent = 0.90,
            aumCr = 7400.0,
            expenseRatio = 0.58,
            isInWatchlist = true,
            targetDropPercentages = listOf(0.50, 1.00, 2.00),
            baselineType = BasePriceType.OPEN
        ),
        EtfItem(
            symbol = "ITBEES",
            name = "Nippon India ETF IT",
            category = "IT & Tech",
            currentPrice = 39.50,
            openPrice = 39.20,
            dayHigh = 39.80,
            dayLow = 39.10,
            prevClose = 39.00,
            changeAmount = 0.50,
            changePercent = 1.28,
            aumCr = 3800.0,
            expenseRatio = 0.22,
            isInWatchlist = false,
            targetDropPercentages = listOf(0.25, 0.75, 1.25),
            baselineType = BasePriceType.OPEN
        ),
        EtfItem(
            symbol = "SILVERBEES",
            name = "Nippon India ETF Silver BeES",
            category = "Gold & Silver",
            currentPrice = 88.40,
            openPrice = 89.20,
            dayHigh = 89.50,
            dayLow = 88.10,
            prevClose = 88.00,
            changeAmount = 0.40,
            changePercent = 0.45,
            aumCr = 4200.0,
            expenseRatio = 0.55,
            isInWatchlist = false,
            targetDropPercentages = listOf(0.50, 1.00),
            baselineType = BasePriceType.OPEN
        ),
        EtfItem(
            symbol = "JUNIORBEES",
            name = "Nippon India ETF Junior BeES (Nifty Next 50)",
            category = "Nifty Equity",
            currentPrice = 680.15,
            openPrice = 684.00,
            dayHigh = 686.00,
            dayLow = 678.00,
            prevClose = 675.00,
            changeAmount = 5.15,
            changePercent = 0.76,
            aumCr = 3100.0,
            expenseRatio = 0.23,
            isInWatchlist = false,
            targetDropPercentages = listOf(0.50, 1.00, 1.50),
            baselineType = BasePriceType.OPEN
        ),
        EtfItem(
            symbol = "CPSEETF",
            name = "CPSE ETF - Public Sector Enterprises",
            category = "Sectoral",
            currentPrice = 94.20,
            openPrice = 95.00,
            dayHigh = 95.40,
            dayLow = 93.80,
            prevClose = 94.80,
            changeAmount = -0.60,
            changePercent = -0.63,
            aumCr = 18500.0,
            expenseRatio = 0.05,
            isInWatchlist = false,
            targetDropPercentages = listOf(0.25, 0.50, 1.00),
            baselineType = BasePriceType.DAY_HIGH
        ),
        EtfItem(
            symbol = "MAFANG",
            name = "Mirae Asset NYSE FANG+ ETF",
            category = "Global Markets",
            currentPrice = 82.60,
            openPrice = 83.50,
            dayHigh = 83.90,
            dayLow = 82.10,
            prevClose = 81.90,
            changeAmount = 0.70,
            changePercent = 0.85,
            aumCr = 2200.0,
            expenseRatio = 0.65,
            isInWatchlist = false,
            targetDropPercentages = listOf(0.50, 1.00, 2.00),
            baselineType = BasePriceType.OPEN
        ),
        EtfItem(
            symbol = "PHARMABEES",
            name = "Nippon India ETF Pharma",
            category = "Sectoral",
            currentPrice = 23.40,
            openPrice = 23.30,
            dayHigh = 23.60,
            dayLow = 23.20,
            prevClose = 23.20,
            changeAmount = 0.20,
            changePercent = 0.86,
            aumCr = 1100.0,
            expenseRatio = 0.21,
            isInWatchlist = false,
            targetDropPercentages = listOf(0.25, 0.50),
            baselineType = BasePriceType.OPEN
        ),
        EtfItem(
            symbol = "MID150BEES",
            name = "Nippon India ETF Nifty Midcap 150",
            category = "Nifty Equity",
            currentPrice = 210.50,
            openPrice = 212.00,
            dayHigh = 212.80,
            dayLow = 209.80,
            prevClose = 209.50,
            changeAmount = 1.00,
            changePercent = 0.48,
            aumCr = 1900.0,
            expenseRatio = 0.21,
            isInWatchlist = false,
            targetDropPercentages = listOf(0.50, 1.00, 1.50),
            baselineType = BasePriceType.OPEN
        ),
        EtfItem(
            symbol = "LIQUIDBEES",
            name = "Nippon India ETF Liquid BeES",
            category = "Debt",
            currentPrice = 1000.00,
            openPrice = 1000.00,
            dayHigh = 1000.00,
            dayLow = 1000.00,
            prevClose = 1000.00,
            changeAmount = 0.00,
            changePercent = 0.00,
            aumCr = 13500.0,
            expenseRatio = 0.68,
            isInWatchlist = false,
            targetDropPercentages = listOf(0.10),
            baselineType = BasePriceType.OPEN
        )
    )

    private val _etfs = MutableStateFlow(initialEtfs)
    val etfs: StateFlow<List<EtfItem>> = _etfs.asStateFlow()

    private val defaultPortfolioItems = listOf(
        PortfolioItem(
            id = "default_1",
            type = AssetType.STOCK_OR_ETF,
            ticker = "NIFTYBEES.NS",
            name = "Nippon India Nifty 50 BeES ETF",
            totalQuantity = 100.0,
            averageBuyPrice = 250.0,
            currentPrice = 284.50
        ),
        PortfolioItem(
            id = "default_2",
            type = AssetType.STOCK_OR_ETF,
            ticker = "HDFCBANK.NS",
            name = "HDFC Bank Limited",
            totalQuantity = 25.0,
            averageBuyPrice = 1600.0,
            currentPrice = 1528.0
        ),
        PortfolioItem(
            id = "default_3",
            type = AssetType.STOCK_OR_ETF,
            ticker = "ITBEES.NS",
            name = "ICICI Prudential Nifty IT ETF",
            totalQuantity = 50.0,
            averageBuyPrice = 300.0,
            currentPrice = 345.0
        ),
        PortfolioItem(
            id = "default_4",
            type = AssetType.MUTUAL_FUND,
            ticker = "MIRAE-LC-DIRECT",
            name = "Mirae Asset Large Cap Fund",
            totalQuantity = 500.0,
            averageBuyPrice = 100.0,
            currentPrice = 116.60
        ),
        PortfolioItem(
            id = "default_5",
            type = AssetType.MUTUAL_FUND,
            ticker = "PPFCF-DIRECT",
            name = "Parag Parikh Flexi Cap Fund",
            totalQuantity = 800.0,
            averageBuyPrice = 75.0,
            currentPrice = 89.25
        )
    )

    private val _portfolioItems = MutableStateFlow(defaultPortfolioItems)
    val portfolioItems: StateFlow<List<PortfolioItem>> = _portfolioItems.asStateFlow()

    private val _isRefreshingPortfolio = MutableStateFlow(false)
    val isRefreshingPortfolio: StateFlow<Boolean> = _isRefreshingPortfolio.asStateFlow()

    private val _indices = MutableStateFlow(
        listOf(
            MarketIndex("NIFTY 50", "NIFTY 50", 24820.50, 105.20, 0.43),
            MarketIndex("BANKNIFTY", "BANK NIFTY", 51340.10, -120.40, -0.23),
            MarketIndex("NIFTYIT", "NIFTY IT", 41200.80, 310.50, 0.76),
            MarketIndex("SENSEX", "SENSEX", 81120.30, 340.10, 0.42)
        )
    )
    val indices: StateFlow<List<MarketIndex>> = _indices.asStateFlow()

    init {
        restoreFromStorage()
        updateWebSocketSubscriptions()
        observeWebSocketTicks()
    }

    fun initContext(context: Context) {
        this.appContext = context.applicationContext
        restoreFromStorage()
        updateWebSocketSubscriptions()
    }

    private fun updateWebSocketSubscriptions() {
        val watchlistSymbols = _etfs.value.map { if (it.symbol.contains(".")) it.symbol else "${it.symbol}.NS" }
        val portfolioSymbols = _portfolioItems.value.map { if (it.ticker.contains(".")) it.ticker else "${it.ticker}.NS" }
        val indexSymbols = listOf("^NSEI", "^NSEBANK", "^CNXIT", "^BSESN")
        wsManager.subscribe((watchlistSymbols + portfolioSymbols + indexSymbols).toSet())
    }

    private fun observeWebSocketTicks() {
        repositoryScope.launch {
            wsManager.tickStream.collect { tick ->
                onMarketTickReceived(tick)
            }
        }
    }

    private fun onMarketTickReceived(tick: MarketTick) {
        val rawSymbol = tick.symbol
        val cleanSymbol = rawSymbol.replace(".NS", "").replace(".BO", "")
        val newPrice = tick.price

        _etfs.update { list ->
            list.map { item ->
                if (item.symbol.equals(rawSymbol, ignoreCase = true) || item.symbol.equals(cleanSymbol, ignoreCase = true)) {
                    val open = if (item.openPrice > 0) item.openPrice else newPrice
                    val prev = if (item.prevClose > 0) item.prevClose else open
                    val diff = newPrice - prev
                    val pct = if (prev > 0) (diff / prev) * 100 else 0.0
                    val high = maxOf(item.dayHigh, newPrice)
                    val low = if (item.dayLow > 0) minOf(item.dayLow, newPrice) else newPrice

                    item.copy(
                        currentPrice = newPrice,
                        changeAmount = String.format("%.2f", diff).toDouble(),
                        changePercent = String.format("%.2f", pct).toDouble(),
                        dayHigh = high,
                        dayLow = low
                    )
                } else item
            }
        }

        _portfolioItems.update { list ->
            list.map { item ->
                if (item.ticker.equals(rawSymbol, ignoreCase = true) || item.ticker.equals(cleanSymbol, ignoreCase = true)) {
                    item.copy(currentPrice = newPrice)
                } else item
            }
        }

        _indices.update { list ->
            list.map { idx ->
                val isMatch = when (idx.symbol) {
                    "NIFTY 50" -> cleanSymbol.equals("NIFTYBEES", ignoreCase = true) || rawSymbol == "^NSEI"
                    "BANKNIFTY" -> cleanSymbol.equals("BANKBEES", ignoreCase = true) || rawSymbol == "^NSEBANK"
                    "NIFTYIT" -> cleanSymbol.equals("ITBEES", ignoreCase = true) || rawSymbol == "^CNXIT"
                    "SENSEX" -> rawSymbol == "^BSESN"
                    else -> false
                }
                if (isMatch) {
                    val delta = tick.changePercent ?: 0.02
                    val newIdxValue = String.format("%.2f", idx.value * (1 + delta / 100)).toDouble()
                    val newChange = String.format("%.2f", idx.changeAmount + (delta * 5)).toDouble()
                    idx.copy(
                        value = newIdxValue,
                        changeAmount = newChange,
                        changePercent = String.format("%.2f", delta).toDouble()
                    )
                } else idx
            }
        }
    }

    private fun restoreFromStorage() {
        val ctx = appContext ?: return
        val savedSymbols = LocalPreferencesManager.loadWatchlist(ctx)

        _etfs.update { list ->
            list.map { item ->
                val savedConfig = LocalPreferencesManager.loadEtfAlertConfig(ctx, item.symbol)
                val isWatchlisted = savedSymbols?.contains(item.symbol) ?: item.isInWatchlist

                if (savedConfig != null) {
                    item.copy(
                        isInWatchlist = isWatchlisted,
                        targetDropPercentages = savedConfig.targetDrops,
                        baselineType = savedConfig.baselineType,
                        alertsEnabled = savedConfig.alertsEnabled
                    )
                } else {
                    item.copy(isInWatchlist = isWatchlisted)
                }
            }
        }

        val savedPortfolio = LocalPreferencesManager.loadPortfolioItems(ctx)
        if (savedPortfolio != null) {
            _portfolioItems.value = savedPortfolio
        }
    }

    private fun persistState() {
        val ctx = appContext ?: return
        val watchlistSymbols = _etfs.value.filter { it.isInWatchlist }.map { it.symbol }.toSet()
        LocalPreferencesManager.saveWatchlist(ctx, watchlistSymbols)

        _etfs.value.forEach { item ->
            LocalPreferencesManager.saveEtfAlertConfig(
                context = ctx,
                symbol = item.symbol,
                targetDrops = item.targetDropPercentages,
                baselineType = item.baselineType,
                alertsEnabled = item.alertsEnabled
            )
        }

        LocalPreferencesManager.savePortfolioItems(ctx, _portfolioItems.value)

        // Push to Cloud Firestore
        cloudSyncManager.pushWatchlistToCloud(watchlistSymbols)
        cloudSyncManager.pushPortfolioToCloud(_portfolioItems.value)
    }

    fun signInAccount(email: String, name: String) {
        cloudSyncManager.signInWithAccount(email, name)
        repositoryScope.launch {
            triggerManualCloudSync()
        }
    }

    fun signOutAccount() {
        cloudSyncManager.signOut()
        _portfolioItems.value = emptyList()
        persistState()
    }

    fun triggerManualCloudSync() {
        val ctx = appContext ?: return
        val watchlistSymbols = _etfs.value.filter { it.isInWatchlist }.map { it.symbol }.toSet()
        cloudSyncManager.pushWatchlistToCloud(watchlistSymbols)
        cloudSyncManager.pushPortfolioToCloud(_portfolioItems.value)

        repositoryScope.launch {
            val payload = cloudSyncManager.restoreDataFromCloud(ctx)
            if (payload != null) {
                payload.watchlist?.let { cloudWatchlist ->
                    _etfs.update { list ->
                        list.map { item ->
                            item.copy(isInWatchlist = cloudWatchlist.contains(item.symbol))
                        }
                    }
                }
                payload.portfolio?.let { cloudPortfolio ->
                    if (cloudPortfolio.isNotEmpty()) {
                        _portfolioItems.value = cloudPortfolio
                    }
                }
                persistState()
                updateWebSocketSubscriptions()
            }
        }
    }

    fun addPortfolioItem(item: PortfolioItem) {
        _portfolioItems.update { list ->
            val existingIndex = list.indexOfFirst {
                it.ticker.equals(item.ticker, ignoreCase = true)
            }
            if (existingIndex != -1) {
                val existing = list[existingIndex]
                val combinedQty = existing.totalQuantity + item.totalQuantity
                val combinedInvested = (existing.totalQuantity * existing.averageBuyPrice) + (item.totalQuantity * item.averageBuyPrice)
                val newAvgBuyPrice = if (combinedQty > 0) combinedInvested / combinedQty else 0.0

                val updatedItem = existing.copy(
                    totalQuantity = combinedQty,
                    averageBuyPrice = newAvgBuyPrice,
                    currentPrice = if (item.currentPrice > 0 && item.currentPrice != item.averageBuyPrice) item.currentPrice else existing.currentPrice
                )
                list.toMutableList().apply {
                    set(existingIndex, updatedItem)
                }
            } else {
                list + item
            }
        }
        persistState()
    }

    fun updatePortfolioItem(updatedItem: PortfolioItem) {
        _portfolioItems.update { list ->
            list.map { if (it.id == updatedItem.id) updatedItem else it }
        }
        persistState()
    }

    fun deletePortfolioItem(id: String) {
        _portfolioItems.update { list ->
            list.filter { it.id != id }
        }
        persistState()
    }

    suspend fun refreshPortfolioPrices() {
        if (_isRefreshingPortfolio.value) return
        _isRefreshingPortfolio.value = true
        try {
            val currentList = _portfolioItems.value
            val updatedList = currentList.map { item ->
                val historical = yahooFinanceService.fetchPortfolioHistoricalPrices(
                    rawSymbol = item.ticker,
                    fallbackPrice = if (item.currentPrice > 0) item.currentPrice else item.averageBuyPrice
                )
                item.copy(
                    currentPrice = historical.currentPrice,
                    prevClosePrice = historical.prevClosePrice,
                    price7DaysAgo = historical.price7DaysAgo,
                    price1MonthAgo = historical.price1MonthAgo
                )
            }
            _portfolioItems.value = updatedList
            persistState()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            _isRefreshingPortfolio.value = false
        }
    }

    suspend fun searchApiEtfs(query: String): List<EtfItem> {
        if (query.isBlank()) return emptyList()
        val apiResults = yahooFinanceService.searchIndianEtfTickers(query)
        val currentWatchlistSymbols = _etfs.value.filter { it.isInWatchlist }.map { it.symbol }.toSet()

        return apiResults.map { item ->
            val existing = _etfs.value.find { it.symbol.equals(item.symbol, ignoreCase = true) }
            if (existing != null) {
                existing.copy(
                    currentPrice = if (item.currentPrice > 0) item.currentPrice else existing.currentPrice,
                    openPrice = if (item.openPrice > 0) item.openPrice else existing.openPrice
                )
            } else {
                item.copy(isInWatchlist = currentWatchlistSymbols.contains(item.symbol))
            }
        }
    }

    fun ensureItemInList(item: EtfItem) {
        _etfs.update { list ->
            if (list.none { it.symbol.equals(item.symbol, ignoreCase = true) }) {
                list + item
            } else list
        }
        persistState()
    }

    fun toggleWatchlist(symbol: String) {
        _etfs.update { list ->
            list.map { item ->
                if (item.symbol.equals(symbol, ignoreCase = true)) {
                    item.copy(isInWatchlist = !item.isInWatchlist)
                } else item
            }
        }
        persistState()
    }

    fun deleteFromWatchlist(symbol: String) {
        val ctx = appContext
        if (ctx != null) {
            LocalPreferencesManager.removeEtfAlertConfig(ctx, symbol)
        }
        _etfs.update { list ->
            list.map { item ->
                if (item.symbol.equals(symbol, ignoreCase = true)) {
                    item.copy(isInWatchlist = false, alertsEnabled = false)
                } else item
            }
        }
        persistState()
    }

    fun updateAlertConfiguration(
        symbol: String,
        targetDrops: List<Double>,
        baselineType: BasePriceType,
        alertsEnabled: Boolean
    ) {
        _etfs.update { list ->
            list.map { item ->
                if (item.symbol.equals(symbol, ignoreCase = true)) {
                    item.copy(
                        targetDropPercentages = targetDrops.sorted(),
                        baselineType = baselineType,
                        alertsEnabled = alertsEnabled
                    )
                } else item
            }
        }
        persistState()
    }

    fun simulatePriceDrop(symbol: String, dropPercent: Double) {
        _etfs.update { list ->
            list.map { item ->
                if (item.symbol.equals(symbol, ignoreCase = true)) {
                    val base = item.getBaselinePrice()
                    val newPrice = base * (1.0 - (dropPercent / 100.0))
                    val diff = newPrice - item.prevClose
                    val pct = if (item.prevClose > 0) (diff / item.prevClose) * 100 else 0.0
                    item.copy(
                        currentPrice = String.format("%.2f", newPrice).toDouble(),
                        changeAmount = String.format("%.2f", diff).toDouble(),
                        changePercent = String.format("%.2f", pct).toDouble()
                    )
                } else item
            }
        }
    }
}


