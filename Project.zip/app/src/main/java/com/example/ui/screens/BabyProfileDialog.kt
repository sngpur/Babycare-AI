package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChildCare
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.local.BabyProfile

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BabyProfileDialog(
    profile: BabyProfile?,
    onDismiss: () -> Unit,
    onSave: (name: String, birthDateMs: Long, gender: String, weightKg: Float, heightCm: Float) -> Unit
) {
    var name by remember(profile) { mutableStateOf(profile?.name ?: "Little One") }
    var gender by remember(profile) { mutableStateOf(profile?.gender ?: "Boy") }
    var weightStr by remember(profile) { mutableStateOf(profile?.weightKg?.toString() ?: "5.2") }
    var heightStr by remember(profile) { mutableStateOf(profile?.heightCm?.toString() ?: "58.0") }
    var ageMonthsStr by remember(profile) {
        val months = profile?.let {
            val diffMs = System.currentTimeMillis() - it.birthDateTimestamp
            (diffMs / (86400L * 1000L * 30L)).toInt().coerceAtLeast(0)
        } ?: 2
        mutableStateOf(months.toString())
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.ChildCare,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(end = 8.dp)
                )
                Text("Baby Profile Setup", style = MaterialTheme.typography.titleLarge)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    "Personalizing your baby's profile helps BabyCare AI tailor milestones, feeding tips, and age-specific guidance.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Baby's Name") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("profile_name_input")
                )

                Text("Gender", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Boy", "Girl", "Prefer not to say").forEach { g ->
                        FilterChip(
                            selected = gender == g,
                            onClick = { gender = g },
                            label = { Text(g) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                OutlinedTextField(
                    value = ageMonthsStr,
                    onValueChange = { ageMonthsStr = it },
                    label = { Text("Age in Months") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = weightStr,
                        onValueChange = { weightStr = it },
                        label = { Text("Weight (kg)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = heightStr,
                        onValueChange = { heightStr = it },
                        label = { Text("Length (cm)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val months = ageMonthsStr.toIntOrNull() ?: 2
                    val birthMs = System.currentTimeMillis() - (months.toLong() * 30L * 86400L * 1000L)
                    val w = weightStr.toFloatOrNull() ?: 5.0f
                    val h = heightStr.toFloatOrNull() ?: 58.0f
                    onSave(name, birthMs, gender, w, h)
                },
                modifier = Modifier.testTag("save_profile_button")
            ) {
                Text("Save Profile")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
