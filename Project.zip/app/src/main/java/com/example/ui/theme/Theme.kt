package com.example.ui.theme

import android.os.Build
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = SoftDarkPrimary,
    onPrimary = SoftDarkOnPrimary,
    primaryContainer = SoftDarkPrimaryContainer,
    onPrimaryContainer = SoftDarkOnPrimaryContainer,
    secondary = SoftDarkSecondary,
    onSecondary = SoftDarkOnSecondary,
    secondaryContainer = SoftDarkSecondaryContainer,
    onSecondaryContainer = SoftDarkOnSecondaryContainer,
    background = SoftDarkBackground,
    onBackground = SoftDarkOnBackground,
    surface = SoftDarkSurface,
    onSurface = SoftDarkOnSurface,
    surfaceVariant = SoftDarkSurfaceVariant,
    onSurfaceVariant = SoftDarkOnSurfaceVariant,
    outline = androidx.compose.ui.graphics.Color(0xFF49454F),
    outlineVariant = androidx.compose.ui.graphics.Color(0xFF3D3D3D)
  )

private val LightColorScheme =
  lightColorScheme(
    primary = LightPrimary,
    onPrimary = LightOnPrimary,
    primaryContainer = LightPrimaryContainer,
    onPrimaryContainer = LightOnPrimaryContainer,
    secondary = LightSecondary,
    onSecondary = LightOnSecondary,
    secondaryContainer = LightSecondaryContainer,
    onSecondaryContainer = LightOnSecondaryContainer,
    background = LightBackground,
    onBackground = LightOnBackground,
    surface = LightSurface,
    onSurface = LightOnSurface,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightOnSurfaceVariant,
    outline = androidx.compose.ui.graphics.Color(0xFF79747E),
    outlineVariant = androidx.compose.ui.graphics.Color(0xFFE0E2E5)
  )

@Composable
fun BabyCareTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val targetColorScheme = when {
    dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
      val context = LocalContext.current
      if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    }
    darkTheme -> DarkColorScheme
    else -> LightColorScheme
  }

  val animSpec = tween<Color>(durationMillis = 350, easing = LinearOutSlowInEasing)

  val animatedPrimary by animateColorAsState(targetColorScheme.primary, animSpec, label = "p")
  val animatedOnPrimary by animateColorAsState(targetColorScheme.onPrimary, animSpec, label = "op")
  val animatedPrimaryContainer by animateColorAsState(targetColorScheme.primaryContainer, animSpec, label = "pc")
  val animatedOnPrimaryContainer by animateColorAsState(targetColorScheme.onPrimaryContainer, animSpec, label = "opc")
  val animatedSecondary by animateColorAsState(targetColorScheme.secondary, animSpec, label = "s")
  val animatedOnSecondary by animateColorAsState(targetColorScheme.onSecondary, animSpec, label = "os")
  val animatedSecondaryContainer by animateColorAsState(targetColorScheme.secondaryContainer, animSpec, label = "sc")
  val animatedOnSecondaryContainer by animateColorAsState(targetColorScheme.onSecondaryContainer, animSpec, label = "osc")
  val animatedBackground by animateColorAsState(targetColorScheme.background, animSpec, label = "bg")
  val animatedOnBackground by animateColorAsState(targetColorScheme.onBackground, animSpec, label = "obg")
  val animatedSurface by animateColorAsState(targetColorScheme.surface, animSpec, label = "sf")
  val animatedOnSurface by animateColorAsState(targetColorScheme.onSurface, animSpec, label = "osf")
  val animatedSurfaceVariant by animateColorAsState(targetColorScheme.surfaceVariant, animSpec, label = "sfv")
  val animatedOnSurfaceVariant by animateColorAsState(targetColorScheme.onSurfaceVariant, animSpec, label = "osfv")
  val animatedOutline by animateColorAsState(targetColorScheme.outline, animSpec, label = "ot")
  val animatedOutlineVariant by animateColorAsState(targetColorScheme.outlineVariant, animSpec, label = "otv")

  val animatedColorScheme = targetColorScheme.copy(
    primary = animatedPrimary,
    onPrimary = animatedOnPrimary,
    primaryContainer = animatedPrimaryContainer,
    onPrimaryContainer = animatedOnPrimaryContainer,
    secondary = animatedSecondary,
    onSecondary = animatedOnSecondary,
    secondaryContainer = animatedSecondaryContainer,
    onSecondaryContainer = animatedOnSecondaryContainer,
    background = animatedBackground,
    onBackground = animatedOnBackground,
    surface = animatedSurface,
    onSurface = animatedOnSurface,
    surfaceVariant = animatedSurfaceVariant,
    onSurfaceVariant = animatedOnSurfaceVariant,
    outline = animatedOutline,
    outlineVariant = animatedOutlineVariant
  )

  MaterialTheme(colorScheme = animatedColorScheme, typography = Typography, content = content)
}

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  BabyCareTheme(darkTheme = darkTheme, dynamicColor = dynamicColor, content = content)
}

