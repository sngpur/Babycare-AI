package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.local.BabyProfile
import com.example.data.local.CareLogEntry
import com.example.data.local.LogType
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CareLogScreen(
    careLogs: List<CareLogEntry>,
    selectedFilter: LogType?,
    profile: BabyProfile?,
    onSetFilter: (LogType?) -> Unit,
    onAddLog: (LogType, String, String, String) -> Unit,
    onDeleteLog: (CareLogEntry) -> Unit
) {
    var showAddDialog by remember { mutableStateOf(false) }
    var selectedTypeForDialog by remember { mutableStateOf(LogType.FEEDING) }

    val filteredLogs = remember(careLogs, selectedFilter) {
        if (selectedFilter == null) careLogs else careLogs.filter { it.logType == selectedFilter }
    }

    // Daily stats calculations (logs within last 24 hours)
    val now = System.currentTimeMillis()
    val past24h = now - (24 * 60 * 60 * 1000L)
    val recentLogs = remember(careLogs) { careLogs.filter { it.timestamp >= past24h } }

    val feedingCount = remember(recentLogs) { recentLogs.count { it.logType == LogType.FEEDING } }
    val sleepCount = remember(recentLogs) { recentLogs.count { it.logType == LogType.SLEEP } }
    val diaperCount = remember(recentLogs) { recentLogs.count { it.logType == LogType.DIAPER } }

    val babyName = profile?.name ?: "Baby"

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    selectedTypeForDialog = LogType.FEEDING
                    showAddDialog = true
                },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Quick Log") },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("add_log_fab")
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Header Stats Banner
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                shape = RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "$babyName's Daily Care Tracker",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        "Last 24 hours activity summary",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StatCard("Feedings", "$feedingCount sessions", Icons.Default.Restaurant, MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                        StatCard("Sleep", "$sleepCount naps", Icons.Default.NightsStay, MaterialTheme.colorScheme.secondary, Modifier.weight(1f))
                        StatCard("Diapers", "$diaperCount changes", Icons.Default.WaterDrop, MaterialTheme.colorScheme.tertiary, Modifier.weight(1f))
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Log Type Filter Chips
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        selected = selectedFilter == null,
                        onClick = { onSetFilter(null) },
                        label = { Text("All Logs") }
                    )
                }
                items(LogType.values()) { type ->
                    val isSelected = selectedFilter == type
                    FilterChip(
                        selected = isSelected,
                        onClick = { onSetFilter(type) },
                        label = { Text(type.name.lowercase().replaceFirstChar { it.uppercase() }) },
                        leadingIcon = {
                            Icon(
                                imageVector = getIconForLogType(type),
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Timeline List
            if (filteredLogs.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.EditCalendar,
                            contentDescription = null,
                            modifier = Modifier.size(48.dp),
                            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            "No care logs recorded yet",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Tap 'Quick Log' below to record feeding, sleep, diaper, or health updates.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    contentPadding = PaddingValues(bottom = 80.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredLogs, key = { it.id }) { log ->
                        CareLogItemCard(log = log, onDelete = { onDeleteLog(log) })
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddCareLogDialog(
            initialType = selectedTypeForDialog,
            onDismiss = { showAddDialog = false },
            onConfirm = { type, title, details, amount ->
                onAddLog(type, title, details, amount)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun StatCard(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, modifier: Modifier) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.12f)),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.2f)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.Start) {
            Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.height(6.dp))
            Text(value, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun CareLogItemCard(log: CareLogEntry, onDelete: () -> Unit) {
    val dateStr = remember(log.timestamp) {
        SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(Date(log.timestamp))
    }

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("care_log_card")
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = CircleShape,
                color = getColorForLogType(log.logType).copy(alpha = 0.15f),
                modifier = Modifier.size(42.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = getIconForLogType(log.logType),
                        contentDescription = null,
                        tint = getColorForLogType(log.logType)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = log.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    if (log.amountOrDuration.isNotBlank()) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer
                        ) {
                            Text(
                                text = log.amountOrDuration,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                if (log.details.isNotBlank()) {
                    Text(
                        text = log.details,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Text(
                    text = dateStr,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                )
            }

            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Default.DeleteOutline,
                    contentDescription = "Delete",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun AddCareLogDialog(
    initialType: LogType,
    onDismiss: () -> Unit,
    onConfirm: (LogType, String, String, String) -> Unit
) {
    var type by remember { mutableStateOf(initialType) }
    var title by remember { mutableStateOf("") }
    var amountOrDuration by remember { mutableStateOf("") }
    var details by remember { mutableStateOf("") }

    // Preset titles based on selected type
    val presetTitles = when (type) {
        LogType.FEEDING -> listOf("Breastfeeding", "Formula Bottle", "Solid Meal", "Water/Juice")
        LogType.SLEEP -> listOf("Nap Time", "Night Sleep", "Resting")
        LogType.DIAPER -> listOf("Wet Diaper", "Dirty Diaper", "Wet & Dirty", "Diaper Rash Check")
        LogType.GROWTH -> listOf("Weight Check", "Length Check", "Head Circumference")
        LogType.HEALTH -> listOf("Temperature Check", "Vaccination", "Vitamin Drop", "Medication")
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Log Care Activity") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Select Type", style = MaterialTheme.typography.labelMedium)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(LogType.values()) { t ->
                        FilterChip(
                            selected = type == t,
                            onClick = {
                                type = t
                                title = ""
                            },
                            label = { Text(t.name.lowercase().replaceFirstChar { it.uppercase() }) }
                        )
                    }
                }

                Text("Quick Preset Title", style = MaterialTheme.typography.labelMedium)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(presetTitles) { preset ->
                        FilterChip(
                            selected = title == preset,
                            onClick = { title = preset },
                            label = { Text(preset) }
                        )
                    }
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Activity Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = amountOrDuration,
                    onValueChange = { amountOrDuration = it },
                    label = { Text("Amount / Duration (e.g. 120 ml, 45m, 37.2°C)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = details,
                    onValueChange = { details = it },
                    label = { Text("Notes / Observations (Optional)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val finalTitle = title.ifBlank { type.name.lowercase().replaceFirstChar { it.uppercase() } }
                    onConfirm(type, finalTitle, details, amountOrDuration)
                },
                modifier = Modifier.testTag("confirm_add_log_button")
            ) {
                Text("Save Log")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

fun getIconForLogType(type: LogType) = when (type) {
    LogType.FEEDING -> Icons.Default.Restaurant
    LogType.SLEEP -> Icons.Default.NightsStay
    LogType.DIAPER -> Icons.Default.WaterDrop
    LogType.GROWTH -> Icons.Default.Straighten
    LogType.HEALTH -> Icons.Default.MedicalServices
}

@Composable
fun getColorForLogType(type: LogType) = when (type) {
    LogType.FEEDING -> MaterialTheme.colorScheme.primary
    LogType.SLEEP -> MaterialTheme.colorScheme.secondary
    LogType.DIAPER -> MaterialTheme.colorScheme.tertiary
    LogType.GROWTH -> MaterialTheme.colorScheme.error
    LogType.HEALTH -> MaterialTheme.colorScheme.outline
}
