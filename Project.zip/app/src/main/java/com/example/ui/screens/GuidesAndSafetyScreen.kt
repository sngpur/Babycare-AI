package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.BabyProfile

data class CareGuideArticle(
    val id: String,
    val title: String,
    val category: String, // "Nutrition", "Health & Safety", "Sleep", "Soothe & Calm", "Hygiene"
    val icon: ImageVector,
    val summary: String,
    val detailedContent: String,
    val keyTakeaways: List<String>
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GuidesAndSafetyScreen(
    profile: BabyProfile?,
    onAskAiAboutTopic: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<String?>(null) }
    var expandedArticleId by remember { mutableStateOf<String?>(null) }

    val categories = listOf("All", "Nutrition", "Health & Safety", "Sleep", "Soothe & Calm", "Hygiene")

    val articles = remember { getVerifiedCareGuides() }

    val filteredArticles = remember(searchQuery, selectedCategory) {
        articles.filter { article ->
            val matchesCategory = selectedCategory == null || selectedCategory == "All" || article.category == selectedCategory
            val matchesSearch = searchQuery.isBlank() ||
                    article.title.contains(searchQuery, ignoreCase = true) ||
                    article.summary.contains(searchQuery, ignoreCase = true) ||
                    article.category.contains(searchQuery, ignoreCase = true)
            matchesCategory && matchesSearch
        }
    }

    val babyName = profile?.name ?: "your baby"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Header Banner
        Surface(
            color = MaterialTheme.colorScheme.tertiaryContainer,
            contentColor = MaterialTheme.colorScheme.onTertiaryContainer,
            shape = RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.MenuBook,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            "Verified Infant Care Guides",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Evidence-based pediatric parenting & safety principles",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search guides (fever, solids, sleep)...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear")
                            }
                        }
                    },
                    shape = RoundedCornerShape(20.dp),
                    singleLine = true,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Category Filter Chips
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(categories) { cat ->
                val isSelected = (selectedCategory == null && cat == "All") || selectedCategory == cat
                FilterChip(
                    selected = isSelected,
                    onClick = { selectedCategory = if (cat == "All") null else cat },
                    label = { Text(cat) },
                    shape = RoundedCornerShape(16.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Articles List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(filteredArticles, key = { it.id }) { article ->
                val isExpanded = expandedArticleId == article.id
                CareGuideCardItem(
                    article = article,
                    isExpanded = isExpanded,
                    onToggleExpand = {
                        expandedArticleId = if (isExpanded) null else article.id
                    },
                    onAskAiMore = {
                        val prompt = "Tell me more detailed advice regarding ${article.title} for $babyName."
                        onAskAiAboutTopic(prompt)
                    }
                )
            }
        }
    }
}

@Composable
fun CareGuideCardItem(
    article: CareGuideArticle,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    onAskAiMore: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("care_guide_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggleExpand() }
            ) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.size(44.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = article.icon,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = article.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = article.category,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                IconButton(onClick = onToggleExpand) {
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = "Expand"
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = article.summary,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    Divider(color = MaterialTheme.colorScheme.outlineVariant)

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Key Guidelines:",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    article.keyTakeaways.forEach { takeaway ->
                        Row(
                            modifier = Modifier.padding(vertical = 3.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .size(16.dp)
                                    .padding(top = 2.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = takeaway,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = article.detailedContent,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Button(
                            onClick = onAskAiMore,
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Discuss with BabyCare AI")
                        }
                    }
                }
            }
        }
    }
}

fun getVerifiedCareGuides(): List<CareGuideArticle> = listOf(
    CareGuideArticle(
        id = "guide_fever",
        title = "Infant Fever & Health Warning Signs",
        category = "Health & Safety",
        icon = Icons.Default.Thermostat,
        summary = "Crucial temperature thresholds and when to seek emergency pediatric care.",
        keyTakeaways = listOf(
            "Rectal temperature of 38.0°C (100.4°F) or higher in infants under 3 months is a medical emergency.",
            "Always use a digital thermometer rectally for infants under 3 months for accuracy.",
            "Watch for dehydration signs: fewer than 4 wet diapers in 24 hours, dry lips, no tears."
        ),
        detailedContent = "Fever is the body's natural immune response to infection. However, in newborns and young infants, immune systems are still immature. For infants 3-6 months, call your doctor if fever exceeds 38.3°C (101°F) or lasts longer than 24 hours. Never administer aspirin or over-the-counter cold medicines to infants."
    ),
    CareGuideArticle(
        id = "guide_solids",
        title = "Baby Diet Guide, Recipes & Choking Safety",
        category = "Nutrition",
        icon = Icons.Default.Restaurant,
        summary = "Age-appropriate food suggestions, simple purees, allergy rules, and choking hazard prevention.",
        keyTakeaways = listOf(
            "3-5 Day Allergy Rule: Introduce ONLY one new food item at a time, waiting 3-5 days before trying another to monitor for allergies.",
            "Choking Hazard Warning: Avoid whole grapes, whole nuts, raw hard carrots, popcorn, hard candies, and thick nut butter.",
            "Simple Recipes: Steamed Sweet Potato Puree (6m+) or Moong Dal Mashed Khichdi (8m+)."
        ),
        detailedContent = "Breastmilk or formula remains the primary source of nutrition during the first year. When starting solids around 6 months, introduce single-ingredient purees (sweet potato, avocado, banana). Always wait 3 to 5 days between introducing new foods to watch for reactions (rash, vomiting, diarrhea, breathing trouble). Always cut round foods like grapes lengthwise into thin quarters to prevent choking. Avoid honey before 12 months."
    ),
    CareGuideArticle(
        id = "guide_sleep",
        title = "Sleep Routine, Nap Schedules & Healthy Habits",
        category = "Sleep & Rest",
        icon = Icons.Default.NightsStay,
        summary = "Age-appropriate nap schedules, wake windows, and bedtime habits for infants and toddlers.",
        keyTakeaways = listOf(
            "0-3 Months: 14-17 hrs total sleep, 4-5 naps, short 60-90 min wake windows.",
            "4-11 Months: 12-15 hrs total sleep, 2-4 naps daily, 1.5-3.5 hr wake windows.",
            "12-24 Months: 11-14 hrs total sleep, 1-2 naps daily, 4-5.5 hr wake windows.",
            "Bedtime Routine: Predictable 20-min wind-down (bath, book, lullaby, lights out) between 7:00-8:00 PM."
        ),
        detailedContent = "Healthy infant and toddler sleep relies on honoring age-specific wake windows to prevent overtiredness. Put baby down 'drowsy but awake' so they learn self-soothing skills. Maintain a consistent safe sleep environment (Always on back, alone in crib, firm mattress, cool 20-22°C temperature, and continuous white noise)."
    ),
    CareGuideArticle(
        id = "guide_colic",
        title = "Gentle Calming Techniques & Peaceful Sleep Environment",
        category = "Soothe & Calm",
        icon = Icons.Default.ChildCare,
        summary = "Safe, relaxing methods to settle infants for rest and guide parents on creating a calm sleep space.",
        keyTakeaways = listOf(
            "The 5-S Soothing Method: Swaddle, Side/Stomach hold while calming, Shush/White Noise, Rhythmic Sway, Pacifier Suck.",
            "Peaceful Sleep Environment: Dim warm lighting 30 mins before bed, cool room temperature (20-22°C), continuous pink/white noise.",
            "Relaxing Wind-Down: Warm bath, downward infant massage strokes, soft lullabies, and placing baby down drowsy but awake."
        ),
        detailedContent = "Helping infants settle down for rest requires a predictable, sensory-soothing transition from active play to quiet sleep. Start wind-down 20-30 minutes before bedtime with dim lighting, a warm bath, and gentle downward strokes during an infant massage. Use continuous pink or white noise to mask household ambient noise. When fussy, employ gentle calming techniques like swaddling, rhythmic swaying, or rhythmic shushing near the ear. Always ensure a peaceful sleep environment with a firm mattress, no loose crib items, and a cool room temperature (20-22°C / 68-72°F) before placing baby on their back once calm."
    ),
    CareGuideArticle(
        id = "guide_hygiene",
        title = "Newborn Bathing & Cord Care",
        category = "Hygiene",
        icon = Icons.Default.CleanHands,
        summary = "Gentle skin care, umbilical cord hygiene, and bath safety.",
        keyTakeaways = listOf(
            "Sponge bath only until the umbilical cord stump falls off (1-3 weeks).",
            "Keep umbilical cord dry and exposed to air; do not rub with alcohol.",
            "Water temperature should be warm (~37°C / 98.6°F); never leave baby unattended."
        ),
        detailedContent = "Newborns do not need daily full baths; 2-3 times a week is sufficient to prevent drying out delicate skin. Pat dry gently in skin folds (neck, armpits, diaper area) and apply fragrance-free barrier ointment for diaper rash protection."
    ),
    CareGuideArticle(
        id = "guide_vaccination",
        title = "Standard Immunization Schedule & Guidance",
        category = "Health & Safety",
        icon = Icons.Default.Vaccines,
        summary = "General knowledge about standard infant vaccine milestones and pediatric advice.",
        keyTakeaways = listOf(
            "Vaccines protect infants against life-threatening childhood diseases like Polio, DTP, Measles, and Hepatitis.",
            "Common schedules include birth vaccines (BCG, HepB, OPV) and primary series at 6, 10, and 14 weeks.",
            "Always verify exact dates and available vaccines with your local health center or pediatrician."
        ),
        detailedContent = "Immunizations prepare your baby's immune system to fight serious infections. Minor side effects like low-grade fever or mild soreness at the injection site are normal and usually subside within 24-48 hours. Always verify exact dates and local brand availability with your pediatrician or health center."
    )
)
