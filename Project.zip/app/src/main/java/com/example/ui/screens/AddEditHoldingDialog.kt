package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.AssetType
import com.example.data.model.PortfolioItem
import com.example.ui.theme.NegativeRed
import java.util.UUID

@Composable
fun AddEditHoldingDialog(
    itemToEdit: PortfolioItem? = null,
    onDismiss: () -> Unit,
    onSave: (PortfolioItem) -> Unit
) {
    var selectedType by remember { mutableStateOf(itemToEdit?.type ?: AssetType.STOCK_OR_ETF) }
    var ticker by remember { mutableStateOf(itemToEdit?.ticker ?: "") }
    var name by remember { mutableStateOf(itemToEdit?.name ?: "") }
    var quantityInput by remember { mutableStateOf(itemToEdit?.totalQuantity?.toString() ?: "") }
    var buyPriceInput by remember { mutableStateOf(itemToEdit?.averageBuyPrice?.toString() ?: "") }
    var currentPriceInput by remember { mutableStateOf(itemToEdit?.currentPrice?.toString() ?: "") }

    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (itemToEdit == null) "Add New Holding" else "Edit Holding",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Asset Type",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedType == AssetType.STOCK_OR_ETF,
                        onClick = { selectedType = AssetType.STOCK_OR_ETF },
                        label = { Text("Stock / ETF") },
                        modifier = Modifier.testTag("asset_type_stock_etf")
                    )
                    FilterChip(
                        selected = selectedType == AssetType.MUTUAL_FUND,
                        onClick = { selectedType = AssetType.MUTUAL_FUND },
                        label = { Text("Mutual Fund") },
                        modifier = Modifier.testTag("asset_type_mutual_fund")
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = ticker,
                    onValueChange = {
                        ticker = it.uppercase()
                        errorMessage = null
                    },
                    label = { Text("Ticker / Symbol (e.g. NIFTYBEES)") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_holding_ticker")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        errorMessage = null
                    },
                    label = { Text("Asset Name (e.g. Nippon India Nifty 50 BeES)") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_holding_name")
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = quantityInput,
                        onValueChange = {
                            quantityInput = it
                            errorMessage = null
                        },
                        label = { Text("Quantity / Units") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_holding_quantity")
                    )

                    OutlinedTextField(
                        value = buyPriceInput,
                        onValueChange = {
                            buyPriceInput = it
                            errorMessage = null
                        },
                        label = { Text("Avg Buy Price (₹)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_holding_buy_price")
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = currentPriceInput,
                    onValueChange = {
                        currentPriceInput = it
                        errorMessage = null
                    },
                    label = { Text("Current Market Price (₹)") },
                    placeholder = { Text("Optional (defaults to buy price)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_holding_current_price")
                )

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = errorMessage!!,
                        style = MaterialTheme.typography.labelMedium,
                        color = NegativeRed
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val cleanTicker = ticker.trim()
                    val cleanName = name.trim()
                    val parsedQty = quantityInput.toDoubleOrNull()
                    val parsedBuyPrice = buyPriceInput.toDoubleOrNull()
                    val parsedCurrentPrice = currentPriceInput.toDoubleOrNull() ?: parsedBuyPrice

                    if (cleanTicker.isBlank()) {
                        errorMessage = "Please enter a ticker symbol"
                        return@Button
                    }
                    if (cleanName.isBlank()) {
                        errorMessage = "Please enter an asset name"
                        return@Button
                    }
                    if (parsedQty == null || parsedQty <= 0) {
                        errorMessage = "Please enter a valid quantity > 0"
                        return@Button
                    }
                    if (parsedBuyPrice == null || parsedBuyPrice <= 0) {
                        errorMessage = "Please enter a valid buy price > 0"
                        return@Button
                    }

                    val finalItem = PortfolioItem(
                        id = itemToEdit?.id ?: UUID.randomUUID().toString(),
                        type = selectedType,
                        ticker = cleanTicker,
                        name = cleanName,
                        totalQuantity = parsedQty,
                        averageBuyPrice = parsedBuyPrice,
                        currentPrice = parsedCurrentPrice ?: parsedBuyPrice
                    )

                    onSave(finalItem)
                },
                modifier = Modifier.testTag("save_holding_button")
            ) {
                Text(if (itemToEdit == null) "Add Holding" else "Save Changes")
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_holding_button")
            ) {
                Text("Cancel")
            }
        },
        modifier = Modifier.testTag("add_edit_holding_dialog")
    )
}
