package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.BasePriceType
import com.example.data.model.EtfItem
import com.example.data.model.MarketIndex
import com.example.data.model.PortfolioItem
import com.example.data.repository.EtfRepository
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(FlowPreview::class)
class EtfViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val repository = EtfRepository(context = application)

    val allEtfs: StateFlow<List<EtfItem>> = repository.etfs
    val marketIndices: StateFlow<List<MarketIndex>> = repository.indices
    val portfolioItems: StateFlow<List<PortfolioItem>> = repository.portfolioItems
    val isRefreshingPortfolio: StateFlow<Boolean> = repository.isRefreshingPortfolio
    val isWebSocketConnected: StateFlow<Boolean> = repository.isWebSocketConnected

    val currentUser = repository.currentUser
    val syncState = repository.syncState
    val lastSyncedTimestamp = repository.lastSyncedTimestamp
    val syncStatusMessage = repository.syncStatusMessage

    val portfolioSummary: StateFlow<PortfolioSummaryMetrics> = portfolioItems
        .combine(MutableStateFlow(Unit)) { items, _ ->
            val totalInvested = items.sumOf { it.investedAmount }
            val currentAmount = items.sumOf { it.currentAmount }
            val allTimePnL = currentAmount - totalInvested
            val allTimePnLPercent = if (totalInvested > 0) (allTimePnL / totalInvested) * 100.0 else 0.0

            val oneDayPnL = items.sumOf { it.oneDayPnL }
            val totalPrevCloseVal = items.sumOf { it.totalQuantity * (if (it.prevClosePrice > 0) it.prevClosePrice else it.currentPrice) }
            val oneDayPnLPercent = if (totalPrevCloseVal > 0) (oneDayPnL / totalPrevCloseVal) * 100.0 else 0.0

            val sevenDayPnL = items.sumOf { it.sevenDayPnL }
            val total7DayVal = items.sumOf { it.totalQuantity * (if (it.price7DaysAgo > 0) it.price7DaysAgo else it.currentPrice) }
            val sevenDayPnLPercent = if (total7DayVal > 0) (sevenDayPnL / total7DayVal) * 100.0 else 0.0

            val oneMonthPnL = items.sumOf { it.oneMonthPnL }
            val total1MonthVal = items.sumOf { it.totalQuantity * (if (it.price1MonthAgo > 0) it.price1MonthAgo else it.currentPrice) }
            val oneMonthPnLPercent = if (total1MonthVal > 0) (oneMonthPnL / total1MonthVal) * 100.0 else 0.0

            PortfolioSummaryMetrics(
                totalInvested = totalInvested,
                currentAmount = currentAmount,
                allTimePnL = allTimePnL,
                allTimePnLPercent = allTimePnLPercent,
                oneDayPnL = oneDayPnL,
                oneDayPnLPercent = oneDayPnLPercent,
                sevenDayPnL = sevenDayPnL,
                sevenDayPnLPercent = sevenDayPnLPercent,
                oneMonthPnL = oneMonthPnL,
                oneMonthPnLPercent = oneMonthPnLPercent
            )
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = PortfolioSummaryMetrics()
        )

    val watchlistEtfs: StateFlow<List<EtfItem>> = repository.etfs
        .combine(MutableStateFlow(Unit)) { list, _ ->
            list.filter { it.isInWatchlist }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    private val _apiSearchResults = MutableStateFlow<List<EtfItem>>(emptyList())

    init {
        refreshPortfolioPrices()
        // Observe search query with debounce to fetch real API results from Yahoo Finance
        viewModelScope.launch {
            _searchQuery
                .debounce(300)
                .collect { query ->
                    if (query.isNotBlank()) {
                        _isSearching.value = true
                        try {
                            val liveResults = repository.searchApiEtfs(query)
                            _apiSearchResults.value = liveResults
                        } catch (e: Exception) {
                            e.printStackTrace()
                            _apiSearchResults.value = emptyList()
                        } finally {
                            _isSearching.value = false
                        }
                    } else {
                        _apiSearchResults.value = emptyList()
                        _isSearching.value = false
                    }
                }
        }
    }

    val searchResults: StateFlow<List<EtfItem>> = combine(
        allEtfs,
        _searchQuery,
        _selectedCategory,
        _apiSearchResults
    ) { list, query, category, apiResults ->
        val localFiltered = list.filter { item ->
            val matchesQuery = query.isBlank() ||
                    item.symbol.contains(query, ignoreCase = true) ||
                    item.name.contains(query, ignoreCase = true)
            val matchesCategory = category == "All" || item.category == category
            matchesQuery && matchesCategory
        }

        val combinedMap = LinkedHashMap<String, EtfItem>()
        // First add API search results (which contain live Open & Current prices)
        apiResults.forEach { item ->
            if (category == "All" || item.category == category) {
                combinedMap[item.symbol.uppercase()] = item
            }
        }
        // Merge local catalog results if not present
        localFiltered.forEach { item ->
            if (!combinedMap.containsKey(item.symbol.uppercase())) {
                combinedMap[item.symbol.uppercase()] = item
            }
        }

        combinedMap.values.toList()
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // State for the Alert Configuration Screen/Modal
    private val _selectedEtfForAlert = MutableStateFlow<EtfItem?>(null)
    val selectedEtfForAlert: StateFlow<EtfItem?> = _selectedEtfForAlert.asStateFlow()

    // Temporary alert editing state while bottom sheet is active
    private val _editingTargetDrops = MutableStateFlow<List<Double>>(emptyList())
    val editingTargetDrops: StateFlow<List<Double>> = _editingTargetDrops.asStateFlow()

    private val _editingBaselineType = MutableStateFlow(BasePriceType.OPEN)
    val editingBaselineType: StateFlow<BasePriceType> = _editingBaselineType.asStateFlow()

    private val _editingAlertsEnabled = MutableStateFlow(true)
    val editingAlertsEnabled: StateFlow<Boolean> = _editingAlertsEnabled.asStateFlow()

    fun onSearchQueryChange(newQuery: String) {
        _searchQuery.value = newQuery
    }

    fun onCategorySelect(category: String) {
        _selectedCategory.value = category
    }

    private val _isEditMode = MutableStateFlow(false)
    val isEditMode: StateFlow<Boolean> = _isEditMode.asStateFlow()

    private val _itemPendingDelete = MutableStateFlow<EtfItem?>(null)
    val itemPendingDelete: StateFlow<EtfItem?> = _itemPendingDelete.asStateFlow()

    fun toggleEditMode() {
        _isEditMode.value = !_isEditMode.value
    }

    fun requestDeleteEtf(item: EtfItem) {
        _itemPendingDelete.value = item
    }

    fun cancelDelete() {
        _itemPendingDelete.value = null
    }

    fun confirmDelete() {
        val item = _itemPendingDelete.value ?: return
        repository.deleteFromWatchlist(item.symbol)
        _itemPendingDelete.value = null
    }

    fun toggleWatchlist(symbol: String) {
        val foundItem = searchResults.value.find { it.symbol.equals(symbol, ignoreCase = true) }
        if (foundItem != null) {
            repository.ensureItemInList(foundItem)
        }
        repository.toggleWatchlist(symbol)
    }

    fun openAlertConfig(etf: EtfItem) {
        repository.ensureItemInList(etf)
        _selectedEtfForAlert.value = etf
        _editingTargetDrops.value = etf.targetDropPercentages
        _editingBaselineType.value = etf.baselineType
        _editingAlertsEnabled.value = etf.alertsEnabled
    }

    fun closeAlertConfig() {
        _selectedEtfForAlert.value = null
    }

    fun addTargetDropPercentage(percentage: Double) {
        if (percentage <= 0.0) return
        val current = _editingTargetDrops.value.toMutableList()
        if (!current.contains(percentage)) {
            current.add(percentage)
            val sortedList = current.sorted()
            _editingTargetDrops.value = sortedList
            syncAlertConfigToRepository(sortedList = sortedList)
        }
    }

    fun removeTargetDropPercentage(percentage: Double) {
        val current = _editingTargetDrops.value.toMutableList()
        if (current.remove(percentage)) {
            _editingTargetDrops.value = current
            syncAlertConfigToRepository(sortedList = current)
        }
    }

    fun updateTargetDropPercentage(oldValue: Double, newValue: Double) {
        if (newValue <= 0.0) return
        val current = _editingTargetDrops.value.toMutableList()
        val index = current.indexOf(oldValue)
        if (index != -1) {
            current[index] = newValue
            val sortedList = current.distinct().sorted()
            _editingTargetDrops.value = sortedList
            syncAlertConfigToRepository(sortedList = sortedList)
        }
    }

    fun setBaselineType(basePriceType: BasePriceType) {
        _editingBaselineType.value = basePriceType
        syncAlertConfigToRepository(baseline = basePriceType)
    }

    fun setAlertsEnabled(enabled: Boolean) {
        _editingAlertsEnabled.value = enabled
        syncAlertConfigToRepository(enabled = enabled)
    }

    private fun syncAlertConfigToRepository(
        sortedList: List<Double> = _editingTargetDrops.value,
        baseline: BasePriceType = _editingBaselineType.value,
        enabled: Boolean = _editingAlertsEnabled.value
    ) {
        val etf = _selectedEtfForAlert.value ?: return
        repository.ensureItemInList(etf)
        repository.updateAlertConfiguration(
            symbol = etf.symbol,
            targetDrops = sortedList,
            baselineType = baseline,
            alertsEnabled = enabled
        )
        if (!etf.isInWatchlist && sortedList.isNotEmpty()) {
            repository.toggleWatchlist(etf.symbol)
        }
    }

    fun saveAlertConfig() {
        val etf = _selectedEtfForAlert.value ?: return
        repository.ensureItemInList(etf)
        repository.updateAlertConfiguration(
            symbol = etf.symbol,
            targetDrops = _editingTargetDrops.value,
            baselineType = _editingBaselineType.value,
            alertsEnabled = _editingAlertsEnabled.value
        )
        // If not already in watchlist, automatically add it when user saves an alert
        if (!etf.isInWatchlist) {
            repository.toggleWatchlist(etf.symbol)
        }
        closeAlertConfig()
    }

    private val _triggeredAlertsLog = MutableStateFlow<List<String>>(emptyList())
    val triggeredAlertsLog: StateFlow<List<String>> = _triggeredAlertsLog.asStateFlow()

    /**
     * Triggers an alert when the current percentage drop from Today's Open Price
     * crosses any of the user-defined thresholds.
     */
    fun triggerAlert(ticker: String, dropPercentage: Double) {
        val alertMessage = "ALERT TRIGGERED: $ticker dropped -${String.format("%.2f", dropPercentage)}% from Today's Open Price!"
        android.util.Log.d("ETF_ALERT", alertMessage)
        
        val currentLog = _triggeredAlertsLog.value.toMutableList()
        if (!currentLog.contains(alertMessage)) {
            currentLog.add(0, alertMessage)
            _triggeredAlertsLog.value = currentLog.take(5)
        }
    }

    fun clearTriggeredAlertsLog() {
        _triggeredAlertsLog.value = emptyList()
    }

    fun simulatePriceDrop(symbol: String, dropPercent: Double) {
        repository.simulatePriceDrop(symbol, dropPercent)
        
        // Evaluate alerts for the updated instrument
        val updatedItem = repository.etfs.value.find { it.symbol.equals(symbol, ignoreCase = true) }
        if (updatedItem != null && updatedItem.alertsEnabled) {
            val dropFromOpen = updatedItem.calculatePercentageDropFromOpen()
            for (threshold in updatedItem.targetDropPercentages) {
                if (dropFromOpen >= threshold || updatedItem.isDropTriggered(threshold)) {
                    triggerAlert(updatedItem.symbol, threshold)
                }
            }
        }
    }

    fun addPortfolioItem(item: PortfolioItem) {
        repository.addPortfolioItem(item)
        refreshPortfolioPrices()
    }

    fun updatePortfolioItem(item: PortfolioItem) {
        repository.updatePortfolioItem(item)
        refreshPortfolioPrices()
    }

    fun deletePortfolioItem(id: String) {
        repository.deletePortfolioItem(id)
    }

    fun refreshPortfolioPrices() {
        viewModelScope.launch {
            repository.refreshPortfolioPrices()
        }
    }

    fun signInAccount(email: String, name: String) {
        repository.signInAccount(email, name)
    }

    fun signOutAccount() {
        repository.signOutAccount()
    }

    fun triggerManualCloudSync() {
        repository.triggerManualCloudSync()
    }
}

data class PortfolioSummaryMetrics(
    val totalInvested: Double = 0.0,
    val currentAmount: Double = 0.0,
    val allTimePnL: Double = 0.0,
    val allTimePnLPercent: Double = 0.0,
    val oneDayPnL: Double = 0.0,
    val oneDayPnLPercent: Double = 0.0,
    val sevenDayPnL: Double = 0.0,
    val sevenDayPnLPercent: Double = 0.0,
    val oneMonthPnL: Double = 0.0,
    val oneMonthPnLPercent: Double = 0.0
)


