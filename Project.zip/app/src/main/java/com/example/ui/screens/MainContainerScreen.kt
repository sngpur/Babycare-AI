package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.viewmodels.BabyCareViewModel

enum class NavigationTab(val title: String, val selectedIcon: ImageVector, val unselectedIcon: ImageVector) {
    CHAT("AI Assistant", Icons.Default.AutoAwesome, Icons.Outlined.AutoAwesome),
    MILESTONES("Milestones", Icons.Default.Stars, Icons.Outlined.Stars),
    LOG("Care Log", Icons.Default.EditCalendar, Icons.Outlined.EditCalendar),
    GUIDES("Guides & Safety", Icons.Default.HealthAndSafety, Icons.Outlined.HealthAndSafety)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainContainerScreen(viewModel: BabyCareViewModel) {
    var selectedTab by remember { mutableStateOf(NavigationTab.CHAT) }
    var showProfileDialog by remember { mutableStateOf(false) }
    var showHistorySheet by remember { mutableStateOf(false) }

    val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
    val profile by viewModel.profile.collectAsStateWithLifecycle()
    val messages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val isThinking by viewModel.isAiThinking.collectAsStateWithLifecycle()
    val careLogs by viewModel.careLogs.collectAsStateWithLifecycle()
    val milestones by viewModel.milestones.collectAsStateWithLifecycle()
    val selectedAgeGroup by viewModel.selectedMilestoneAge.collectAsStateWithLifecycle()
    val selectedLogFilter by viewModel.selectedLogFilter.collectAsStateWithLifecycle()

    val babyName = profile?.name ?: "Little One"
    val babyAgeText = remember(profile?.birthDateTimestamp) {
        if (profile == null) "2m"
        else {
            val diffMs = System.currentTimeMillis() - profile!!.birthDateTimestamp
            val days = (diffMs / (86400L * 1000L)).toInt().coerceAtLeast(0)
            val months = days / 30
            val remDays = days % 30
            if (months > 0) "${months}m ${remDays}d" else "${days}d"
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "BabyCare AI",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        // Baby Profile Quick Pill Button
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier
                                .clickable { showProfileDialog = true }
                                .testTag("profile_pill_button")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ChildCare,
                                    contentDescription = "Profile",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    "$babyName ($babyAgeText)",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showHistorySheet = true },
                        modifier = Modifier.testTag("chat_history_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "Recent Chats & History",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    IconButton(
                        onClick = { viewModel.toggleDarkMode() },
                        modifier = Modifier.testTag("theme_toggle_button")
                    ) {
                        Icon(
                            imageVector = if (isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = if (isDarkMode) "Switch to Light Mode" else "Switch to Dark Mode",
                            tint = if (isDarkMode) androidx.compose.ui.graphics.Color(0xFFFFB74D) else MaterialTheme.colorScheme.primary
                        )
                    }

                    if (selectedTab == NavigationTab.CHAT) {
                        IconButton(
                            onClick = { viewModel.clearChat() },
                            modifier = Modifier.testTag("clear_chat_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteSweep,
                                contentDescription = "Clear Chat",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                windowInsets = WindowInsets.navigationBars
            ) {
                NavigationTab.values().forEach { tab ->
                    val isSelected = selectedTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { selectedTab = tab },
                        icon = {
                            Icon(
                                imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                contentDescription = tab.title
                            )
                        },
                        label = { Text(tab.title) },
                        modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                    )
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (selectedTab) {
                NavigationTab.CHAT -> ChatScreen(
                    messages = messages,
                    isThinking = isThinking,
                    profile = profile,
                    onSendMessage = { text -> viewModel.sendMessage(text) },
                    onToggleBookmark = { id, current -> viewModel.toggleBookmark(id, current) },
                    onClearChat = { viewModel.clearChat() },
                    onOpenHistory = { showHistorySheet = true }
                )

                NavigationTab.MILESTONES -> MilestonesScreen(
                    milestones = milestones,
                    selectedAgeGroup = selectedAgeGroup,
                    profile = profile,
                    onSelectAgeGroup = { ageGroup -> viewModel.setMilestoneAgeGroup(ageGroup) },
                    onToggleMilestone = { id, current -> viewModel.toggleMilestone(id, current) },
                    onAskAiAboutMilestone = { prompt ->
                        selectedTab = NavigationTab.CHAT
                        viewModel.sendMessage(prompt)
                    }
                )

                NavigationTab.LOG -> CareLogScreen(
                    careLogs = careLogs,
                    selectedFilter = selectedLogFilter,
                    profile = profile,
                    onSetFilter = { filter -> viewModel.setLogFilter(filter) },
                    onAddLog = { type, title, details, amount ->
                        viewModel.addCareLog(type, title, details, amount)
                    },
                    onDeleteLog = { entry -> viewModel.deleteCareLog(entry) }
                )

                NavigationTab.GUIDES -> GuidesAndSafetyScreen(
                    profile = profile,
                    onAskAiAboutTopic = { prompt ->
                        selectedTab = NavigationTab.CHAT
                        viewModel.sendMessage(prompt)
                    }
                )
            }
        }
    }

    if (showProfileDialog) {
        BabyProfileDialog(
            profile = profile,
            onDismiss = { showProfileDialog = false },
            onSave = { name, birthDateMs, gender, weightKg, heightCm ->
                viewModel.updateProfile(name, birthDateMs, gender, weightKg, heightCm)
                showProfileDialog = false
            }
        )
    }

    if (showHistorySheet) {
        ChatHistorySheet(
            messages = messages,
            onDismiss = { showHistorySheet = false },
            onToggleBookmark = { id, current -> viewModel.toggleBookmark(id, current) },
            onDeleteMessage = { id -> viewModel.deleteChatMessage(id) },
            onClearAllHistory = { viewModel.clearChat() },
            onSelectQueryToAsk = { query ->
                selectedTab = NavigationTab.CHAT
                viewModel.sendMessage(query)
            }
        )
    }
}
