package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.PriceCheck
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SheetState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BasePriceType
import com.example.data.model.EtfItem
import com.example.ui.theme.NegativeRed
import com.example.ui.theme.PositiveGreen

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AlertConfigBottomSheet(
    etf: EtfItem,
    targetDrops: List<Double>,
    baselineType: BasePriceType,
    alertsEnabled: Boolean,
    sheetState: SheetState,
    onDismiss: () -> Unit,
    onAddDropTarget: (Double) -> Unit,
    onEditDropTarget: (Double, Double) -> Unit = { _, _ -> },
    onRemoveDropTarget: (Double) -> Unit,
    onSetBaselineType: (BasePriceType) -> Unit,
    onSetAlertsEnabled: (Boolean) -> Unit,
    onSave: () -> Unit,
    modifier: Modifier = Modifier
) {
    var customPercentageInput by remember { mutableStateOf("") }
    var inputError by remember { mutableStateOf<String?>(null) }

    var editingAlertValue by remember { mutableStateOf<Double?>(null) }
    var editInputText by remember { mutableStateOf("") }
    var editInputError by remember { mutableStateOf<String?>(null) }

    if (editingAlertValue != null) {
        val oldValue = editingAlertValue!!
        AlertDialog(
            onDismissRequest = { editingAlertValue = null },
            title = {
                Text(
                    text = "Edit Drop Threshold %",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            },
            text = {
                Column {
                    Text(
                        text = "Modify target drop percentage for ${etf.symbol}:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = editInputText,
                        onValueChange = {
                            editInputText = it
                            editInputError = null
                        },
                        label = { Text("Target Drop Percentage") },
                        trailingIcon = { Text("%", modifier = Modifier.padding(end = 12.dp)) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        isError = editInputError != null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("edit_alert_input")
                    )
                    if (editInputError != null) {
                        Text(
                            text = editInputError!!,
                            style = MaterialTheme.typography.labelSmall,
                            color = NegativeRed,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val newDouble = editInputText.toDoubleOrNull()
                        if (newDouble != null && newDouble > 0.0) {
                            onEditDropTarget(oldValue, newDouble)
                            editingAlertValue = null
                        } else {
                            editInputError = "Enter valid percentage > 0"
                        }
                    },
                    modifier = Modifier.testTag("confirm_edit_alert_button")
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { editingAlertValue = null },
                    modifier = Modifier.testTag("cancel_edit_alert_button")
                ) {
                    Text("Cancel")
                }
            },
            modifier = Modifier.testTag("edit_alert_dialog")
        )
    }

    val presetPercentages = listOf(0.25, 0.50, 0.75, 1.00, 1.50, 2.00, 3.00, 5.00)

    val currentBaselinePrice = when (baselineType) {
        BasePriceType.OPEN -> etf.openPrice
        BasePriceType.DAY_HIGH -> etf.dayHigh
        BasePriceType.PREV_CLOSE -> etf.prevClose
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = modifier.testTag("alert_config_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .padding(10.dp)
                                .size(24.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "Configure Drop Alerts",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${etf.symbol} • ${etf.name}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1
                        )
                    }
                }
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Current Price & Baseline Banner
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Current Price",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "₹${String.format("%,.2f", etf.currentPrice)}",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "Reference Base (${baselineType.label})",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "₹${String.format("%,.2f", currentBaselinePrice)}",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Enable Alerts Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = if (alertsEnabled) Icons.Default.NotificationsActive else Icons.Default.NotificationsOff,
                        contentDescription = null,
                        tint = if (alertsEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Enable Percentage Drop Alerts",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                }
                Switch(
                    checked = alertsEnabled,
                    onCheckedChange = onSetAlertsEnabled,
                    modifier = Modifier.testTag("master_alert_switch")
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Baseline Price Selector
            Text(
                text = "1. SELECT BASELINE PRICE FOR DROPS",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                BasePriceType.values().forEach { type ->
                    val selected = baselineType == type
                    FilterChip(
                        selected = selected,
                        onClick = { onSetBaselineType(type) },
                        shape = RoundedCornerShape(50.dp),
                        label = {
                            Text(
                                text = type.label,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                )
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("baseline_chip_${type.name}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Multiple Target Percentage Drops Manager
            Text(
                text = "2. ADD MULTIPLE TARGET PERCENTAGE DROPS",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Quick Add Chips
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                presetPercentages.forEach { pct ->
                    val isAlreadyAdded = targetDrops.contains(pct)
                    OutlinedButton(
                        onClick = { onAddDropTarget(pct) },
                        enabled = !isAlreadyAdded,
                        shape = RoundedCornerShape(50.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                        modifier = Modifier.height(34.dp).testTag("preset_drop_chip_$pct")
                    ) {
                        Text(
                            text = "+ $pct%",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (isAlreadyAdded) FontWeight.Normal else FontWeight.Bold
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Custom Percentage Input
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = customPercentageInput,
                    onValueChange = {
                        customPercentageInput = it
                        inputError = null
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("custom_percentage_input"),
                    label = { Text("Custom Drop % (e.g., 0.35)") },
                    placeholder = { Text("0.35") },
                    trailingIcon = { Text("%", modifier = Modifier.padding(end = 12.dp)) },
                    shape = RoundedCornerShape(50.dp),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Decimal,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(onDone = {
                        val valDouble = customPercentageInput.toDoubleOrNull()
                        if (valDouble != null && valDouble > 0.0) {
                            onAddDropTarget(valDouble)
                            customPercentageInput = ""
                        } else {
                            inputError = "Enter valid positive percentage"
                        }
                    }),
                    isError = inputError != null,
                    singleLine = true
                )

                Button(
                    onClick = {
                        val valDouble = customPercentageInput.toDoubleOrNull()
                        if (valDouble != null && valDouble > 0.0) {
                            onAddDropTarget(valDouble)
                            customPercentageInput = ""
                        } else {
                            inputError = "Enter valid positive percentage"
                        }
                    },
                    shape = RoundedCornerShape(50.dp),
                    modifier = Modifier
                        .height(56.dp)
                        .testTag("add_custom_drop_button")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Add")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add")
                }
            }

            if (inputError != null) {
                Text(
                    text = inputError!!,
                    style = MaterialTheme.typography.labelSmall,
                    color = NegativeRed,
                    modifier = Modifier.padding(top = 4.dp, start = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Configured Targets List
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ACTIVE TARGET DROPS (${targetDrops.size})",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (targetDrops.isNotEmpty()) {
                    Text(
                        text = "Triggers when price ≤ target",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            if (targetDrops.isEmpty()) {
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "No drop target percentages added yet. Tap a quick preset above or type a custom percentage.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            } else {
                Column(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    targetDrops.forEach { dropPct ->
                        val triggerPrice = currentBaselinePrice * (1.0 - (dropPct / 100.0))
                        val isTriggered = etf.currentPrice <= triggerPrice

                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isTriggered && alertsEnabled) {
                                    NegativeRed.copy(alpha = 0.15f)
                                } else {
                                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                }
                            ),
                            border = if (isTriggered && alertsEnabled) androidx.compose.foundation.BorderStroke(1.dp, NegativeRed) else null,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = if (isTriggered && alertsEnabled) NegativeRed else MaterialTheme.colorScheme.primaryContainer
                                    ) {
                                        Text(
                                            text = "-${String.format("%.2f", dropPct)}%",
                                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                            color = if (isTriggered && alertsEnabled) Color.White else MaterialTheme.colorScheme.onPrimaryContainer,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }

                                    Column {
                                        Text(
                                            text = "Trigger at ₹${String.format("%,.2f", triggerPrice)}",
                                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = if (isTriggered && alertsEnabled) "STATUS: TRIGGERED! (Current: ₹${etf.currentPrice})" else "Status: Monitoring Live Price",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = if (isTriggered && alertsEnabled) NegativeRed else PositiveGreen
                                            )
                                        )
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = {
                                            editingAlertValue = dropPct
                                            editInputText = dropPct.toString()
                                            editInputError = null
                                        },
                                        modifier = Modifier.testTag("edit_drop_target_$dropPct")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Edit,
                                            contentDescription = "Edit Alert Value",
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }

                                    IconButton(
                                        onClick = { onRemoveDropTarget(dropPct) },
                                        modifier = Modifier.testTag("remove_drop_target_$dropPct")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DeleteOutline,
                                            contentDescription = "Remove Alert",
                                            tint = NegativeRed
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Save Actions
            Button(
                onClick = onSave,
                shape = RoundedCornerShape(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("save_alert_config_button")
            ) {
                Icon(imageVector = Icons.Default.Check, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Save Drop Alert Rules",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }
        }
    }
}
