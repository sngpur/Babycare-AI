package com.example.ui.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.*
import com.example.data.repository.BabyCareRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class BabyCareViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: BabyCareRepository

    val profile: StateFlow<BabyProfile?>
    val chatMessages: StateFlow<List<ChatMessage>>
    val careLogs: StateFlow<List<CareLogEntry>>
    val milestones: StateFlow<List<MilestoneEntry>>

    private val _isAiThinking = MutableStateFlow(false)
    val isAiThinking: StateFlow<Boolean> = _isAiThinking.asStateFlow()

    private val _isDarkMode = MutableStateFlow(false)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    private val _selectedMilestoneAge = MutableStateFlow("0-3 Months")
    val selectedMilestoneAge: StateFlow<String> = _selectedMilestoneAge.asStateFlow()

    private val _selectedLogFilter = MutableStateFlow<LogType?>(null)
    val selectedLogFilter: StateFlow<LogType?> = _selectedLogFilter.asStateFlow()

    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
    }

    init {
        val db = AppDatabase.getDatabase(application)
        repository = BabyCareRepository(db.babyCareDao())

        profile = repository.profileFlow.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), null
        )

        chatMessages = repository.chatMessagesFlow.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
        )

        careLogs = repository.careLogsFlow.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
        )

        milestones = repository.milestonesFlow.stateIn(
            viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
        )

        viewModelScope.launch {
            repository.initializeDefaultDataIfNeeded()
        }
    }

    fun sendMessage(text: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            _isAiThinking.value = true
            repository.sendChatMessage(text)
            _isAiThinking.value = false
        }
    }

    fun clearChat() {
        viewModelScope.launch {
            repository.clearChat()
        }
    }

    fun deleteChatMessage(messageId: Long) {
        viewModelScope.launch {
            repository.deleteChatMessage(messageId)
        }
    }

    fun toggleBookmark(messageId: Long, isBookmarked: Boolean) {
        viewModelScope.launch {
            repository.toggleBookmark(messageId, isBookmarked)
        }
    }

    fun addCareLog(type: LogType, title: String, details: String, amountOrDuration: String) {
        viewModelScope.launch {
            repository.addCareLog(type, title, details, amountOrDuration)
        }
    }

    fun deleteCareLog(entry: CareLogEntry) {
        viewModelScope.launch {
            repository.deleteCareLog(entry)
        }
    }

    fun toggleMilestone(milestoneId: Long, currentCompleted: Boolean) {
        viewModelScope.launch {
            repository.toggleMilestone(milestoneId, !currentCompleted)
        }
    }

    fun setMilestoneAgeGroup(group: String) {
        _selectedMilestoneAge.value = group
    }

    fun setLogFilter(filter: LogType?) {
        _selectedLogFilter.value = filter
    }

    fun updateProfile(name: String, birthDateMs: Long, gender: String, weightKg: Float, heightCm: Float) {
        viewModelScope.launch {
            repository.updateProfile(
                BabyProfile(
                    id = 1,
                    name = name.ifBlank { "Little One" },
                    birthDateTimestamp = birthDateMs,
                    gender = gender,
                    weightKg = weightKg,
                    heightCm = heightCm
                )
            )
        }
    }
}
