package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Mode Colors (Soft off-white background #F8F9FA, Charcoal text #202124)
val LightBackground = Color(0xFFF8F9FA)
val LightOnBackground = Color(0xFF202124)
val LightSurface = Color(0xFFFFFFFF)
val LightOnSurface = Color(0xFF202124)
val LightSurfaceVariant = Color(0xFFEFF1F3)
val LightOnSurfaceVariant = Color(0xFF44474E)

val LightPrimary = Color(0xFF6750A4)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFFEADDFF)
val LightOnPrimaryContainer = Color(0xFF21005D)

val LightSecondary = Color(0xFF0061A4)
val LightOnSecondary = Color(0xFFFFFFFF)
val LightSecondaryContainer = Color(0xFFD1E4FF)
val LightOnSecondaryContainer = Color(0xFF001D36)

// Dark Mode Colors (Deep dark gray #121212, Cards/Bubbles #2C2C2C, Soft white text #E8EAED)
val SoftDarkBackground = Color(0xFF121212)
val SoftDarkOnBackground = Color(0xFFE8EAED)
val SoftDarkSurface = Color(0xFF2C2C2C)
val SoftDarkOnSurface = Color(0xFFE8EAED)
val SoftDarkSurfaceVariant = Color(0xFF383838)
val SoftDarkOnSurfaceVariant = Color(0xFFE8EAED)

val SoftDarkPrimary = Color(0xFFD0BCFF)
val SoftDarkOnPrimary = Color(0xFF381E72)
val SoftDarkPrimaryContainer = Color(0xFF4F378B)
val SoftDarkOnPrimaryContainer = Color(0xFFE8EAED)

val SoftDarkSecondary = Color(0xFF9ECAFF)
val SoftDarkOnSecondary = Color(0xFF003258)
val SoftDarkSecondaryContainer = Color(0xFF00497D)
val SoftDarkOnSecondaryContainer = Color(0xFFD1E4FF)


