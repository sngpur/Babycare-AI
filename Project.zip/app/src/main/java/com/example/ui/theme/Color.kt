package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// High Density Theme Color Palette
val HighDensityPrimary = Color(0xFF005AC1)
val HighDensityPrimaryContainer = Color(0xFFD8E2FF)
val HighDensityOnPrimaryContainer = Color(0xFF001A41)

val HighDensityBackground = Color(0xFFFDFBFF)
val HighDensitySurface = Color(0xFFFFFFFF)
val HighDensitySurfaceVariant = Color(0xFFF1F0F4)
val HighDensityOutline = Color(0xFFE1E2EC)

val HighDensityTextPrimary = Color(0xFF1C1B1F)
val HighDensityTextSecondary = Color(0xFF44474E)

val PositiveGreen = Color(0xFF059669)
val PositiveGreenBg = Color(0xFFECFDF5)
val NegativeRed = Color(0xFFE11D48)
val NegativeRedBg = Color(0xFFFFE4E6)

val GoldAccent = Color(0xFFD4A000)
val GoldAccentBg = Color(0xFFFFF7D6)

// Dark Theme Variants
val DeepNavyDark = Color(0xFF0B132B)
val SlateSurfaceDark = Color(0xFF1C2541)
val SlateCardDark = Color(0xFF232F52)
val TextPrimaryDark = Color(0xFFFFFFFF)
val TextSecondaryDark = Color(0xFFA0AEC0)

