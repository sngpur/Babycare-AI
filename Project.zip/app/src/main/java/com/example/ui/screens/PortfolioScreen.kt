package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AssetType
import com.example.data.model.PortfolioItem
import com.example.ui.theme.NegativeRed
import com.example.ui.theme.NegativeRedBg
import com.example.ui.theme.PositiveGreen
import com.example.ui.theme.PositiveGreenBg
import com.example.ui.viewmodel.PortfolioSummaryMetrics

enum class PnLTimeframe {
    ALL_TIME,
    ONE_DAY,
    SEVEN_DAYS,
    ONE_MONTH
}

enum class DisplayViewOption(
    val label: String,
    val shortLabel: String,
    val description: String
) {
    CURRENT_INVESTED(
        label = "Current (Invested)",
        shortLabel = "Current Value",
        description = "Current market value & invested amount"
    ),
    RETURNS_PERCENT(
        label = "Returns (%)",
        shortLabel = "Total Returns",
        description = "Overall profit/loss amount & return percentage"
    ),
    MARKET_PRICE_1D(
        label = "Market Price (1D%)",
        shortLabel = "Price (1D%)",
        description = "Live market price & today's 1-day percentage change"
    ),
    ONE_DAY_PNL(
        label = "1D Profit/Loss (1D P&L %)",
        shortLabel = "1D P&L",
        description = "Today's profit/loss amount & 1-day % return"
    ),
    SEVEN_DAY_PNL(
        label = "Last 7 Market Days (7D P&L %)",
        shortLabel = "7D P&L",
        description = "Profit/loss over the past 7 market days"
    ),
    ONE_MONTH_PNL(
        label = "Last 1 Month (1M P&L %)",
        shortLabel = "1M P&L",
        description = "Profit/loss over the past 1 month"
    )
}

enum class PortfolioSortField(
    val label: String,
    val isAlphabetical: Boolean = false
) {
    PNL_PERCENT("P&L (%)"),
    PNL_AMOUNT("P&L (₹)"),
    LTP_PERCENT("LTP (%)"),
    LTP_AMOUNT("LTP (₹)"),
    INVESTED("Invested (₹)"),
    CURRENT_VALUE("Current (₹)"),
    ALPHABETICAL("Alphabetically", isAlphabetical = true)
}

enum class SortDirection {
    HIGH_TO_LOW, // or A -> Z
    LOW_TO_HIGH  // or Z -> A
}

data class PortfolioSortConfig(
    val field: PortfolioSortField = PortfolioSortField.PNL_PERCENT,
    val direction: SortDirection = SortDirection.HIGH_TO_LOW
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PortfolioScreen(
    portfolioItems: List<PortfolioItem> = emptyList(),
    portfolioSummary: PortfolioSummaryMetrics = PortfolioSummaryMetrics(),
    isRefreshing: Boolean = false,
    isWebSocketConnected: Boolean = true,
    onRefreshPortfolio: () -> Unit = {},
    onAddHolding: (PortfolioItem) -> Unit = {},
    onUpdateHolding: (PortfolioItem) -> Unit = {},
    onDeleteHolding: (String) -> Unit = {},
    onOpenCloudSync: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var selectedTabIndex by remember { mutableIntStateOf(0) } // 0: All, 1: Stocks & ETFs, 2: Mutual Funds
    var selectedTimeframe by remember { mutableStateOf(PnLTimeframe.ALL_TIME) }
    var selectedDisplayOption by remember { mutableStateOf(DisplayViewOption.RETURNS_PERCENT) }
    var showDisplayViewBottomSheet by remember { mutableStateOf(false) }

    var sortConfig by remember { mutableStateOf(PortfolioSortConfig()) }
    var showSortByBottomSheet by remember { mutableStateOf(false) }

    var showAddDialog by remember { mutableStateOf(false) }
    var itemToEdit by remember { mutableStateOf<PortfolioItem?>(null) }
    var itemPendingDelete by remember { mutableStateOf<PortfolioItem?>(null) }

    val filteredAndSortedItems = remember(portfolioItems, selectedTabIndex, sortConfig) {
        val categoryFiltered = when (selectedTabIndex) {
            1 -> portfolioItems.filter { it.type == AssetType.STOCK_OR_ETF }
            2 -> portfolioItems.filter { it.type == AssetType.MUTUAL_FUND }
            else -> portfolioItems
        }

        when (sortConfig.field) {
            PortfolioSortField.PNL_PERCENT -> {
                if (sortConfig.direction == SortDirection.HIGH_TO_LOW) {
                    categoryFiltered.sortedByDescending { it.profitLossPercent }
                } else {
                    categoryFiltered.sortedBy { it.profitLossPercent }
                }
            }
            PortfolioSortField.PNL_AMOUNT -> {
                if (sortConfig.direction == SortDirection.HIGH_TO_LOW) {
                    categoryFiltered.sortedByDescending { it.profitLoss }
                } else {
                    categoryFiltered.sortedBy { it.profitLoss }
                }
            }
            PortfolioSortField.LTP_PERCENT -> {
                if (sortConfig.direction == SortDirection.HIGH_TO_LOW) {
                    categoryFiltered.sortedByDescending { it.oneDayPnLPercent }
                } else {
                    categoryFiltered.sortedBy { it.oneDayPnLPercent }
                }
            }
            PortfolioSortField.LTP_AMOUNT -> {
                if (sortConfig.direction == SortDirection.HIGH_TO_LOW) {
                    categoryFiltered.sortedByDescending { it.currentPrice }
                } else {
                    categoryFiltered.sortedBy { it.currentPrice }
                }
            }
            PortfolioSortField.INVESTED -> {
                if (sortConfig.direction == SortDirection.HIGH_TO_LOW) {
                    categoryFiltered.sortedByDescending { it.investedAmount }
                } else {
                    categoryFiltered.sortedBy { it.investedAmount }
                }
            }
            PortfolioSortField.CURRENT_VALUE -> {
                if (sortConfig.direction == SortDirection.HIGH_TO_LOW) {
                    categoryFiltered.sortedByDescending { it.currentAmount }
                } else {
                    categoryFiltered.sortedBy { it.currentAmount }
                }
            }
            PortfolioSortField.ALPHABETICAL -> {
                if (sortConfig.direction == SortDirection.HIGH_TO_LOW) {
                    categoryFiltered.sortedBy { it.name.lowercase() }
                } else {
                    categoryFiltered.sortedByDescending { it.name.lowercase() }
                }
            }
        }
    }

    if (showAddDialog || itemToEdit != null) {
        AddEditHoldingDialog(
            itemToEdit = itemToEdit,
            onDismiss = {
                showAddDialog = false
                itemToEdit = null
            },
            onSave = { newItem ->
                if (itemToEdit != null) {
                    onUpdateHolding(newItem)
                } else {
                    onAddHolding(newItem)
                }
                showAddDialog = false
                itemToEdit = null
            }
        )
    }

    if (itemPendingDelete != null) {
        val targetItem = itemPendingDelete!!
        AlertDialog(
            onDismissRequest = { itemPendingDelete = null },
            title = {
                Text(
                    text = "Delete Holding",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            },
            text = {
                Text(
                    text = "Are you sure you want to remove ${targetItem.name} (${targetItem.ticker}) from your portfolio?",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteHolding(targetItem.id)
                        itemPendingDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NegativeRed),
                    modifier = Modifier.testTag("confirm_delete_holding_button")
                ) {
                    Text("Delete", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { itemPendingDelete = null },
                    modifier = Modifier.testTag("cancel_delete_holding_button")
                ) {
                    Text("Cancel")
                }
            },
            modifier = Modifier.testTag("delete_holding_dialog")
        )
    }

    if (showDisplayViewBottomSheet) {
        ModalBottomSheet(
            onDismissRequest = { showDisplayViewBottomSheet = false },
            sheetState = rememberModalBottomSheetState(),
            modifier = Modifier.testTag("display_view_bottom_sheet")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Text(
                    text = "Select Display View",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Choose what metric to show on holding cards:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(16.dp))

                DisplayViewOption.values().forEachIndexed { index, option ->
                    val isSelected = selectedDisplayOption == option
                    Surface(
                        onClick = {
                            selectedDisplayOption = option
                            showDisplayViewBottomSheet = false
                        },
                        shape = RoundedCornerShape(14.dp),
                        color = if (isSelected)
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                        border = if (isSelected)
                            androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
                        else null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .testTag("display_option_$index")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = option.label,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold
                                    ),
                                    color = if (isSelected)
                                        MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = option.description,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Selected",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }

    if (showSortByBottomSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSortByBottomSheet = false },
            sheetState = rememberModalBottomSheetState(),
            modifier = Modifier.testTag("sort_by_bottom_sheet")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Sort By",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Select metric & order",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))

                PortfolioSortField.values().forEach { sortField ->
                    val isFieldSelected = sortConfig.field == sortField
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .testTag("sort_row_${sortField.name}"),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = sortField.label,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = if (isFieldSelected) FontWeight.Bold else FontWeight.SemiBold
                            ),
                            color = if (isFieldSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f)
                        )

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Button 1: High -> Low (or A -> Z)
                            val isHighToLowActive = isFieldSelected && sortConfig.direction == SortDirection.HIGH_TO_LOW
                            Surface(
                                onClick = {
                                    sortConfig = PortfolioSortConfig(sortField, SortDirection.HIGH_TO_LOW)
                                    showSortByBottomSheet = false
                                },
                                shape = RoundedCornerShape(50.dp),
                                color = if (isHighToLowActive)
                                    MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                border = if (isHighToLowActive) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                modifier = Modifier.testTag("sort_btn_${sortField.name}_high_low")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    if (isHighToLowActive) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onPrimary,
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                    }
                                    Text(
                                        text = if (sortField.isAlphabetical) "A → Z" else "High → Low",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = if (isHighToLowActive) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            // Button 2: Low -> High (or Z -> A)
                            val isLowToHighActive = isFieldSelected && sortConfig.direction == SortDirection.LOW_TO_HIGH
                            Surface(
                                onClick = {
                                    sortConfig = PortfolioSortConfig(sortField, SortDirection.LOW_TO_HIGH)
                                    showSortByBottomSheet = false
                                },
                                shape = RoundedCornerShape(50.dp),
                                color = if (isLowToHighActive)
                                    MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                border = if (isLowToHighActive) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                modifier = Modifier.testTag("sort_btn_${sortField.name}_low_high")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    if (isLowToHighActive) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onPrimary,
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                    }
                                    Text(
                                        text = if (sortField.isAlphabetical) "Z → A" else "Low → High",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = if (isLowToHighActive) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }

    Scaffold(
        topBar = {
            Column {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primaryContainer,
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AccountBalanceWallet,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier
                                        .padding(8.dp)
                                        .size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = "My Portfolio",
                                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(50),
                                        color = if (isWebSocketConnected) PositiveGreen.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isWebSocketConnected) PositiveGreen.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(6.dp)
                                                    .background(if (isWebSocketConnected) PositiveGreen else Color.Gray, CircleShape)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = if (isWebSocketConnected) "LIVE TICK" else "OFFLINE",
                                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.ExtraBold),
                                                color = if (isWebSocketConnected) PositiveGreen else MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                                Text(
                                    text = "Real-time Holdings & Performance",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = onOpenCloudSync,
                            modifier = Modifier.testTag("portfolio_cloud_sync_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudDone,
                                contentDescription = "Cloud Backup & Sync",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(
                            onClick = onRefreshPortfolio,
                            enabled = !isRefreshing,
                            modifier = Modifier.testTag("refresh_portfolio_button")
                        ) {
                            if (isRefreshing) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Refresh Real-time Prices",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        Button(
                            onClick = { showAddDialog = true },
                            modifier = Modifier
                                .padding(end = 8.dp)
                                .testTag("top_add_holding_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add", fontWeight = FontWeight.Bold)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier.testTag("portfolio_top_app_bar")
                )

                AnimatedVisibility(
                    visible = isRefreshing,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    LinearProgressIndicator(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("portfolio_loading_indicator")
                    )
                }
            }
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddDialog = true },
                icon = { Icon(Icons.Default.Add, contentDescription = "Add Holding") },
                text = { Text("Add Holding", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("fab_add_holding")
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Portfolio Total Summary Card with Timeframe Selection
            PortfolioSummaryCard(
                summary = portfolioSummary,
                selectedTimeframe = selectedTimeframe,
                onSelectTimeframe = { selectedTimeframe = it }
            )

            // Top TabBar with 3 tabs: 'All', 'Stocks & ETFs', 'Mutual Funds'
            PrimaryTabRow(
                selectedTabIndex = selectedTabIndex,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("portfolio_tab_row")
            ) {
                Tab(
                    selected = selectedTabIndex == 0,
                    onClick = { selectedTabIndex = 0 },
                    text = { Text("All (${portfolioItems.size})", fontWeight = FontWeight.SemiBold) },
                    modifier = Modifier.testTag("portfolio_tab_all")
                )
                Tab(
                    selected = selectedTabIndex == 1,
                    onClick = { selectedTabIndex = 1 },
                    text = {
                        Text(
                            "Stocks & ETFs (${portfolioItems.count { it.type == AssetType.STOCK_OR_ETF }})",
                            fontWeight = FontWeight.SemiBold
                        )
                    },
                    modifier = Modifier.testTag("portfolio_tab_stocks")
                )
                Tab(
                    selected = selectedTabIndex == 2,
                    onClick = { selectedTabIndex = 2 },
                    text = {
                        Text(
                            "Mutual Funds (${portfolioItems.count { it.type == AssetType.MUTUAL_FUND }})",
                            fontWeight = FontWeight.SemiBold
                        )
                    },
                    modifier = Modifier.testTag("portfolio_tab_mf")
                )
            }

            // Groww-style Controls Row: Sort By & Display View Selectors
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Holdings (${filteredAndSortedItems.size})",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Sort By Selector Chip
                    Surface(
                        shape = RoundedCornerShape(50.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            MaterialTheme.colorScheme.secondary.copy(alpha = 0.4f)
                        ),
                        modifier = Modifier
                            .clickable { showSortByBottomSheet = true }
                            .testTag("sort_by_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.SwapVert,
                                contentDescription = "Sort By",
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            val dirSymbol = if (sortConfig.field.isAlphabetical) {
                                if (sortConfig.direction == SortDirection.HIGH_TO_LOW) "A-Z" else "Z-A"
                            } else {
                                if (sortConfig.direction == SortDirection.HIGH_TO_LOW) "↓" else "↑"
                            }
                            Text(
                                text = "${sortConfig.field.label} $dirSymbol",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }

                    // Display View Selector Chip
                    Surface(
                        shape = RoundedCornerShape(50.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)
                        ),
                        modifier = Modifier
                            .clickable { showDisplayViewBottomSheet = true }
                            .testTag("display_view_selector")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = selectedDisplayOption.label,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "Select View",
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }

            if (filteredAndSortedItems.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.PieChart,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "No Holdings Found",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Tap 'Add Holding' to start tracking your assets.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    }
                }
            } else {
                // Holdings List
                LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 80.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("portfolio_holdings_list")
                ) {
                    items(filteredAndSortedItems, key = { it.id }) { holding ->
                        val dismissState = rememberSwipeToDismissBoxState(
                            confirmValueChange = { dismissValue ->
                                if (dismissValue == SwipeToDismissBoxValue.EndToStart || dismissValue == SwipeToDismissBoxValue.StartToEnd) {
                                    itemPendingDelete = holding
                                }
                                false
                            }
                        )

                        SwipeToDismissBox(
                            state = dismissState,
                            backgroundContent = {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(NegativeRed, RoundedCornerShape(20.dp))
                                        .padding(horizontal = 20.dp),
                                    contentAlignment = Alignment.CenterEnd
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text("Swipe to Delete", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Delete",
                                            tint = Color.White
                                        )
                                    }
                                }
                            }
                        ) {
                            HoldingCard(
                                holding = holding,
                                selectedDisplayOption = selectedDisplayOption,
                                selectedTimeframe = selectedTimeframe,
                                onEdit = { itemToEdit = holding },
                                onDelete = { itemPendingDelete = holding }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PortfolioSummaryCard(
    summary: PortfolioSummaryMetrics,
    selectedTimeframe: PnLTimeframe,
    onSelectTimeframe: (PnLTimeframe) -> Unit
) {
    val (pnlAmount, pnlPercent, timeframeLabel) = when (selectedTimeframe) {
        PnLTimeframe.ALL_TIME -> Triple(summary.allTimePnL, summary.allTimePnLPercent, "All-Time P&L")
        PnLTimeframe.ONE_DAY -> Triple(summary.oneDayPnL, summary.oneDayPnLPercent, "1-Day P&L")
        PnLTimeframe.SEVEN_DAYS -> Triple(summary.sevenDayPnL, summary.sevenDayPnLPercent, "7-Day P&L")
        PnLTimeframe.ONE_MONTH -> Triple(summary.oneMonthPnL, summary.oneMonthPnLPercent, "1-Month P&L")
    }

    val isPositive = pnlAmount >= 0

    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            MaterialTheme.colorScheme.outlineVariant
        ),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("portfolio_summary_card")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Current Portfolio Value",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "₹${String.format("%,.2f", summary.currentAmount)}",
                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Surface(
                    shape = RoundedCornerShape(50.dp),
                    color = if (isPositive) PositiveGreenBg else NegativeRedBg,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isPositive) PositiveGreen.copy(alpha = 0.5f) else NegativeRed.copy(alpha = 0.5f)
                    )
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = if (isPositive) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                            contentDescription = null,
                            tint = if (isPositive) PositiveGreen else NegativeRed,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${if (isPositive) "+" else ""}${String.format("%.2f", pnlPercent)}%",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = if (isPositive) PositiveGreen else NegativeRed
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Timeframe selector chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = selectedTimeframe == PnLTimeframe.ALL_TIME,
                    onClick = { onSelectTimeframe(PnLTimeframe.ALL_TIME) },
                    label = { Text("All-Time", fontSize = 11.sp) },
                    modifier = Modifier.testTag("timeframe_all_time")
                )
                FilterChip(
                    selected = selectedTimeframe == PnLTimeframe.ONE_DAY,
                    onClick = { onSelectTimeframe(PnLTimeframe.ONE_DAY) },
                    label = { Text("1-Day", fontSize = 11.sp) },
                    modifier = Modifier.testTag("timeframe_1_day")
                )
                FilterChip(
                    selected = selectedTimeframe == PnLTimeframe.SEVEN_DAYS,
                    onClick = { onSelectTimeframe(PnLTimeframe.SEVEN_DAYS) },
                    label = { Text("7-Day", fontSize = 11.sp) },
                    modifier = Modifier.testTag("timeframe_7_days")
                )
                FilterChip(
                    selected = selectedTimeframe == PnLTimeframe.ONE_MONTH,
                    onClick = { onSelectTimeframe(PnLTimeframe.ONE_MONTH) },
                    label = { Text("1-Month", fontSize = 11.sp) },
                    modifier = Modifier.testTag("timeframe_1_month")
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            androidx.compose.material3.HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Total Invested",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "₹${String.format("%,.2f", summary.totalInvested)}",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = timeframeLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${if (isPositive) "+" else ""}₹${String.format("%,.2f", pnlAmount)}",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = if (isPositive) PositiveGreen else NegativeRed
                    )
                }
            }
        }
    }
}

@Composable
fun HoldingCard(
    holding: PortfolioItem,
    selectedDisplayOption: DisplayViewOption = DisplayViewOption.RETURNS_PERCENT,
    selectedTimeframe: PnLTimeframe = PnLTimeframe.ALL_TIME,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val (primaryMetricText, secondaryMetricText, metricPrimaryColor, metricSecondaryColor, metricBgColor) = when (selectedDisplayOption) {
        DisplayViewOption.CURRENT_INVESTED -> {
            val currVal = "₹${String.format("%,.2f", holding.currentAmount)}"
            val invVal = "Invested ₹${String.format("%,.2f", holding.investedAmount)}"
            Quintuple(
                currVal,
                invVal,
                MaterialTheme.colorScheme.onSurface,
                MaterialTheme.colorScheme.onSurfaceVariant,
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
            )
        }
        DisplayViewOption.RETURNS_PERCENT -> {
            val pnl = holding.profitLoss
            val pct = holding.profitLossPercent
            val pos = pnl >= 0
            val sign = if (pos) "+" else ""
            val pnlStr = "${sign}₹${String.format("%,.2f", pnl)}"
            val pctStr = "${sign}${String.format("%.2f", pct)}%"
            Quintuple(
                pnlStr,
                pctStr,
                if (pos) PositiveGreen else NegativeRed,
                if (pos) PositiveGreen else NegativeRed,
                if (pos) PositiveGreenBg else NegativeRedBg
            )
        }
        DisplayViewOption.MARKET_PRICE_1D -> {
            val priceStr = "₹${String.format("%,.2f", holding.currentPrice)}"
            val pct = holding.oneDayPnLPercent
            val pos = pct >= 0
            val sign = if (pos) "+" else ""
            val pctStr = "${sign}${String.format("%.2f", pct)}% 1D"
            Quintuple(
                priceStr,
                pctStr,
                MaterialTheme.colorScheme.onSurface,
                if (pos) PositiveGreen else NegativeRed,
                if (pos) PositiveGreenBg else NegativeRedBg
            )
        }
        DisplayViewOption.ONE_DAY_PNL -> {
            val pnl = holding.oneDayPnL
            val pct = holding.oneDayPnLPercent
            val pos = pnl >= 0
            val sign = if (pos) "+" else ""
            val pnlStr = "${sign}₹${String.format("%,.2f", pnl)}"
            val pctStr = "${sign}${String.format("%.2f", pct)}% 1D"
            Quintuple(
                pnlStr,
                pctStr,
                if (pos) PositiveGreen else NegativeRed,
                if (pos) PositiveGreenBg else NegativeRedBg,
                if (pos) PositiveGreenBg else NegativeRedBg
            )
        }
        DisplayViewOption.SEVEN_DAY_PNL -> {
            val pnl = holding.sevenDayPnL
            val pct = holding.sevenDayPnLPercent
            val pos = pnl >= 0
            val sign = if (pos) "+" else ""
            val pnlStr = "${sign}₹${String.format("%,.2f", pnl)}"
            val pctStr = "${sign}${String.format("%.2f", pct)}% 7D"
            Quintuple(
                pnlStr,
                pctStr,
                if (pos) PositiveGreen else NegativeRed,
                if (pos) PositiveGreen else NegativeRed,
                if (pos) PositiveGreenBg else NegativeRedBg
            )
        }
        DisplayViewOption.ONE_MONTH_PNL -> {
            val pnl = holding.oneMonthPnL
            val pct = holding.oneMonthPnLPercent
            val pos = pnl >= 0
            val sign = if (pos) "+" else ""
            val pnlStr = "${sign}₹${String.format("%,.2f", pnl)}"
            val pctStr = "${sign}${String.format("%.2f", pct)}% 1M"
            Quintuple(
                pnlStr,
                pctStr,
                if (pos) PositiveGreen else NegativeRed,
                if (pos) PositiveGreen else NegativeRed,
                if (pos) PositiveGreenBg else NegativeRedBg
            )
        }
    }

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
        ),
        modifier = modifier
            .fillMaxWidth()
            .testTag("holding_card_${holding.ticker}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Main Header Row: Asset info (left) & Chosen Metric (right)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = holding.name,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (holding.type == AssetType.STOCK_OR_ETF)
                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
                            else MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.7f)
                        ) {
                            Text(
                                text = if (holding.type == AssetType.STOCK_OR_ETF) "ETF" else "MF",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold),
                                color = if (holding.type == AssetType.STOCK_OR_ETF)
                                    MaterialTheme.colorScheme.onPrimaryContainer
                                else MaterialTheme.colorScheme.onTertiaryContainer,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${holding.ticker} • ${if (holding.totalQuantity % 1.0 == 0.0) holding.totalQuantity.toInt().toString() else holding.totalQuantity.toString()} units @ ₹${holding.averageBuyPrice}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                // Prominently Displayed Metric on the Right (Groww Style)
                Column(
                    horizontalAlignment = Alignment.End,
                    modifier = Modifier.testTag("holding_metric_column_${holding.ticker}")
                ) {
                    Text(
                        text = primaryMetricText,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = metricPrimaryColor
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Surface(
                        shape = RoundedCornerShape(50.dp),
                        color = metricBgColor
                    ) {
                        Text(
                            text = secondaryMetricText,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 11.sp),
                            color = metricSecondaryColor,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            androidx.compose.material3.HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
            Spacer(modifier = Modifier.height(10.dp))

            // Details Row: Invested, Current Price & Edit/Delete actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Invested",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "₹${String.format("%,.2f", holding.investedAmount)}",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                }

                Column {
                    Text(
                        text = "Current Value",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "₹${String.format("%,.2f", holding.currentAmount)}",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("edit_holding_${holding.ticker}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit Holding",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("delete_holding_${holding.ticker}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete Holding",
                            tint = NegativeRed,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Multi-Period Performance Breakdown Grid
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    PnLSummaryPill(title = "1D", amount = holding.oneDayPnL, percent = holding.oneDayPnLPercent)
                    PnLSummaryPill(title = "7D", amount = holding.sevenDayPnL, percent = holding.sevenDayPnLPercent)
                    PnLSummaryPill(title = "1M", amount = holding.oneMonthPnL, percent = holding.oneMonthPnLPercent)
                    PnLSummaryPill(title = "All", amount = holding.profitLoss, percent = holding.profitLossPercent)
                }
            }
        }
    }
}

private data class Quintuple<A, B, C, D, E>(
    val first: A,
    val second: B,
    val third: C,
    val fourth: D,
    val fifth: E
)

@Composable
private fun PnLSummaryPill(
    title: String,
    amount: Double,
    percent: Double
) {
    val isPos = amount >= 0
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = "${if (isPos) "+" else ""}${String.format("%.1f", percent)}%",
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp, fontWeight = FontWeight.Bold),
            color = if (isPos) PositiveGreen else NegativeRed
        )
    }
}
