package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.sync.SyncState
import com.example.ui.components.CloudSyncBottomSheet
import com.example.ui.screens.AlertConfigBottomSheet
import com.example.ui.screens.PortfolioScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.WatchlistScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.EtfViewModel

enum class AppScreen {
    WATCHLIST,
    PORTFOLIO,
    SEARCH
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 101)
            }
        }

        setContent {
            MyApplicationTheme {
                EtfTrackerApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EtfTrackerApp(
    viewModel: EtfViewModel = viewModel()
) {
    var currentScreen by remember { mutableStateOf(AppScreen.WATCHLIST) }

    val watchlistEtfs by viewModel.watchlistEtfs.collectAsStateWithLifecycle()
    val marketIndices by viewModel.marketIndices.collectAsStateWithLifecycle()
    val portfolioItems by viewModel.portfolioItems.collectAsStateWithLifecycle()
    val portfolioSummary by viewModel.portfolioSummary.collectAsStateWithLifecycle()
    val isRefreshingPortfolio by viewModel.isRefreshingPortfolio.collectAsStateWithLifecycle()
    val isWebSocketConnected by viewModel.isWebSocketConnected.collectAsStateWithLifecycle()

    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val syncState by viewModel.syncState.collectAsStateWithLifecycle()
    val lastSyncedTimestamp by viewModel.lastSyncedTimestamp.collectAsStateWithLifecycle()
    val syncStatusMessage by viewModel.syncStatusMessage.collectAsStateWithLifecycle()

    var showCloudSyncSheet by remember { mutableStateOf(false) }
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val triggeredAlertsLog by viewModel.triggeredAlertsLog.collectAsStateWithLifecycle()

    val selectedEtfForAlert by viewModel.selectedEtfForAlert.collectAsStateWithLifecycle()
    val editingTargetDrops by viewModel.editingTargetDrops.collectAsStateWithLifecycle()
    val editingBaselineType by viewModel.editingBaselineType.collectAsStateWithLifecycle()
    val editingAlertsEnabled by viewModel.editingAlertsEnabled.collectAsStateWithLifecycle()

    val isEditMode by viewModel.isEditMode.collectAsStateWithLifecycle()
    val itemPendingDelete by viewModel.itemPendingDelete.collectAsStateWithLifecycle()

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(syncState, syncStatusMessage) {
        if (syncState == SyncState.ERROR && syncStatusMessage.isNotBlank()) {
            snackbarHostState.showSnackbar(
                message = "Cloud Sync Error: $syncStatusMessage",
                duration = SnackbarDuration.Short
            )
        }
    }

    LaunchedEffect(isWebSocketConnected) {
        if (!isWebSocketConnected) {
            snackbarHostState.showSnackbar(
                message = "Live price stream disconnected. Check internet connection.",
                duration = SnackbarDuration.Short
            )
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier.testTag("bottom_navigation_bar")
            ) {
                NavigationBarItem(
                    selected = currentScreen == AppScreen.WATCHLIST,
                    onClick = { currentScreen = AppScreen.WATCHLIST },
                    icon = { Icon(imageVector = Icons.Default.Bookmark, contentDescription = "Watchlist") },
                    label = { Text("Watchlist", fontWeight = FontWeight.SemiBold) },
                    modifier = Modifier.testTag("nav_item_watchlist")
                )
                NavigationBarItem(
                    selected = currentScreen == AppScreen.PORTFOLIO,
                    onClick = { currentScreen = AppScreen.PORTFOLIO },
                    icon = { Icon(imageVector = Icons.Default.PieChart, contentDescription = "My Portfolio") },
                    label = { Text("My Portfolio", fontWeight = FontWeight.SemiBold) },
                    modifier = Modifier.testTag("nav_item_portfolio")
                )
            }
        }
    ) { innerPadding ->
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            color = MaterialTheme.colorScheme.background
        ) {
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "ScreenTransition"
            ) { screen ->
                when (screen) {
                    AppScreen.WATCHLIST -> {
                        WatchlistScreen(
                            watchlistEtfs = watchlistEtfs,
                            marketIndices = marketIndices,
                            triggeredAlertsLog = triggeredAlertsLog,
                            isEditMode = isEditMode,
                            itemPendingDelete = itemPendingDelete,
                            isWebSocketConnected = isWebSocketConnected,
                            onToggleEditMode = { viewModel.toggleEditMode() },
                            onRequestDelete = { item -> viewModel.requestDeleteEtf(item) },
                            onConfirmDelete = { viewModel.confirmDelete() },
                            onCancelDelete = { viewModel.cancelDelete() },
                            onOpenSearch = { currentScreen = AppScreen.SEARCH },
                            onConfigureAlerts = { etf -> viewModel.openAlertConfig(etf) },
                            onToggleWatchlist = { symbol -> viewModel.toggleWatchlist(symbol) },
                            onSimulateDrop = { symbol, drop -> viewModel.simulatePriceDrop(symbol, drop) },
                            onOpenCloudSync = { showCloudSyncSheet = true },
                            currentUser = currentUser
                        )
                    }

                    AppScreen.PORTFOLIO -> {
                        PortfolioScreen(
                            portfolioItems = portfolioItems,
                            portfolioSummary = portfolioSummary,
                            isRefreshing = isRefreshingPortfolio,
                            isWebSocketConnected = isWebSocketConnected,
                            onRefreshPortfolio = { viewModel.refreshPortfolioPrices() },
                            onAddHolding = { item -> viewModel.addPortfolioItem(item) },
                            onUpdateHolding = { item -> viewModel.updatePortfolioItem(item) },
                            onDeleteHolding = { id -> viewModel.deletePortfolioItem(id) },
                            onOpenCloudSync = { showCloudSyncSheet = true }
                        )
                    }

                    AppScreen.SEARCH -> {
                        SearchScreen(
                            searchResults = searchResults,
                            searchQuery = searchQuery,
                            selectedCategory = selectedCategory,
                            onQueryChange = { q -> viewModel.onSearchQueryChange(q) },
                            onCategorySelect = { c -> viewModel.onCategorySelect(c) },
                            onConfigureAlerts = { etf -> viewModel.openAlertConfig(etf) },
                            onToggleWatchlist = { symbol -> viewModel.toggleWatchlist(symbol) },
                            onBack = { currentScreen = AppScreen.WATCHLIST }
                        )
                    }
                }
            }

            // Alert Configuration Modal BottomSheet
            if (selectedEtfForAlert != null) {
                AlertConfigBottomSheet(
                    etf = selectedEtfForAlert!!,
                    targetDrops = editingTargetDrops,
                    baselineType = editingBaselineType,
                    alertsEnabled = editingAlertsEnabled,
                    sheetState = sheetState,
                    onDismiss = { viewModel.closeAlertConfig() },
                    onAddDropTarget = { pct -> viewModel.addTargetDropPercentage(pct) },
                    onEditDropTarget = { oldVal, newVal -> viewModel.updateTargetDropPercentage(oldVal, newVal) },
                    onRemoveDropTarget = { pct -> viewModel.removeTargetDropPercentage(pct) },
                    onSetBaselineType = { base -> viewModel.setBaselineType(base) },
                    onSetAlertsEnabled = { enabled -> viewModel.setAlertsEnabled(enabled) },
                    onSave = { viewModel.saveAlertConfig() }
                )
            }

            // Cloud Backup and Sync BottomSheet
            if (showCloudSyncSheet) {
                CloudSyncBottomSheet(
                    currentUser = currentUser,
                    syncState = syncState,
                    lastSyncedTimestamp = lastSyncedTimestamp,
                    statusMessage = syncStatusMessage,
                    onDismiss = { showCloudSyncSheet = false },
                    onTriggerSync = { viewModel.triggerManualCloudSync() },
                    onSignInAccount = { email, name -> viewModel.signInAccount(email, name) },
                    onSignOut = { viewModel.signOutAccount() }
                )
            }
        }
    }
}
